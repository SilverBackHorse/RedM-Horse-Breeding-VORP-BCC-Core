-- BCC Horse Breeding Pack - All In One SQL Installer
-- Safe to run on a fresh database OR an existing database.
-- Creates/patches:
--   player_horses
--   bcc_horsebreeding_* tables
--   coal_stables_horses
--   Coal appearance columns
--   BCC stables item rows, only if the items table exists

SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------------
-- Helper procedures for old MySQL/MariaDB hosts that do not support
-- ADD COLUMN IF NOT EXISTS or CREATE INDEX IF NOT EXISTS.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS hbpack_add_column_if_missing;
DELIMITER $$
CREATE PROCEDURE hbpack_add_column_if_missing(
    IN p_table VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_definition TEXT
)
BEGIN
    IF EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = p_table
    ) AND NOT EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = p_table
          AND COLUMN_NAME = p_column
    ) THEN
        SET @hb_sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
        PREPARE hb_stmt FROM @hb_sql;
        EXECUTE hb_stmt;
        DEALLOCATE PREPARE hb_stmt;
    END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS hbpack_add_index_if_missing;
DELIMITER $$
CREATE PROCEDURE hbpack_add_index_if_missing(
    IN p_table VARCHAR(64),
    IN p_index VARCHAR(64),
    IN p_columns TEXT
)
BEGIN
    IF EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = p_table
    ) AND NOT EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = p_table
          AND INDEX_NAME = p_index
    ) THEN
        SET @hb_sql = CONCAT('CREATE INDEX `', p_index, '` ON `', p_table, '` (', p_columns, ')');
        PREPARE hb_stmt FROM @hb_sql;
        EXECUTE hb_stmt;
        DEALLOCATE PREPARE hb_stmt;
    END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS hbpack_modify_column_if_exists;
DELIMITER $$
CREATE PROCEDURE hbpack_modify_column_if_exists(
    IN p_table VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_definition TEXT
)
BEGIN
    IF EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = p_table
          AND COLUMN_NAME = p_column
    ) THEN
        SET @hb_sql = CONCAT('ALTER TABLE `', p_table, '` MODIFY COLUMN `', p_column, '` ', p_definition);
        PREPARE hb_stmt FROM @hb_sql;
        EXECUTE hb_stmt;
        DEALLOCATE PREPARE hb_stmt;
    END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS hbpack_insert_stable_items_if_possible;
DELIMITER $$
CREATE PROCEDURE hbpack_insert_stable_items_if_possible()
BEGIN
    IF EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'items'
    ) THEN
        INSERT INTO `items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`, `desc`)
        VALUES
          ('oil_lantern', 'Oil Lantern', 1, 1, 'item_standard', 1, 'A portable light source.'),
          ('consumable_horse_reviver', 'Horse Reviver', 3, 1, 'item_standard', 1, 'Curative compound for injured horse.'),
          ('consumable_haycube', 'Haycube', 10, 1, 'item_standard', 1, 'A compact cube of hay.'),
          ('horsebrush', 'Horse Brush', 5, 1, 'item_standard', 1, 'A brush used for grooming horses.'),
          ('consumable_apple', 'Apple', 10, 1, 'item_standard', 1, 'A juicy and delicious fruit.'),
          ('consumable_carrots', 'Carrots', 10, 1, 'item_standard', 1, 'An orange root vegetable commonly used in cooking.'),
          ('diamond', 'Diamond', 20, 1, 'item_standard', 1, 'A precious gemstone known for its brilliance and value.')
        ON DUPLICATE KEY UPDATE
          `label` = VALUES(`label`),
          `limit` = VALUES(`limit`),
          `can_remove` = VALUES(`can_remove`),
          `type` = VALUES(`type`),
          `usable` = VALUES(`usable`),
          `desc` = VALUES(`desc`);
    END IF;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------------
-- BCC Stables player_horses table. This is created if the user has not
-- installed BCC Stables SQL yet. If it already exists, the missing columns are
-- added below without breaking existing data.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `player_horses` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(50) NOT NULL,
  `charid` INT(11) NOT NULL,
  `selected` INT(11) NOT NULL DEFAULT 0,
  `name` VARCHAR(100) NOT NULL,
  `model` VARCHAR(100) NOT NULL,
  `components` LONGTEXT NULL,
  `gender` ENUM('male', 'female') DEFAULT 'male',
  `xp` INT(11) NOT NULL DEFAULT 0,
  `captured` INT(11) NOT NULL DEFAULT 0,
  `born` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `health` INT(11) NOT NULL DEFAULT 50,
  `stamina` INT(11) NOT NULL DEFAULT 50,
  `writhe` INT(11) NOT NULL DEFAULT 0,
  `dead` INT(11) NOT NULL DEFAULT 0,
  `breedable` TINYINT(1) DEFAULT NULL,
  `inBreed` TINYINT(1) DEFAULT NULL,
  `coal_appearance` LONGTEXT DEFAULT NULL,
  `coal_tack_colors` LONGTEXT DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CALL hbpack_add_column_if_missing('player_horses', 'identifier', 'VARCHAR(50) NOT NULL DEFAULT ''''');
CALL hbpack_add_column_if_missing('player_horses', 'charid', 'INT(11) NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('player_horses', 'selected', 'INT(11) NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('player_horses', 'name', 'VARCHAR(100) NOT NULL DEFAULT ''Horse''');
CALL hbpack_add_column_if_missing('player_horses', 'model', 'VARCHAR(100) NOT NULL DEFAULT ''''');
CALL hbpack_add_column_if_missing('player_horses', 'components', 'LONGTEXT NULL');
CALL hbpack_add_column_if_missing('player_horses', 'gender', 'ENUM(''male'', ''female'') DEFAULT ''male''');
CALL hbpack_add_column_if_missing('player_horses', 'xp', 'INT(11) NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('player_horses', 'captured', 'INT(11) NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('player_horses', 'born', 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP');
CALL hbpack_add_column_if_missing('player_horses', 'health', 'INT(11) NOT NULL DEFAULT 50');
CALL hbpack_add_column_if_missing('player_horses', 'stamina', 'INT(11) NOT NULL DEFAULT 50');
CALL hbpack_add_column_if_missing('player_horses', 'writhe', 'INT(11) NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('player_horses', 'dead', 'INT(11) NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('player_horses', 'breedable', 'TINYINT(1) DEFAULT NULL');
CALL hbpack_add_column_if_missing('player_horses', 'inBreed', 'TINYINT(1) DEFAULT NULL');
CALL hbpack_add_column_if_missing('player_horses', 'coal_appearance', 'LONGTEXT DEFAULT NULL');
CALL hbpack_add_column_if_missing('player_horses', 'coal_tack_colors', 'LONGTEXT DEFAULT NULL');
CALL hbpack_modify_column_if_exists('player_horses', 'components', 'LONGTEXT NULL');
CALL hbpack_add_index_if_missing('player_horses', 'idx_charid', '`charid`');
CALL hbpack_add_index_if_missing('player_horses', 'idx_identifier', '`identifier`');

-- Add stable consumable/items rows only when the framework items table exists.
CALL hbpack_insert_stable_items_if_possible();

-- ---------------------------------------------------------------------------
-- BCC Horse Breeding tables.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_horses` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ranch_id` INT NOT NULL,
  `horse_id` INT NOT NULL,
  `owner_identifier` VARCHAR(50) NOT NULL,
  `owner_charid` INT NOT NULL,
  `status` VARCHAR(50) NOT NULL DEFAULT 'ready',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_ranch_horse` (`ranch_id`, `horse_id`),
  KEY `idx_ranch` (`ranch_id`),
  KEY `idx_horse` (`horse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_foals` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ranch_id` INT NOT NULL,
  `owner_identifier` VARCHAR(50) NOT NULL,
  `owner_charid` INT NOT NULL,
  `mother_horse_id` INT NOT NULL,
  `father_horse_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL DEFAULT 'Foal',
  `model` VARCHAR(100) NOT NULL,
  `components` LONGTEXT NULL,
  `scale` FLOAT NOT NULL DEFAULT 0.60,
  `gender` ENUM('male','female') NOT NULL DEFAULT 'male',
  `stage` VARCHAR(30) NOT NULL DEFAULT 'pregnancy',
  `born_at` INT NOT NULL DEFAULT 0,
  `young_at` INT NOT NULL DEFAULT 0,
  `adult_at` INT NOT NULL DEFAULT 0,
  `pregnancy_end` INT NOT NULL DEFAULT 0,
  `hunger` INT NOT NULL DEFAULT 75,
  `thirst` INT NOT NULL DEFAULT 75,
  `cleanliness` INT NOT NULL DEFAULT 75,
  `bonding` INT NOT NULL DEFAULT 0,
  `training` INT NOT NULL DEFAULT 0,
  `manure` INT NOT NULL DEFAULT 0,
  `claimed` TINYINT(1) NOT NULL DEFAULT 0,
  `foal_number` INT NOT NULL DEFAULT 0,
  `last_hay_chore` INT NOT NULL DEFAULT 0,
  `last_water_chore` INT NOT NULL DEFAULT 0,
  `last_cleanpoop_chore` INT NOT NULL DEFAULT 0,
  `coal_appearance` LONGTEXT DEFAULT NULL,
  `coal_tack_colors` LONGTEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ranch_stage` (`ranch_id`, `stage`),
  KEY `idx_owner` (`owner_charid`, `owner_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CALL hbpack_add_column_if_missing('bcc_horsebreeding_foals', 'foal_number', 'INT NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('bcc_horsebreeding_foals', 'last_hay_chore', 'INT NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('bcc_horsebreeding_foals', 'last_water_chore', 'INT NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('bcc_horsebreeding_foals', 'last_cleanpoop_chore', 'INT NOT NULL DEFAULT 0');
CALL hbpack_add_column_if_missing('bcc_horsebreeding_foals', 'coal_appearance', 'LONGTEXT DEFAULT NULL');
CALL hbpack_add_column_if_missing('bcc_horsebreeding_foals', 'coal_tack_colors', 'LONGTEXT DEFAULT NULL');
CALL hbpack_add_column_if_missing('bcc_horsebreeding_foals', 'components', 'LONGTEXT NULL');

CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_zones` (
  `ranch_id` INT NOT NULL,
  `zone_data` LONGTEXT NOT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ranch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_supplies` (
  `ranch_id` INT NOT NULL,
  `supplies` INT NOT NULL DEFAULT 0,
  `last_buy` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`ranch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Coal stables table. This is separate from BCC Stables, but included because
-- the pack ships Coal appearance support.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `coal_stables_horses` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(128) NOT NULL,
  `slot` INT NOT NULL DEFAULT 1,
  `horse_id` VARCHAR(128) NOT NULL,
  `last_stable` VARCHAR(128) DEFAULT NULL,
  `model` VARCHAR(128) DEFAULT NULL,
  `tack_json` LONGTEXT DEFAULT NULL,
  `beauty_json` LONGTEXT DEFAULT NULL,
  `is_main` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_identifier_slot` (`identifier`, `slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Cleanup helper procedures.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS hbpack_insert_stable_items_if_possible;
DROP PROCEDURE IF EXISTS hbpack_modify_column_if_exists;
DROP PROCEDURE IF EXISTS hbpack_add_index_if_missing;
DROP PROCEDURE IF EXISTS hbpack_add_column_if_missing;

SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS;
