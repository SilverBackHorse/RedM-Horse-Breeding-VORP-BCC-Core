Config = {}

Config.DevMode = false
Config.Command = 'horsebreeding' -- opens the ranch breeding menu
Config.RanchUseDistance = 45.0

-- If true, only ranch owners/employees can use the horse breeding ranch.
-- Set false while testing if your BCC Ranch employee/owner lookup is blocking you.
Config.StrictBccRanchPermission = false

-- Horse chores/care are portable by design. Players can open the breeding menu away from
-- saved chore points, but chore setup is blocked in towns by Config.BlockedTowns below.
Config.AllowAnywhereTesting = true

-- Prevent portable breeding chores/props from being started in towns.
Config.BlockHorseTasksInTowns = true
Config.BlockedTownRadius = 250.0
Config.BlockedTowns = {
    { name = 'Valentine', coords = vector3(-277.0, 805.0, 119.0), radius = 260.0 },
    { name = 'Blackwater', coords = vector3(-875.0, -1328.0, 43.0), radius = 320.0 },
    { name = 'Saint Denis', coords = vector3(2630.0, -1225.0, 53.0), radius = 520.0 },
    { name = 'Rhodes', coords = vector3(1230.0, -1295.0, 76.0), radius = 280.0 },
    { name = 'Strawberry', coords = vector3(-1800.0, -425.0, 154.0), radius = 260.0 },
    { name = 'Armadillo', coords = vector3(-3662.0, -2602.0, -14.0), radius = 260.0 },
    { name = 'Tumbleweed', coords = vector3(-5517.0, -2940.0, -2.0), radius = 260.0 },
    { name = 'Annesburg', coords = vector3(2930.0, 1345.0, 44.0), radius = 260.0 },
    { name = 'Van Horn', coords = vector3(2986.0, 570.0, 44.0), radius = 260.0 },
    { name = 'Emerald Ranch', coords = vector3(1416.0, 278.0, 89.0), radius = 220.0 },
    { name = 'MacFarlanes Ranch', coords = vector3(-2395.0, -2378.0, 61.0), radius = 220.0 }
}

-- Draw map blips for saved horse breeding ranch zones.
Config.ShowBreedingBlips = true
Config.BreedingBlipSprite = 'blip_horse_owned_bonding_4'
Config.BreedingBlipSpriteHash = -637422489 -- blip_horse_owned_bonding_4
Config.BreedingBlipScale = 0.2
Config.BreedingBlipColorModifier = 'BLIP_MODIFIER_MP_COLOR_8'
Config.FoalSpawnDistance = 12.0
Config.MaxActiveFoals = 3
Config.MaxActiveMares = 3
Config.MareSpawnOffset = vector3(-2.5, -1.5, 0.0)
Config.RanchAnimalMaxDistance = 45.0
Config.RanchAnimalTeleportBuffer = 25.0
Config.RanchAnimalBoundaryCheckMs = 5000
Config.RanchAnimalOwnerAttentionDistance = 18.0 -- if owner is nearby, loose mares/foals stay close
Config.RanchAnimalOwnerTooFarDistance = 28.0 -- start walking back toward owner/ranch when farther than this
Config.RanchAnimalAmbientCareChance = 25 -- percent chance per AI tick to visit hay/water/manure spot
Config.FoalSpawnOffsets = { vector3(2.0, 1.5, 0.0), vector3(3.0, -1.5, 0.0), vector3(-2.0, 1.5, 0.0) }
Config.ShowFoalNumberOverHead = true
Config.FoalNumberDrawDistance = 18.0

-- Real server times. Shorten for testing.
Config.PregnancySeconds = 60 * 60 * 24 -- 24 hours
Config.FoalToYoungSeconds = 60 * 60 * 12 -- 12 hours
Config.YoungToAdultSeconds = 60 * 60 * 12 -- 12 hours
Config.FoalGrowthDbUpdateMinutes = 1 -- DB scale/stage refresh interval for live growth.

-- Testing examples:
-- Config.PregnancySeconds = 300
-- Config.FoalToYoungSeconds = 300
-- Config.YoungToAdultSeconds = 300


-- Portable chore props. These spawn temporarily near the player when a chore starts,
-- then are cleaned up on finish/cancel/resource stop.
Config.DynamicChoreProps = true
Config.ChoreAnimationStartDelayMs = 750
Config.HayProgressAfterAnimationMs = 0
Config.HayShortCountdownMs = 1000
Config.ChoreToolPropsToCleanup = { 'p_bucket03x', 'p_bucket01x', 'p_bucket02x', 'p_pitchfork01x', 'p_hayfork01x', 'p_rake01x', 'p_rake02x', 'p_shovel01x' }
Config.WaterBucketProp = 'p_bucket03x'
Config.WaterBucketAttach = { bone = 'PH_R_Hand', x = 0.0, y = 0.0, z = 0.0, rx = 0.0, ry = 0.0, rz = 0.0 }
Config.CleaningRakeProp = 'p_rake02x'
Config.CleaningRakeAttach = { bone = 'PH_R_Hand', x = 0.0, y = 0.0, z = 0.19, rx = 0.0, ry = 0.0, rz = 0.0 }
Config.ChoreProps = {
    water = {
        { model = 'p_watertrough01x', hash = 199641577, offset = vector3(1.6, 0.0, 0.0), headingOffset = 90.0 }
    },
    hay = {
        { model = 'p_haybale01x', hash = 540874704, offset = vector3(1.4, 0.0, 0.0), headingOffset = 0.0 },
        { model = 'p_haypile01x', offset = vector3(0.2, 1.0, 0.0), headingOffset = 35.0 }
    },
    cleanpoop = {
        { model = 'p_haypile02x', offset = vector3(0.0, 0.0, 0.0), headingOffset = 20.0 }
    }
}

Config.RegisterUsableFoalCareItems = false -- If BCC Stables says 'no horse out', start this resource after bcc-stables so these item handlers route brush/feed to nearby spawned foals.

Config.Care = {
    FeedAmount = 30,
    WaterAmount = 30,
    BrushAmount = 25,
    DirectFeedHayCubeAmount = 18,
    DirectFeedSugarCubeAmount = 10,
    DirectFeedBondHayCubeAmount = 4,
    DirectFeedBondSugarCubeAmount = 8,
    DirectFeedTrainingSugarCubeAmount = 1,
    CleanPoopAmount = 30,
    GroundworkBondAmount = 15,
    GroundworkTrainingAmount = 15,
    MaxValue = 100,
    ChoreCooldownMinutes = 10,
    DecayEveryMinutes = 10,
    DecayAmount = 9,
    MinCareToClaimAdult = 25,
    MinTrainingBonusThreshold = 50,
    GrowthBonusEnabled = true,
    GrowthBonusThreshold = 65,
    MaxGrowthBonusSecondsPerChore = 600,
    StatBasedGrowthEnabled = true,
    StatGrowthMinAverage = 0,
    StatGrowthMaxMultiplier = 2.0 -- at 100 average care/training/bonding, 24h growth can finish in about 12h.
}


Config.PassiveTraining = {
    Enabled = true,
    CheckEveryMs = 5000,
    MinTravelDistance = 12.0,
    LassoBondAmount = 3,
    LassoTrainingAmount = 5,
    RidingBondAmount = 2,
    RidingTrainingAmount = 6
}


Config.Resupply = {
    Enabled = true,
    SupplyGain = 60,
    MaxValue = 100,
    TimeLimitSeconds = 0, -- disabled: resupply deliveries no longer fail by timer
    CompletionRadius = 22.0,
    SpawnMinDistance = 300.0,
    SpawnMaxDistance = 450.0,
    SpawnNearPlayerRoad = false, -- use ranch radius, not player-road, so it spawns farther away
    RoadSearchAttempts = 24,
    WagonModel = 'wagon05x',
    DriverModel = 'a_m_m_rancher_01',
    HayBaleModel = 's_haybale01x',
    CargoCount = 8,
    WagonBlipSprite = -570710357,
    DestinationBlipSprite = -440547520,
    WagonBlipScale = 0.25,
    DestinationBlipScale = 0.3,
    NpcDriveSpeed = 3.5,
    PlayerNearWagonRadius = 18.0
}

Config.RanchSupplies = {
    Enabled = true,
    MaxValue = 100,
    BuyAmount = 45,
    ChoreCost = 15,
    RequiredForChores = { hay = true, water = true, cleanpoop = true, feed_haycube = true, feed_sugarcube = true },
    BuyCooldownMinutes = 10,
    CashPrice = 25,
    GoldPrice = 1
}

Config.MareCare = {
    PassivePregnancyBoostEnabled = true,
    PassiveCheckMinutes = 10,
    PassivePregnancyBonusSeconds = 600, -- while supplies > 0 and all care locations are set
    BrushPregnancyBonusSeconds = 900,
    HayCubePregnancyBonusSeconds = 900,
    SugarCubePregnancyBonusSeconds = 1200
}


-- Chore locations are offsets from the ranch center, like BCC Ranch-style ranch task spots.
-- Move these per-ranch by editing the offsets, or duplicate this table and add your own ranch-specific logic later.
Config.Chores = {
    hay = {
        label = 'Feed Hay At Location',
        action = 'feed_hay',
        offset = vector3(3.0, 2.0, 0.0),
        radius = 4.0,
        duration = 8000,
        scenario = 'WORLD_HUMAN_PITCH_HAY_SPREAD',
        description = ''
    },
    water = {
        label = 'Fill Water At Location',
        action = 'water_trough',
        offset = vector3(5.0, 2.0, 0.0),
        radius = 4.0,
        duration = 8000,
        scenario = 'WORLD_HUMAN_BUCKET_POUR_LOW',
        description = ''
    },
    cleanpoop = {
        label = 'Clean Poop/Bedding At Location',
        action = 'clean_poop',
        offset = vector3(-3.0, 2.0, 0.0),
        radius = 4.0,
        duration = 10000,
        scenario = 'WORLD_HUMAN_FARMER_RAKE',
        description = ''
    }
}



-- Optional item requirements. Keep false until you confirm your item names.
Config.RequireCareItems = false
Config.CareItems = {
    feed = 'consumable_haycube',
    water = 'water',
    brush = 'horsebrush',
    feed_haycube = 'consumable_haycube',
    feed_sugarcube = 'sugarcube',
    feed_hay = 'consumable_haycube',
    water_trough = 'water',
    brush_horse = 'horsebrush',
    clean_poop = nil,
    groundwork = nil
}

-- Adult foal defaults inserted into BCC Stables player_horses.
Config.BornHorseDefaults = {
    captured = 0,
    selected = 0,
    health = 75,
    stamina = 75,
    xpBonusMin = 0,
    xpBonusMax = 100
}

-- If one parent model fails, the foal falls back to this horse model.
Config.DefaultFoalModel = 'a_c_horse_morgan_flaxenchestnut'

-- Foal sizing uses the same native Coal Stables uses: Citizen.InvokeNative(0x25ACFC650B65C538, ped, scale).
Config.FoalScales = {
    newborn = 0.60,
    foal = 0.60,
    foalMid = 0.70,
    young = 0.80,
    adult = 0.90,
    stableAdult = 1.00
}

-- Foal growth is 24 real hours after birth:
-- 0-6h = 0.6, 6-12h = 0.7, 12-18h = 0.8, 18-24h/adult ranch state = 0.9.
-- When claimed into BCC Stables, Coal appearance scale is saved as 1.0.



Config.Notify = {
    -- Same left-side notification style as vorp_lootnpcs.
    -- Leave title/icon blank so there is no checkmark/X icon.
    Title = '',
    TextureDict = '',
    TextureIcon = '',
    Color = 'COLOR_WHITE',
    Duration = 4000
}

Config.Text = {
    menuTitle = 'Horse Breeding Ranch',
    noRanch = 'Open /horsebreeding outside town to set up your temporary breeding ranch.',
    noHorses = 'No horses found.',
    registered = 'Horse registered at this ranch.',
    breedStarted = 'Breeding started. The mare is now pregnant.',
    careDone = 'Horse chore completed. Stats updated.',
    claimed = 'Foal grew up and was added to BCC Stables.',
    notReady = 'That foal is not adult yet.',
    tooFarFromChore = 'You are too far from that chore spot.',
    townBlocked = 'You cannot do horse breeding chores inside or too close to town.',
    choreCancelled = 'Chore cancelled.',
    failed = 'Action failed.',
    setupSaved = 'Horse breeding setup saved.',
    setupCleared = 'Horse breeding setup removed.',
    setupNoRanches = 'No ranches found for setup.',
    setupPickPoint = 'Stand where you want this point, then click the menu button.',
    packupDone = 'Horse breeding ranch packed up.',
    careAreaNeeded = 'Set Foal Care Locations first.',
    choreLocationNeeded = 'Set this chore location first.',
    foalSpawned = 'Foal spawned at the breeding ranch.',
    noSupplies = 'Ranch supplies are empty. Buy supplies before doing chores.',
    choreCooldown = 'That chore is on cooldown.',
    suppliesBought = 'Ranch supplies increased.',
    supplyCooldown = 'You must wait before buying more ranch supplies.',
    notEnoughMoney = 'You do not have enough money.',
    paymentFailed = 'Payment failed. Supplies were not purchased.'
}
