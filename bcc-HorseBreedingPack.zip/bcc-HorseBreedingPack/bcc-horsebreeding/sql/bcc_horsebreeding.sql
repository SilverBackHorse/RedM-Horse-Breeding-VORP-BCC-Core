-- BCC Horse Breeding SQL - safe/idempotent installer
-- Safe to run more than once. BCC Stables should still be installed for full stable features.

CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_horses` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ranch_id` INT NOT NULL,
  `horse_id` INT NOT NULL,
  `owner_identifier` VARCHAR(50) NOT NULL,
  `owner_charid` INT NOT NULL,
  `status` VARCHAR(50) NOT NULL DEFAULT 'ready',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_ranch_horse` (`ranch_id`, `horse_id`),
  KEY `idx_ranch` (`ranch_id`),
  KEY `idx_horse` (`horse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_foals` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ranch_id` INT NOT NULL,
  `owner_identifier` VARCHAR(50) NOT NULL,
  `owner_charid` INT NOT NULL,
  `mother_horse_id` INT NOT NULL,
  `father_horse_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL DEFAULT 'Foal',
  `model` VARCHAR(100) NOT NULL,
  `components` LONGTEXT NULL,
  `scale` FLOAT NOT NULL DEFAULT 0.60,
  `gender` ENUM('male','female') NOT NULL DEFAULT 'male',
  `stage` VARCHAR(30) NOT NULL DEFAULT 'pregnancy',
  `born_at` INT NOT NULL DEFAULT 0,
  `young_at` INT NOT NULL DEFAULT 0,
  `adult_at` INT NOT NULL DEFAULT 0,
  `pregnancy_end` INT NOT NULL DEFAULT 0,
  `hunger` INT NOT NULL DEFAULT 75,
  `thirst` INT NOT NULL DEFAULT 75,
  `cleanliness` INT NOT NULL DEFAULT 75,
  `bonding` INT NOT NULL DEFAULT 0,
  `training` INT NOT NULL DEFAULT 0,
  `manure` INT NOT NULL DEFAULT 0,
  `claimed` TINYINT(1) NOT NULL DEFAULT 0,
  `foal_number` INT NOT NULL DEFAULT 0,
  `last_hay_chore` INT NOT NULL DEFAULT 0,
  `last_water_chore` INT NOT NULL DEFAULT 0,
  `last_cleanpoop_chore` INT NOT NULL DEFAULT 0,
  `coal_appearance` LONGTEXT DEFAULT NULL,
  `coal_tack_colors` LONGTEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ranch_stage` (`ranch_id`, `stage`),
  KEY `idx_owner` (`owner_charid`, `owner_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_zones` (
  `ranch_id` INT NOT NULL,
  `zone_data` LONGTEXT NOT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ranch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_supplies` (
  `ranch_id` INT NOT NULL,
  `supplies` INT NOT NULL DEFAULT 0,
  `last_buy` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`ranch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Minimal safety table so Coal/Breeding columns do not fail if this SQL is run before bcc-stables.sql.
CREATE TABLE IF NOT EXISTS `player_horses` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(50) NOT NULL,
  `charid` INT(11) NOT NULL,
  `selected` INT(11) NOT NULL DEFAULT 0,
  `name` VARCHAR(100) NOT NULL,
  `model` VARCHAR(100) NOT NULL,
  `components` LONGTEXT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Compatibility helpers: avoids MySQL/MariaDB version problems with ADD COLUMN IF NOT EXISTS / CREATE INDEX IF NOT EXISTS.
DROP PROCEDURE IF EXISTS `bcc_safe_add_column`;
DELIMITER $$
CREATE PROCEDURE `bcc_safe_add_column`(IN p_table VARCHAR(64), IN p_column VARCHAR(64), IN p_definition TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND COLUMN_NAME = p_column
  ) THEN
    SET @sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS `bcc_safe_add_index`;
DELIMITER $$
CREATE PROCEDURE `bcc_safe_add_index`(IN p_table VARCHAR(64), IN p_index VARCHAR(64), IN p_definition TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND INDEX_NAME = p_index
  ) THEN
    SET @sql = CONCAT('CREATE INDEX `', p_index, '` ON `', p_table, '` ', p_definition);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;
END$$
DELIMITER ;

CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'components', 'LONGTEXT NULL');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'scale', 'FLOAT NOT NULL DEFAULT 0.60');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'bonding', 'INT NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'training', 'INT NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'manure', 'INT NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'claimed', 'TINYINT(1) NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'foal_number', 'INT NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'last_hay_chore', 'INT NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'last_water_chore', 'INT NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'last_cleanpoop_chore', 'INT NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'coal_appearance', 'LONGTEXT DEFAULT NULL');
CALL `bcc_safe_add_column`('bcc_horsebreeding_foals', 'coal_tack_colors', 'LONGTEXT DEFAULT NULL');

CALL `bcc_safe_add_column`('player_horses', 'components', 'LONGTEXT NULL');
CALL `bcc_safe_add_column`('player_horses', 'coal_appearance', 'LONGTEXT DEFAULT NULL');
CALL `bcc_safe_add_column`('player_horses', 'coal_tack_colors', 'LONGTEXT DEFAULT NULL');
ALTER TABLE `player_horses` MODIFY COLUMN `components` LONGTEXT NULL;

DROP PROCEDURE IF EXISTS `bcc_safe_add_column`;
DROP PROCEDURE IF EXISTS `bcc_safe_add_index`;
