local BccUtils = exports['bcc-utils'].initiate()
local FeatherMenu = exports['feather-menu'].initiate()

local HBMenu = FeatherMenu:RegisterMenu('bcc-horsebreeding:Menu', {
    top = '40%',
    left = '20%',
    ['720width'] = '400px',
    ['1080width'] = '500px',
    ['2kwidth'] = '600px',
    ['4kwidth'] = '800px',
    style = {},
    contentslot = { style = { ['height'] = '500px', ['min-height'] = '500px' } },
    draggable = true
})

local function dprint(msg)
    if Config.DevMode then print('^3[bcc-horsebreeding client]^7 ' .. tostring(msg)) end
end

-- Breeding notifications use the same simple VORP tip style as void_paycheck-vorp.
-- No Feather notify, no custom NUI, no blue-line prompt.
local function notify(msg, duration)
    TriggerEvent('vorp:Tip', tostring(msg or ''), tonumber(duration) or ((Config.Notify and Config.Notify.Duration) or 5000))
end

RegisterNetEvent('bcc-horsebreeding:notify', function(msg, duration)
    notify(msg, duration)
end)

local function notifyGain(label, foal)
    notify(label)
end


local function formatDueTime(seconds)
    seconds = tonumber(seconds) or 0
    if seconds <= 0 then return 'soon' end
    local mins = math.floor(seconds / 60)
    if mins < 1 then return 'under 1m' end
    local days = math.floor(mins / 1440)
    local hours = math.floor((mins % 1440) / 60)
    local remMins = mins % 60
    if days > 0 then
        if hours > 0 then return ('about %sd %sh'):format(days, hours) end
        return ('about %sd'):format(days)
    end
    if hours > 0 then
        if remMins > 0 then return ('about %sh %sm'):format(hours, remMins) end
        return ('about %sh'):format(hours)
    end
    return ('about %sm'):format(remMins)
end

local function decodeCoords(raw)
    if type(raw) ~= 'string' then return nil end
    local ok, data = pcall(json.decode, raw)
    if not ok or not data then return nil end
    if data.x and data.y and data.z then return vector3(tonumber(data.x), tonumber(data.y), tonumber(data.z)) end
    return nil
end

local function vecToTable(v)
    return { x = tonumber(v.x), y = tonumber(v.y), z = tonumber(v.z) }
end

local function decodeBreedingZone(raw)
    if type(raw) ~= 'string' or raw == '' then return nil end
    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= 'table' then return nil end
    return data
end

local function tableToVector(t)
    if type(t) ~= 'table' or not t.x or not t.y or not t.z then return nil end
    return vector3(tonumber(t.x), tonumber(t.y), tonumber(t.z))
end

local function getRanchCenter(ranch)
    local zone = ranch.hbZone or decodeBreedingZone(ranch.horsebreeding_zone)
    if zone and zone.center then
        local c = tableToVector(zone.center)
        if c then return c end
    end
    return ranch.coords or decodeCoords(ranch.ranchcoords)
end

local function ensureZoneLoaded(ranch)
    ranch.hbZone = ranch.hbZone or decodeBreedingZone(ranch.horsebreeding_zone) or { points = {} }
    ranch.hbZone.points = ranch.hbZone.points or {}
    return ranch.hbZone
end

local function getNearestAllowedRanch(cb)
    BccUtils.RPC:Call('bcc-horsebreeding:GetMyRanches', {}, function(ranches)
        local ped = PlayerPedId()
        local pcoords = GetEntityCoords(ped)
        local nearest, nearestDist = nil, 999999.0
        for _, ranch in ipairs(ranches or {}) do
            ranch.hbZone = decodeBreedingZone(ranch.horsebreeding_zone)
            local coords = getRanchCenter(ranch)
            if coords then
                local dist = #(pcoords - coords)
                local zoneRadius = ranch.hbZone and tonumber(ranch.hbZone.radius)
                local limit = zoneRadius or tonumber(ranch.ranch_radius_limit) or Config.RanchUseDistance
                local allowedDist = math.max(Config.RanchUseDistance, limit)
                if dist < allowedDist and dist < nearestDist then
                    nearest = ranch
                    nearest.coords = coords
                    nearestDist = dist
                end
            end
        end
        if not nearest and Config.AllowAnywhereTesting then
            nearest = {
                ranchid = 0,
                ranchname = 'Horse Breeding Test Ranch',
                coords = pcoords,
                hbZone = { center = vecToTable(pcoords), radius = 9999.0, points = {} }
            }
            notify('Horse breeding test mode: no BCC ranch found, opening temporary ranch menu here.')
        end
        cb(nearest)
    end)
end



local breedingBlips = {}

local function clearBreedingBlips()
    for _, blip in ipairs(breedingBlips) do
        pcall(function()
            if blip.Remove then blip:Remove() end
        end)
        pcall(function()
            if blip.rawblip then BccUtils.Blips:RemoveBlip(blip.rawblip) end
        end)
        pcall(function()
            if type(blip) == 'number' then RemoveBlip(blip) end
        end)
    end
    breedingBlips = {}
end

local function createBreedingBlip(ranch)
    if not Config.ShowBreedingBlips then return end
    local coords = getRanchCenter(ranch)
    if not coords then return end
    local name = (ranch.ranchname or 'Ranch') .. ' Horse Breeding'

    local created = nil
    pcall(function()
        if BccUtils.Blips and BccUtils.Blips.SetBlip then
            created = BccUtils.Blips:SetBlip(name, Config.BreedingBlipSprite or 'blip_horse', Config.BreedingBlipScale or 0.2, coords.x, coords.y, coords.z)
        elseif BccUtils.Blip and BccUtils.Blip.SetBlip then
            created = BccUtils.Blip:SetBlip(name, Config.BreedingBlipSprite or 'blip_horse', Config.BreedingBlipScale or 0.2, coords.x, coords.y, coords.z)
        end
    end)

    if created then
        pcall(function()
            if Config.BreedingBlipColorModifier and BccUtils.Blips and BccUtils.Blips.AddBlipModifier then
                local modifier = BccUtils.Blips:AddBlipModifier(created, Config.BreedingBlipColorModifier)
                if modifier and modifier.ApplyModifier then modifier:ApplyModifier() end
            end
        end)
        breedingBlips[#breedingBlips+1] = created
    end
end

local function refreshBreedingBlips()
    clearBreedingBlips()
    BccUtils.RPC:Call('bcc-horsebreeding:GetMyRanches', {}, function(ranches)
        for _, ranch in ipairs(ranches or {}) do
            ranch.hbZone = decodeBreedingZone(ranch.horsebreeding_zone)
            -- Only show horse breeding blips for ranches that have saved horse-breeding setup.
            if ranch.hbZone and ranch.hbZone.center then
                createBreedingBlip(ranch)
            end
        end
    end)
end

RegisterNetEvent('vorp:SelectedCharacter')
AddEventHandler('vorp:SelectedCharacter', function()
    Wait(3000)
    refreshBreedingBlips()
end)

local function addBack(page, fn)
    page:RegisterElement('button', { label = 'Back', style = {} }, fn)
    page:RegisterElement('button', { label = 'Close', style = {} }, function() HBMenu:Close() end)
end

local function OpenMainMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:main')
    page:RegisterElement('header', { value = Config.Text.menuTitle, slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = 'Portable ranch: ' .. tostring(ranch.ranchname or 'Temporary Horse Breeding Ranch'), slot = 'content', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })

    page:RegisterElement('button', { label = 'Register Horses', style = {} }, function()
        OpenRegisterHorseMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Breed Registered Horses', style = {} }, function()
        OpenBreedMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Set Foal Care Locations', style = {} }, function()
        OpenCareSetupMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Horse Chores', style = {} }, function()
        OpenChoreFoalSelectMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Foal & Mare Stats', style = {} }, function()
        OpenStatsMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Buy Ranch Supplies', style = {} }, function()
        OpenRanchSuppliesMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Spawn Foal', style = {} }, function()
        OpenSpawnFoalSelectMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Spawn Pregnant Mare', style = {} }, function()
        OpenSpawnMareSelectMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Despawn Mare', style = {} }, function()
        DespawnMares()
        OpenMainMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Add Adult Horse To Stables', style = {} }, function()
        OpenAddAdultHorseToStablesMenu(ranch)
    end)

    page:RegisterElement('button', { label = 'Despawn Foal', style = {} }, function()
        DespawnFoal()
        OpenMainMenu(ranch)
    end)

    page:RegisterElement('line', { slot = 'content', style = {} })
    page:RegisterElement('button', { label = 'Pack Up Breeding Ranch', style = {} }, function()
        PackUpBreedingRanch()
        HBMenu:Close()
    end)

    page:RegisterElement('button', { label = 'Close', style = {} }, function() HBMenu:Close() end)
    HBMenu:Open({ startupPage = page })
end

function OpenRegisterHorseMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:register')
    page:RegisterElement('header', { value = 'Register Horse', slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = 'This links an owned BCC Stables horse to this ranch for breeding.', slot = 'content', style = {} })
    BccUtils.RPC:Call('bcc-horsebreeding:GetMyHorses', {}, function(horses)
        if not horses or #horses == 0 then
            page:RegisterElement('textdisplay', { value = Config.Text.noHorses, slot = 'content', style = {} })
        else
            for _, horse in ipairs(horses) do
                local label = ('%s [%s] %s'):format(horse.name or 'Horse', horse.gender or '?', horse.selected == 1 and '(selected)' or '')
                page:RegisterElement('button', { label = label, style = {} }, function()
                    BccUtils.RPC:Call('bcc-horsebreeding:RegisterHorseAtRanch', { ranchId = ranch.ranchid, horseId = horse.id }, function(success)
                        if success then OpenMainMenu(ranch) else notify(Config.Text.failed) end
                    end)
                end)
            end
        end
        addBack(page, function() OpenMainMenu(ranch) end)
        HBMenu:Open({ startupPage = page })
    end)
end

function OpenBreedMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:breed')
    local selectedMare, selectedStallion = nil, nil
    page:RegisterElement('header', { value = 'Breed Horses', slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = 'Pick a female/mare and a male/stallion registered at this ranch.', slot = 'content', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })

    BccUtils.RPC:Call('bcc-horsebreeding:GetRanchHorses', { ranchId = ranch.ranchid }, function(horses)
        local mares, stallions = {}, {}
        for _, h in ipairs(horses or {}) do
            if h.gender == 'female' and h.status == 'ready' then mares[#mares+1] = h end
            if h.gender == 'male' and h.status == 'ready' then stallions[#stallions+1] = h end
        end

        local function horseLabel(h)
            return tostring((h and h.name) or 'Unnamed Horse')
        end

        local function notifyReadyIfBoth()
            if selectedMare and selectedStallion then
                notify('Mare and stallion selected. Ready to breed.')
            end
        end

        page:RegisterElement('textdisplay', { value = 'Mares', slot = 'content', style = {} })
        if #mares == 0 then
            page:RegisterElement('textdisplay', { value = 'No ready mares registered here.', slot = 'content', style = {} })
        end
        for _, h in ipairs(mares) do
            page:RegisterElement('button', { label = horseLabel(h), style = {} }, function()
                selectedMare = h.id
                notify('Mare selected: ' .. horseLabel(h))
                notifyReadyIfBoth()
            end)
        end
        page:RegisterElement('line', { slot = 'content', style = {} })
        page:RegisterElement('textdisplay', { value = 'Stallions', slot = 'content', style = {} })
        if #stallions == 0 then
            page:RegisterElement('textdisplay', { value = 'No ready stallions registered here.', slot = 'content', style = {} })
        end
        for _, h in ipairs(stallions) do
            page:RegisterElement('button', { label = horseLabel(h), style = {} }, function()
                selectedStallion = h.id
                notify('Stallion selected: ' .. horseLabel(h))
                notifyReadyIfBoth()
            end)
        end
        page:RegisterElement('line', { slot = 'content', style = {} })
        page:RegisterElement('button', { label = 'Start Breeding', style = {} }, function()
            if not selectedMare or not selectedStallion then return notify('Select one mare and one stallion first.') end
            BccUtils.RPC:Call('bcc-horsebreeding:BreedHorses', { ranchId = ranch.ranchid, mareId = selectedMare, stallionId = selectedStallion }, function(result)
                local success = result == true or (type(result) == 'table' and result.success == true)
                local message = type(result) == 'table' and result.message or nil
                if success then
                    notify(message or 'Breeding started. Mare pregnancy saved.')
                    OpenFoalMenu(ranch)
                else
                    notify(message or Config.Text.failed)
                end
            end)
        end)
        addBack(page, function() OpenMainMenu(ranch) end)
        HBMenu:Open({ startupPage = page })
    end)
end

local function stageText(foal)
    if foal.stage == 'pregnancy' then
        local left = math.max(0, tonumber(foal.pregnancy_end or 0) - GetCloudTimeAsInt())
        return 'Pregnant / birth in about ' .. tostring(math.floor(left / 60)) .. ' min'
    end
    return tostring(foal.stage)
end

function OpenFoalMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:foals')
    page:RegisterElement('header', { value = 'Foals and Care', slot = 'header', style = {} })
    BccUtils.RPC:Call('bcc-horsebreeding:GetFoals', { ranchId = ranch.ranchid }, function(foals)
        if not foals or #foals == 0 then
            page:RegisterElement('textdisplay', { value = 'No pregnancies or foals yet.', slot = 'content', style = {} })
        else
            for _, f in ipairs(foals) do
                local label = ('%s %s [%s] H:%s W:%s C:%s'):format(foalLabel(f), stageText(f), f.gender, f.hunger, f.thirst, f.cleanliness)
                page:RegisterElement('button', { label = label, style = {} }, function()
                    OpenSingleFoalMenu(ranch, f)
                end)
            end
        end
        addBack(page, function() OpenMainMenu(ranch) end)
        HBMenu:Open({ startupPage = page })
    end)
end

function OpenSingleFoalMenu(ranch, foal)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:foal:' .. tostring(foal.id))
    local newName = ''
    page:RegisterElement('header', { value = foalLabel(foal), slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = ('Stage: %s | Gender: %s | Model: %s'):format(stageText(foal), foal.gender, foal.model), slot = 'content', style = {} })
    page:RegisterElement('textdisplay', { value = ('Mother: %s | Father: %s'):format(foal.mother_name or '?', foal.father_name or '?'), slot = 'content', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })

    page:RegisterElement('button', { label = 'Horse chores / tasks', style = {} }, function()
        OpenChoreMenu(ranch, foal)
    end)

    page:RegisterElement('line', { slot = 'content', style = {} })
    page:RegisterElement('input', { label = 'Adult horse name', placeholder = 'Name when claimed', style = {} }, function(data)
        newName = data.value
    end)
    page:RegisterElement('button', { label = 'Claim adult into BCC Stables', style = {} }, function()
        BccUtils.RPC:Call('bcc-horsebreeding:ClaimFoal', { ranchId = ranch.ranchid, foalId = foal.id, name = newName }, function(success, msg)
            if success then OpenFoalMenu(ranch) else notify(msg or Config.Text.failed) end
        end)
    end)

    addBack(page, function() OpenFoalMenu(ranch) end)
    HBMenu:Open({ startupPage = page })
end


local function getChoreCoords(ranch, chore)
    local zone = ensureZoneLoaded(ranch)
    if chore and chore.key and zone.points and zone.points[chore.key] then
        local p = tableToVector(zone.points[chore.key])
        if p then return p end
    end
    local base = getRanchCenter(ranch)
    if not base then return nil end
    return base + (chore.offset or vector3(0.0, 0.0, 0.0))
end

local function DrawTxt3D(x, y, z, text)
    local onScreen, sx, sy = GetScreenCoordFromWorldCoord(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextColor(255, 255, 255, 215)
        SetTextCentre(true)
        DisplayText(CreateVarString(10, 'LITERAL_STRING', text), sx, sy)
    end
end

local activeChoreProps = {}

local function cleanupChoreProps()
    for _, obj in ipairs(activeChoreProps) do
        if obj and DoesEntityExist(obj) then
            DeleteObject(obj)
        end
    end
    activeChoreProps = {}
end

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        cleanupChoreProps()
        if cleanupResupplyJob then cleanupResupplyJob(0) end
    end
end)

local function isInBlockedTown(coords)
    if Config.BlockHorseTasksInTowns == false then return false, nil end
    local fallbackRadius = tonumber(Config.BlockedTownRadius) or 250.0
    for _, town in ipairs(Config.BlockedTowns or {}) do
        if town.coords then
            local radius = tonumber(town.radius) or fallbackRadius
            if #(coords - town.coords) <= radius then
                return true, town.name or 'town'
            end
        end
    end
    return false, nil
end

local function rotateOffset(offset, heading)
    local rad = math.rad(heading or 0.0)
    local cosH, sinH = math.cos(rad), math.sin(rad)
    return vector3(
        offset.x * cosH - offset.y * sinH,
        offset.x * sinH + offset.y * cosH,
        offset.z or 0.0
    )
end

local function loadObjectModel(prop)
    local hash = prop.hash or joaat(prop.model)
    if not IsModelValid(hash) then
        dprint('invalid prop model: ' .. tostring(prop.model))
        return nil
    end
    RequestModel(hash)
    local timeout = GetGameTimer() + 7000
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do Wait(50) end
    if not HasModelLoaded(hash) then
        dprint('failed to load prop model: ' .. tostring(prop.model))
        return nil
    end
    return hash
end


local function snapToGround(pos)
    local groundZ = nil
    for _, height in ipairs({ 25.0, 15.0, 8.0, 3.0 }) do
        local ok, found, z = pcall(function()
            return GetGroundZFor_3dCoord(pos.x, pos.y, pos.z + height, false)
        end)
        if ok and found and z then
            groundZ = z
            break
        end
        Wait(0)
    end
    if groundZ then return vector3(pos.x, pos.y, groundZ) end
    return vector3(pos.x, pos.y, pos.z - 1.0)
end

local function spawnChoreProps(choreKey, baseCoords, baseHeading)
    cleanupChoreProps()
    if Config.DynamicChoreProps == false then return activeChoreProps end
    local props = Config.ChoreProps and Config.ChoreProps[choreKey]
    if not props then return activeChoreProps end

    for _, prop in ipairs(props) do
        local hash = loadObjectModel(prop)
        if hash then
            local off = rotateOffset(prop.offset or vector3(0.0, 0.0, 0.0), baseHeading)
            local pos = snapToGround(baseCoords + off)
            local obj = CreateObject(hash, pos.x, pos.y, pos.z, false, true, false, false, false)
            if obj and DoesEntityExist(obj) then
                SetEntityAsMissionEntity(obj, true, true)
                SetEntityHeading(obj, (baseHeading + (prop.headingOffset or 0.0)) % 360.0)
                PlaceObjectOnGroundProperly(obj, true)
                Wait(100)
                PlaceObjectOnGroundProperly(obj, true)
                if choreKey == 'cleanpoop' then
                    local oc = GetEntityCoords(obj)
                    local grounded = snapToGround(oc)
                    SetEntityCoords(obj, grounded.x, grounded.y, grounded.z - 0.03, false, false, false, false)
                    PlaceObjectOnGroundProperly(obj, true)
                end
                FreezeEntityPosition(obj, true)
                activeChoreProps[#activeChoreProps+1] = obj
            end
            SetModelAsNoLongerNeeded(hash)
        end
    end
    return activeChoreProps
end

local spawnedFoals = {}
local spawnedFoalLabels = {}

local function foalLabelNumber(foal)
    return tonumber(foal and foal.foal_number) or tonumber(foal and foal.display_number) or tonumber(foal and foal.id) or 1
end

local function foalLabel(foal)
    return ('Foal #%s'):format(foalLabelNumber(foal))
end
local spawnedMares = {}


local function joaatSafe(value)
    if type(value) == 'number' then return value end
    return joaat(tostring(value))
end

local function decodeJsonSafe(value)
    if type(value) == 'table' then return value end
    if type(value) ~= 'string' or value == '' then return {} end
    local ok, decoded = pcall(json.decode, value)
    if ok and type(decoded) == 'table' then return decoded end
    return {}
end

local function setHorseMetaTag(ped, rec)
    if not rec or not rec.drawable or not rec.albedo or not rec.normal or not rec.material then return end
    pcall(function()
        Citizen.InvokeNative(0xBC6DF00D7A4A6819, ped, joaatSafe(rec.drawable), joaatSafe(rec.albedo), joaatSafe(rec.normal), joaatSafe(rec.material), rec.palette and joaatSafe(rec.palette) or 0, tonumber(rec.tint0) or 0, tonumber(rec.tint1) or 0, tonumber(rec.tint2) or 0)
    end)
end

local function applyFoalCoalAppearance(ped, foal)
    if not ped or ped == 0 or not DoesEntityExist(ped) or not foal then return end
    local app = decodeJsonSafe(foal.coal_appearance or foal.components)
    if app.buildAHorse then app = app.buildAHorse end
    if app.body then
        for _, key in ipairs({ 'hand', 'head', 'mis2' }) do
            setHorseMetaTag(ped, app.body[key])
        end
    end
    if app.hair then
        for _, item in pairs(app.hair or {}) do
            if type(item) == 'table' then
                if item.assets and type(item.assets) == 'table' then
                    for _, asset in ipairs(item.assets) do setHorseMetaTag(ped, asset) end
                else
                    setHorseMetaTag(ped, item)
                end
            end
        end
    end
    
pcall(function() Citizen.InvokeNative(0xCC8CA3E88256E58F, ped, false, true, true, true, false) end)
end

-- Force a spawned breeding mare to appear as a mare even when the base horse ped
-- or saved Coal appearance defaults to a stallion/body variant.
-- RedM horse gender visuals are handled by metaped variation data, not by the DB
-- label alone, so we aggressively remove common male genital/mis variants and
-- refresh the ped variation after Coal coat data is applied.
local function forceHorseMareVisual(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return end

    -- BCC Stables' actual mare visual switch. This is the part that controls
    -- the visible stud/mare body expression on normal BCC horses.
    pcall(function() Citizen.InvokeNative(0x5653AB26C82938CF, ped, 41611, 1.0) end) -- SetCharExpression

    -- Coal has genital equipment entries. Apply female and remove male as an
    -- extra guard, then refresh variation. Some artifacts ignore this by itself,
    -- so the expression above is still the primary fix.
    local maleGenitals = joaat('horse_equipment_male_genitals')
    local femaleGenitals = joaat('horse_equipment_female_genitals')
    pcall(function() Citizen.InvokeNative(0xD710A5007C2AC539, ped, maleGenitals, 0) end)
    pcall(function() Citizen.InvokeNative(0xD3A7B003ED343FD9, ped, femaleGenitals, true, true, true) end)
    pcall(function() Citizen.InvokeNative(0xCC8CA3E88256E58F, ped, false, true, true, true, false) end) -- UpdatePedVariation
end

local function forceHorseStudVisual(ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return end

    -- Undo the mare expression and apply male genitals for stallion/stud visuals.
    pcall(function() Citizen.InvokeNative(0x5653AB26C82938CF, ped, 41611, 0.0) end) -- SetCharExpression
    local maleGenitals = joaat('horse_equipment_male_genitals')
    local femaleGenitals = joaat('horse_equipment_female_genitals')
    pcall(function() Citizen.InvokeNative(0xD710A5007C2AC539, ped, femaleGenitals, 0) end)
    pcall(function() Citizen.InvokeNative(0xD3A7B003ED343FD9, ped, maleGenitals, true, true, true) end)
    pcall(function() Citizen.InvokeNative(0xCC8CA3E88256E58F, ped, false, true, true, true, false) end) -- UpdatePedVariation
end

local function forceHorseGenderVisual(ped, gender)
    if tostring(gender or '') == 'female' then
        forceHorseMareVisual(ped)
    else
        forceHorseStudVisual(ped)
    end
end

local function enforceHorseGenderVisualForAWhile(ped, gender)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return end
    CreateThread(function()
        -- Coal/BCC appearance updates can fire a little after the ped is created
        -- and can overwrite the sex expression. Re-apply for a few seconds so
        -- the final rendered horse matches its DB gender.
        for _ = 1, 8 do
            if not ped or ped == 0 or not DoesEntityExist(ped) then return end
            forceHorseGenderVisual(ped, gender)
            Wait(500)
        end
    end)
end

local function enforceMareVisualForAWhile(ped)
    enforceHorseGenderVisualForAWhile(ped, 'female')
end

local function getSpawnedFoalPed(foalId)
    local entry = spawnedFoals and spawnedFoals[tonumber(foalId)]
    if entry and DoesEntityExist(entry) then return entry end
    return nil
end

local function getSpawnedMarePed(pregnancyId)
    local entry = spawnedMares and spawnedMares[tonumber(pregnancyId)]
    if entry and DoesEntityExist(entry) then return entry end
    return nil
end

local function getNearestSpawnedMareEntry(radius)
    local playerPed = PlayerPedId()
    local pcoords = GetEntityCoords(playerPed)
    local bestId, bestPed, bestDist = nil, nil, tonumber(radius) or 4.0
    for pregnancyId, ped in pairs(spawnedMares or {}) do
        if ped and DoesEntityExist(ped) then
            local dist = #(pcoords - GetEntityCoords(ped))
            if dist <= bestDist then
                bestId, bestPed, bestDist = pregnancyId, ped, dist
            end
        end
    end
    return bestId, bestPed
end

local function countSpawnedFoals()
    local count = 0
    for id, ped in pairs(spawnedFoals or {}) do
        if ped and DoesEntityExist(ped) then
            count = count + 1
        else
            spawnedFoals[id] = nil
        end
    end
    return count
end

local function getMaxActiveFoals()
    return tonumber(Config.MaxActiveFoals) or 3
end

local function isHorsePed(entity)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return false end
    if IsPedAPlayer(entity) or IsPedHuman(entity) then return false end

    -- Always trust foals spawned by this resource.
    if spawnedFoals then
        for _, foalPed in pairs(spawnedFoals) do
            if foalPed == entity then return true end
        end
    end

    -- RDR native: IS_THIS_MODEL_A_HORSE. Kept protected so odd artifacts do not error.
    local ok, result = pcall(function()
        return Citizen.InvokeNative(0x772A1969F649E902, GetEntityModel(entity), Citizen.ResultAsInteger())
    end)
    return ok and result == 1
end

local function getNearestHorsePedToPlayer(maxDist)
    local ped = PlayerPedId()
    local pcoords = GetEntityCoords(ped)
    local nearest, nearestDist = nil, maxDist or 4.0

    -- First prefer the breeding foal if it is close.
    if spawnedFoals then
        for _, horsePed in pairs(spawnedFoals) do
            if horsePed and DoesEntityExist(horsePed) then
                local dist = #(pcoords - GetEntityCoords(horsePed))
                if dist < nearestDist then
                    nearest = horsePed
                    nearestDist = dist
                end
            end
        end
    end

    -- If the foal targeting is weird, allow the brush animation on any nearby horse.
    -- Stats still save to the selected breeding foal; this only fixes the animation target.
    for _, entity in ipairs(GetGamePool('CPed') or {}) do
        if entity ~= ped and isHorsePed(entity) then
            local dist = #(pcoords - GetEntityCoords(entity))
            if dist < nearestDist then
                nearest = entity
                nearestDist = dist
            end
        end
    end

    return nearest, nearestDist
end

local function getNearestSpawnedFoalEntry(maxDist)
    local ped = PlayerPedId()
    local pcoords = GetEntityCoords(ped)
    local nearestId, nearestPed, nearestDist = nil, nil, maxDist or 4.0
    if spawnedFoals then
        for foalId, horsePed in pairs(spawnedFoals) do
            if horsePed and DoesEntityExist(horsePed) then
                local dist = #(pcoords - GetEntityCoords(horsePed))
                if dist < nearestDist then
                    nearestId = tonumber(foalId)
                    nearestPed = horsePed
                    nearestDist = dist
                end
            end
        end
    end
    return nearestId, nearestPed, nearestDist
end

local function playAnimalBrushInteraction(horsePed, duration)
    local ped = PlayerPedId()
    if not horsePed or not DoesEntityExist(horsePed) then return false end

    local distance = #(GetEntityCoords(ped) - GetEntityCoords(horsePed))
    if distance > 3.5 then
        notify('Stand beside a horse to brush it.')
        return false
    end

    -- BCC Stables does not turn the player first or clear the horse task first.
    -- Matching that path makes the actual brush animation far more reliable.
    ClearPedTasks(ped)

    local started = pcall(function()
        Citizen.InvokeNative(0xCD181A959CFDD7F4, ped, horsePed, `Interaction_Brush`, `p_brushHorse02x`, true)
    end)
    if not started then return false end

    Wait(duration or 5000)

    pcall(function() Citizen.InvokeNative(0x6585D955A68452A5, horsePed) end) -- ClearPedEnvDirt
    pcall(function() Citizen.InvokeNative(0x523C79AEEFCC4A2A, horsePed, 10, 'ALL') end) -- ClearPedDamageDecalByZone
    pcall(function() Citizen.InvokeNative(0x8FE22675A5A45817, horsePed) end) -- ClearPedBloodDamage
    pcall(function() ClearPedWetness(horsePed) end)
    ClearPedTasks(ped)
    return true
end

local function playAnimalFeedInteraction(horsePed, duration, snackModel)
    local ped = PlayerPedId()
    if not horsePed or not DoesEntityExist(horsePed) then return false end

    local distance = #(GetEntityCoords(ped) - GetEntityCoords(horsePed))
    if distance > 3.5 then
        notify('Stand beside a horse to feed it.')
        return false
    end

    -- Match BCC Stables exactly. Do not force-turn first; that can cancel the animal interaction.
    ClearPedTasks(ped)

    local started = pcall(function()
        Citizen.InvokeNative(0xCD181A959CFDD7F4, ped, horsePed, `Interaction_Food`, `s_horsnack_haycube01x`, true)
    end)
    if not started then return false end

    Wait(duration or 5000)
    pcall(function() Citizen.InvokeNative(0x67C540AA08E4A6F5, 'Core_Fill_Up', 'Consumption_Sounds', true, 0) end)
    ClearPedTasks(ped)
    return true
end

local function startGroundworkLead(horsePed, choreCoords, radius, duration)
    local ped = PlayerPedId()
    local finish = GetGameTimer() + duration
    if horsePed and DoesEntityExist(horsePed) then
        ClearPedTasks(horsePed)
        SetBlockingOfNonTemporaryEvents(horsePed, true)
    end

    while GetGameTimer() < finish do
        Wait(0)
        local pcoords = GetEntityCoords(ped)
        if #(pcoords - choreCoords) > radius then
            if horsePed and DoesEntityExist(horsePed) then ClearPedTasks(horsePed) end
            return false
        end

        if horsePed and DoesEntityExist(horsePed) then
            local hcoords = GetEntityCoords(horsePed)
            local dist = #(pcoords - hcoords)
            if dist > 3.0 then
                TaskGoToEntity(horsePed, ped, 1500, 2.0, 1.1, 0, 0)
            end
        end
        DrawTxt3D(pcoords.x, pcoords.y, pcoords.z + 1.0, 'Groundwork - keep the horse with you: ' .. tostring(math.ceil((finish - GetGameTimer()) / 1000)) .. 's')
    end
    if horsePed and DoesEntityExist(horsePed) then ClearPedTasks(horsePed) end
    return true
end

local attachedChoreTools = {}

local function cleanupToolPropsNearPlayer()
    -- Cleanup temporary tool props that scenarios/animations can leave in hand or next to the player.
    local ped = PlayerPedId()
    local pcoords = GetEntityCoords(ped)
    local toolNames = Config.ChoreToolPropsToCleanup or { 'p_bucket03x', 'p_bucket01x', 'p_pitchfork01x', 'p_hayfork01x', 'p_rake01x', 'p_rake02x' }
    local toolHashes = {}
    for _, name in ipairs(toolNames) do toolHashes[joaat(name)] = true end

    for _, obj in ipairs(attachedChoreTools or {}) do
        if obj and DoesEntityExist(obj) then
            DetachEntity(obj, true, true)
            SetEntityAsMissionEntity(obj, true, true)
            DeleteObject(obj)
            DeleteEntity(obj)
        end
    end
    attachedChoreTools = {}

    for _, obj in ipairs(GetGamePool('CObject') or {}) do
        if obj and DoesEntityExist(obj) then
            local model = GetEntityModel(obj)
            local dist = #(pcoords - GetEntityCoords(obj))
            if toolHashes[model] and (dist < 8.0 or IsEntityAttachedToEntity(obj, ped)) then
                DetachEntity(obj, true, true)
                SetEntityAsMissionEntity(obj, true, true)
                DeleteObject(obj)
                DeleteEntity(obj)
            end
        end
    end
end

local function requestAnimDict(dict)
    RequestAnimDict(dict)
    local timeout = GetGameTimer() + 7000
    while not HasAnimDictLoaded(dict) and GetGameTimer() < timeout do Wait(50) end
    return HasAnimDictLoaded(dict)
end


local function restoreAllPlayerControls()
    -- RedM does not expose EnableAllControlActions on every artifact/build.
    -- Use it only when present, otherwise safely re-enable the common control groups.
    if type(EnableAllControlActions) == 'function' then
        pcall(function() EnableAllControlActions(0) end)
        pcall(function() EnableAllControlActions(1) end)
        pcall(function() EnableAllControlActions(2) end)
        return
    end

    if type(EnableControlAction) == 'function' then
        for group = 0, 2 do
            for control = 0, 359 do
                pcall(function() EnableControlAction(group, control, true) end)
            end
        end
    end
end

local function playAttachedToolAnim(animDict, animName, duration, propModel, attach)
    local ped = PlayerPedId()
    cleanupToolPropsNearPlayer()
    if not requestAnimDict(animDict) then return false end

    local obj = nil
    if propModel then
        local hash = joaat(propModel)
        RequestModel(hash)
        local timeout = GetGameTimer() + 7000
        while not HasModelLoaded(hash) and GetGameTimer() < timeout do Wait(50) end
        if HasModelLoaded(hash) then
            local coords = GetEntityCoords(ped)
            obj = CreateObject(hash, coords.x, coords.y, coords.z, true, true, false)
            if obj and DoesEntityExist(obj) then
                SetEntityAsMissionEntity(obj, true, true)
                local bone = GetEntityBoneIndexByName(ped, (attach and attach.bone) or 'PH_R_Hand')
                AttachEntityToEntity(obj, ped, bone,
                    (attach and attach.x) or 0.0, (attach and attach.y) or 0.0, (attach and attach.z) or 0.19,
                    (attach and attach.rx) or 0.0, (attach and attach.ry) or 0.0, (attach and attach.rz) or 0.0,
                    false, false, true, false, 0, true, false, false)
                attachedChoreTools[#attachedChoreTools + 1] = obj
            end
            SetModelAsNoLongerNeeded(hash)
        end
    end

    TaskPlayAnim(ped, animDict, animName, 1.0, 1.0, duration, 16, 0, true, 0, false, 0, false)
    Wait(duration)
    pcall(function() ClearPedTasks(ped) end)
    pcall(function() ClearPedSecondaryTask(ped) end)
    Wait(50)
    pcall(function() ClearPedTasksImmediately(ped) end)
    cleanupToolPropsNearPlayer()
    restoreAllPlayerControls()
    return true
end

local function restorePlayerAfterChore()
    local ped = PlayerPedId()

    -- Scenarios in RedM can leave the player in a soft-locked interaction state
    -- even after the prop is deleted. Force clear both normal and secondary tasks,
    -- then repeat cleanup a few frames later so scrollwheel/weapon wheel comes back.
    pcall(function() ClearPedTasks(ped) end)
    pcall(function() ClearPedSecondaryTask(ped) end)
    Wait(50)
    pcall(function() ClearPedTasksImmediately(ped) end)
    pcall(function() ClearPedSecondaryTask(ped) end)
    pcall(function() Citizen.InvokeNative(0xAAA34F8A7CB32098, ped) end) -- CLEAR_PED_TASKS

    cleanupToolPropsNearPlayer()

    -- Nudge the ped fully back to player control. These are safe no-ops on builds
    -- where a native is unavailable.
    pcall(function() FreezeEntityPosition(ped, false) end)
    pcall(function() SetPedCanPlayGestureAnims(ped, true) end)
    pcall(function() SetPedCanPlayAmbientAnims(ped, true) end)
    pcall(function() SetCurrentPedWeapon(ped, joaat('WEAPON_UNARMED'), true, 0, false, false) end)

    restoreAllPlayerControls()
    Wait(250)
    cleanupToolPropsNearPlayer()
    restoreAllPlayerControls()
end


local function doHaySpreadChore(label, duration, scenario, choreCoords, radius)
    local ped = PlayerPedId()
    cleanupToolPropsNearPlayer()

    -- Match the old working hay behavior: start the scenario with -1 so RedM
    -- lets WORLD_HUMAN_PITCH_HAY_SPREAD reach the shake/scatter phase naturally.
    -- The countdown below controls when we clean it up.
    TaskStartScenarioInPlace(ped, joaat(scenario), -1, true, false, false, false)

    local finish = GetGameTimer() + duration
    local cancelled = false
    while GetGameTimer() < finish do
        Wait(0)
        local pcoords = GetEntityCoords(ped)
        if #(pcoords - choreCoords) > radius then
            cancelled = true
            break
        end
        local left = math.ceil((finish - GetGameTimer()) / 1000)
        DrawTxt3D(choreCoords.x, choreCoords.y, choreCoords.z + 1.0, label .. ': ' .. tostring(left) .. 's')
    end

    restorePlayerAfterChore()
    return not cancelled
end

local function doTimedChore(label, duration, scenario, choreCoords, radius, isGroundwork, noTimer)
    local ped = PlayerPedId()
    local cancelled = false

    if scenario then
        TaskStartScenarioInPlace(ped, joaat(scenario), -1, true, false, false, false)
        if noTimer then
            -- Hay works best as a very short visible countdown: the animation starts,
            -- runs for about a second, then we hard-clear the scenario so the player
            -- is not stuck and the scrollwheel returns.
            local finish = GetGameTimer() + (Config.HayShortCountdownMs or 1000)
            while GetGameTimer() < finish do
                Wait(0)
                local c = GetEntityCoords(ped)
                DrawTxt3D(choreCoords.x, choreCoords.y, choreCoords.z + 1.0, label .. ': 1s')
                if #(c - choreCoords) > radius then
                    restorePlayerAfterChore()
                    return false
                end
            end
            restorePlayerAfterChore()
            return true
        end
        -- Let the scenario animation begin before countdown, but do not wait so long
        -- that the player gets trapped in the scenario after the chore is done.
        Wait(Config.ChoreAnimationStartDelayMs or 750)
    end

    local finish = GetGameTimer() + duration
    while GetGameTimer() < finish do
        Wait(0)
        local pcoords = GetEntityCoords(ped)
        local dist = #(pcoords - choreCoords)
        if dist > radius then
            cancelled = true
            break
        end
        local left = math.ceil((finish - GetGameTimer()) / 1000)
        if isGroundwork then
            DrawTxt3D(pcoords.x, pcoords.y, pcoords.z + 1.0, label .. ' - keep leading/walking: ' .. tostring(left) .. 's')
        else
            DrawTxt3D(choreCoords.x, choreCoords.y, choreCoords.z + 1.0, label .. ': ' .. tostring(left) .. 's')
        end
    end

    restorePlayerAfterChore()
    return not cancelled
end


local function PrecheckHorseChore(ranch, foal, choreKey, cb)
    BccUtils.RPC:Call('bcc-horsebreeding:CanDoHorseChore', { ranchId = ranch.ranchid, foalId = foal.id, chore = choreKey }, function(ok, msg)
        if not ok then
            notify(msg or Config.Text.failed)
            cb(false)
            return
        end
        cb(true)
    end)
end

function StartHorseChore(ranch, foal, choreKey)
    local chore = Config.Chores[choreKey]
    if not chore then return notify(Config.Text.failed) end
    chore.key = choreKey
    local zone = ensureZoneLoaded(ranch)
    if not zone.points or not zone.points[choreKey] then
        notify(Config.Text.choreLocationNeeded or 'Set this chore location first.')
        return OpenCareSetupMenu(ranch)
    end

    local coords = tableToVector(zone.points[choreKey])
    if not coords then return notify(Config.Text.choreLocationNeeded or 'Set this chore location first.') end
    local ped = PlayerPedId()
    local pcoords = GetEntityCoords(ped)
    local blocked, townName = isInBlockedTown(coords)
    if blocked then
        return notify((Config.Text.townBlocked or 'You cannot do horse breeding chores in town.') .. ' (' .. tostring(townName) .. ')')
    end
    local radius = tonumber(chore.radius) or 4.0
    if #(pcoords - coords) > radius then
        return notify(Config.Text.tooFarFromChore or 'You are too far from that chore spot.')
    end

    PrecheckHorseChore(ranch, foal, choreKey, function(canStart)
        if not canStart then return end

        HBMenu:Close()
        
        local horsePed = getSpawnedFoalPed(foal.id)
    if not horsePed then horsePed = getNearestHorsePedToPlayer(5.0) end
    if horsePed and DoesEntityExist(horsePed) then
        if choreKey == 'hay' then
            TaskStartScenarioInPlace(horsePed, joaat('WORLD_ANIMAL_HORSE_GRAZING_DOMESTIC'), tonumber(chore.duration) or 8000, true, false, false, false)
        elseif choreKey == 'water' then
            TaskStartScenarioInPlace(horsePed, joaat('PROP_ANIMAL_HORSE_DRINK_TROUGH'), tonumber(chore.duration) or 8000, true, false, false, false)
        end
    end

    local choreDuration = tonumber(chore.duration) or 8000
    local ok
    if choreKey == 'water' then
        -- Water is working correctly; keep the same BCC Ranch-style scenario path.
        ok = doTimedChore(chore.label, choreDuration, chore.scenario or 'WORLD_HUMAN_BUCKET_POUR_LOW', coords, radius, false, false)
    elseif choreKey == 'cleanpoop' then
        -- Cleaning is working correctly; keep the BCC Ranch/Farming rake animation path.
        ok = playAttachedToolAnim('amb_work@world_human_farmer_rake@male_a@idle_a', 'idle_a', choreDuration, Config.CleaningRakeProp or 'p_rake02x', Config.CleaningRakeAttach)
    elseif choreKey == 'hay' then
        -- Feed hay now uses the same attached rake animation path as cleaning,
        -- because that path is stable and does not leave the scrollwheel locked.
        ok = playAttachedToolAnim('amb_work@world_human_farmer_rake@male_a@idle_a', 'idle_a', choreDuration, Config.CleaningRakeProp or 'p_rake02x', Config.CleaningRakeAttach)
    else
        ok = doTimedChore(chore.label, choreDuration, chore.scenario, coords, radius, false, false)
    end
    if horsePed and DoesEntityExist(horsePed) then ClearPedTasks(horsePed) end
    restorePlayerAfterChore()
    if not ok then return notify(Config.Text.choreCancelled) end

        BccUtils.RPC:Call('bcc-horsebreeding:DoHorseChore', { ranchId = ranch.ranchid, foalId = foal.id, chore = choreKey }, function(success, updated, msg)
            if success then
                notifyGain(updated and updated.message or ('Increased ' .. chore.label), updated)
            else
                notify(msg or Config.Text.failed)
            end
        end)
    end)
end

function BrushSpawnedFoal(ranch, foal)
    local horsePed = getSpawnedFoalPed(foal.id)
    if not horsePed then horsePed = getNearestHorsePedToPlayer(4.0) end
    if not horsePed then return notify('Spawn the foal first, then stand beside it to brush.') end
    HBMenu:Close()
    local ok = playAnimalBrushInteraction(horsePed, 5000)
    if not ok then return notify(Config.Text.choreCancelled) end
    BccUtils.RPC:Call('bcc-horsebreeding:DoHorseChore', { ranchId = ranch.ranchid, foalId = foal.id, chore = 'brush' }, function(success, updated)
        if success then
            notifyGain('Brushing complete', updated)
        else
            notify(Config.Text.failed)
        end
    end)
end

local ensurePortableRanch -- forward declaration for item handlers

function FeedSpawnedFoal(ranch, foal, feedType)
    -- Feed animation can target any nearby horse, like brush.
    -- Breeding stats still save to the selected/spawned foal record below.
    local horsePed = getNearestHorsePedToPlayer(4.0)
    if not horsePed then horsePed = getSpawnedFoalPed(foal.id) end
    if not horsePed then return notify('Stand beside a horse to feed it.') end

    local chore = feedType == 'sugarcube' and 'feed_sugarcube' or 'feed_haycube'
    local label = feedType == 'sugarcube' and 'Sugar Cube' or 'Hay Cube'

    PrecheckHorseChore(ranch, foal, chore, function(canStart)
        if not canStart then return end
        HBMenu:Close()
        local ok = playAnimalFeedInteraction(horsePed, 5000, 's_horsnack_haycube01x')
        if not ok then return notify(Config.Text.choreCancelled) end

        BccUtils.RPC:Call('bcc-horsebreeding:DoHorseChore', { ranchId = ranch.ranchid, foalId = foal.id, chore = chore }, function(success, updated, msg)
            if success then
                notifyGain(updated and updated.message or ('Fed ' .. label), updated)
            else
                notify(msg or (Config.Text.failed .. ' Missing item?'))
            end
        end)
    end)
end

RegisterNetEvent('bcc-horsebreeding:UseFoalCareItem', function(kind, itemName)
    -- SHADOWS FIX:
    -- Do NOT require/open/force the breeding ranch unless a breeding foal or mare is actually nearby.
    -- If no breeding animal is close, immediately fall back to BCC Stables so the player's main horse
    -- can be fed/brushed normally.

    local foalId, horsePed = getNearestSpawnedFoalEntry(3.5)
    if foalId and horsePed then
        local ranch = activePortableRanch or ensurePortableRanch()
        if not ranch then return notify('Start your horse breeding ranch first with /horsebreeding.') end

        if kind == 'brush' then
            BrushSpawnedFoal(ranch, { id = foalId })
        elseif kind == 'sugarcube' then
            FeedSpawnedFoal(ranch, { id = foalId }, 'sugarcube')
        else
            FeedSpawnedFoal(ranch, { id = foalId }, 'haycube')
        end
        return
    end

    local pregnancyId, marePed = getNearestSpawnedMareEntry(3.5)
    if pregnancyId and marePed then
        local ranch = activePortableRanch or ensurePortableRanch()
        if not ranch then return notify('Start your horse breeding ranch first with /horsebreeding.') end

        if kind == 'brush' then
            BrushSpawnedMare(ranch, { id = pregnancyId })
        elseif kind == 'sugarcube' then
            FeedSpawnedMare(ranch, { id = pregnancyId }, 'sugarcube')
        else
            FeedSpawnedMare(ranch, { id = pregnancyId }, 'haycube')
        end
        return
    end

    -- No breeding foal/mare nearby: let BCC Stables handle the active/main horse.
    if kind == 'brush' then
        TriggerEvent('bcc-stables:BrushHorse')
    elseif kind == 'sugarcube' or kind == 'haycube' then
        TriggerEvent('bcc-stables:FeedHorse', itemName)
    else
        TriggerEvent('bcc-stables:FeedHorse', itemName)
    end
end)

function OpenChoreFoalSelectMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:choreselect')
    page:RegisterElement('header', { value = 'Horse Chores', slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = 'Pick a foal/young horse/adult ranch-born horse to care for.', slot = 'content', style = {} })
    BccUtils.RPC:Call('bcc-horsebreeding:GetFoals', { ranchId = ranch.ranchid }, function(foals)
        local added = 0
        for _, f in ipairs(foals or {}) do
            if f.stage ~= 'pregnancy' then
                added = added + 1
                local label = ('Foal #%s'):format(added)
                page:RegisterElement('button', { label = label, style = {} }, function()
                    OpenChoreMenu(ranch, f)
                end)
            end
        end
        if added == 0 then
            page:RegisterElement('textdisplay', { value = 'No born foals/horses ready for chores yet.', slot = 'content', style = {} })
        end
        addBack(page, function() OpenMainMenu(ranch) end)
        HBMenu:Open({ startupPage = page })
    end)
end

function OpenChoreMenu(ranch, foal)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:chores:' .. tostring(foal.id))
    page:RegisterElement('header', { value = 'Horse Chores', slot = 'header', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })

    local order = { 'hay', 'water', 'cleanpoop' }
    for _, key in ipairs(order) do
        local chore = Config.Chores[key]
        if chore then
            page:RegisterElement('button', { label = chore.label, style = {} }, function()
                StartHorseChore(ranch, foal, key)
            end)
        end
    end

    addBack(page, function() OpenSingleFoalMenu(ranch, foal) end)
    HBMenu:Open({ startupPage = page })
end



-- Resupply delivery wagon system removed.
-- Ranch supplies are now buyable only through the Buy Ranch Supplies menu.
function CancelAllResupplyDeliveries(silent)
    ClearGpsMultiRoute()
    SetGpsMultiRouteRender(false)
    if not silent then notify('No active delivery.') end
end

function OpenResupplyMenu(ranch)
    OpenRanchSuppliesMenu(ranch)
end

function OpenRanchSuppliesMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:supplies')
    page:RegisterElement('header', { value = 'Ranch Supplies', slot = 'header', style = {} })
    BccUtils.RPC:Call('bcc-horsebreeding:GetRanchSupplies', { ranchId = ranch.ranchid }, function(data)
        local supplies = (data and data.supplies) or 0
        page:RegisterElement('textdisplay', { value = ('Supplies: %s%%'):format(supplies), slot = 'content', style = {} })
        page:RegisterElement('line', { slot = 'content', style = {} })
        page:RegisterElement('button', { label = ('Buy Supplies - Cash $%s'):format(Config.RanchSupplies.CashPrice or 25), style = {} }, function()
            BccUtils.RPC:Call('bcc-horsebreeding:BuyRanchSupplies', { ranchId = ranch.ranchid, currency = 'cash' }, function(success, msg)
                notify(msg or (success and Config.Text.suppliesBought or Config.Text.failed))
                OpenRanchSuppliesMenu(ranch)
            end)
        end)
        page:RegisterElement('button', { label = ('Buy Supplies - Gold %s'):format(Config.RanchSupplies.GoldPrice or 1), style = {} }, function()
            BccUtils.RPC:Call('bcc-horsebreeding:BuyRanchSupplies', { ranchId = ranch.ranchid, currency = 'gold' }, function(success, msg)
                notify(msg or (success and Config.Text.suppliesBought or Config.Text.failed))
                OpenRanchSuppliesMenu(ranch)
            end)
        end)
        addBack(page, function() OpenMainMenu(ranch) end)
        HBMenu:Open({ startupPage = page })
    end)
end

function OpenStatsMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:stats')
    page:RegisterElement('header', { value = 'Mare / Foal Stats', slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = 'Simple status only. Higher foal care/training/bonding helps growth progress faster.', slot = 'content', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })

    BccUtils.RPC:Call('bcc-horsebreeding:GetFoals', { ranchId = ranch.ranchid }, function(foals)
        page:RegisterElement('textdisplay', { value = 'Mares', slot = 'content', style = {} })

        local mareStatus = {}
        for _, f in ipairs(foals or {}) do
            local key = tostring(f.mother_horse_id or f.mother_name or '')
            if key ~= '' then
                local name = f.mother_name or 'Mare'
                if not mareStatus[key] then
                    mareStatus[key] = { name = name, pregnant = false, born = false, due = 0 }
                end
                if f.stage == 'pregnancy' then
                    mareStatus[key].pregnant = true
                    mareStatus[key].due = tonumber(f.pregnancy_end or 0) or 0
                else
                    mareStatus[key].born = true
                end
            end
        end

        local mares = 0
        for _, data in pairs(mareStatus) do
            mares = mares + 1
            local mareLine
            if data.pregnant then
                local left = math.max(0, data.due - GetCloudTimeAsInt())
                mareLine = ('%s: Pregnant - foal due in %s'):format(data.name, formatDueTime(left))
            elseif data.born then
                mareLine = ('%s: Foal born'):format(data.name)
            else
                mareLine = ('%s: Not pregnant'):format(data.name)
            end
            page:RegisterElement('textdisplay', { value = mareLine, slot = 'content', style = {} })
        end
        if mares == 0 then page:RegisterElement('textdisplay', { value = 'No bred mares yet.', slot = 'content', style = {} }) end

        page:RegisterElement('line', { slot = 'content', style = {} })
        page:RegisterElement('textdisplay', { value = 'Foals', slot = 'content', style = {} })
        local born = 0
        for _, f in ipairs(foals or {}) do
            if f.stage ~= 'pregnancy' then
                born = born + 1
                local adultText = 'Adult: ready'
                if f.stage ~= 'adult' then
                    local adultAt = tonumber(f.adult_at or 0) or 0
                    if adultAt > 0 then
                        adultText = 'Adult in ' .. formatDueTime(math.max(0, adultAt - GetCloudTimeAsInt()))
                    else
                        adultText = 'Adult time not set yet'
                    end
                end
                local value = ('#%s %s | Food %s%% | Water %s%% | Clean %s%% | Trained %s%% | Bond %s%% | Manure %s%% | %s'):format(
                    foalLabelNumber(f), f.name or 'Foal', f.hunger or 0, f.thirst or 0, f.cleanliness or 0, f.training or 0, f.bonding or 0, f.manure or 0, adultText
                )
                page:RegisterElement('textdisplay', { value = value, slot = 'content', style = {} })
            end
        end
        if born == 0 then page:RegisterElement('textdisplay', { value = 'No born foals yet.', slot = 'content', style = {} }) end
        addBack(page, function() OpenMainMenu(ranch) end)
        HBMenu:Open({ startupPage = page })
    end)
end


local function loadModel(modelName)
    local hash = joaat(modelName)
    if not IsModelValid(hash) then return nil end
    RequestModel(hash)
    local timeout = GetGameTimer() + 7000
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do Wait(50) end
    if not HasModelLoaded(hash) then return nil end
    return hash
end

function SpawnFoalEntity(ranch, selected)
    if not selected or selected.stage == 'pregnancy' then
        return notify('That foal is not born yet.')
    end

    local selectedId = tonumber(selected.id)
    if selectedId and getSpawnedFoalPed(selectedId) then
        return notify(('%s is already spawned.'):format(foalLabel(selected)))
    end
    if countSpawnedFoals() >= getMaxActiveFoals() then
        return notify(('You can only have %s foals spawned at once. Despawn one first.'):format(getMaxActiveFoals()))
    end

    local hash = loadModel(selected.model or Config.DefaultFoalModel)
    if not hash then return notify('Foal model failed to load.') end
    local spawnIndex = countSpawnedFoals() + 1
    local offsets = Config.FoalSpawnOffsets or { vector3(2.0, 1.5, 0.0), vector3(3.0, -1.0, 0.0), vector3(-2.0, 1.5, 0.0) }
    local offset = offsets[spawnIndex] or vector3(2.0 + spawnIndex, 1.5, 0.0)
    local coords = (ranch.coords or GetEntityCoords(PlayerPedId())) + offset
    coords = snapToGround(coords)
    local ped = CreatePed(hash, coords.x, coords.y, coords.z, GetEntityHeading(PlayerPedId()), false, false, false, false)
    if not ped or not DoesEntityExist(ped) then return notify('Foal spawn failed.') end
    Citizen.InvokeNative(0x283978A15512B2FE, ped, true)
    Citizen.InvokeNative(0x58A850EAEE20FAA3, ped)
    SetEntityAsMissionEntity(ped, true, true)
    SetBlockingOfNonTemporaryEvents(ped, false)
    FreezeEntityPosition(ped, false)
    local scale = tonumber(selected.scale) or (Config.FoalScales and Config.FoalScales[selected.stage]) or 0.9
    pcall(function() Citizen.InvokeNative(0x25ACFC650B65C538, ped, scale) end)
    applyFoalCoalAppearance(ped, selected)
    pcall(function() Citizen.InvokeNative(0x25ACFC650B65C538, ped, scale) end)
    forceHorseGenderVisual(ped, selected.gender)
    enforceHorseGenderVisualForAWhile(ped, selected.gender)
    TaskWanderStandard(ped, 10.0, 10)
    spawnedFoals[selectedId or tonumber(selected.id)] = ped
    spawnedFoalLabels[selectedId or tonumber(selected.id)] = foalLabel(selected)
    notify((Config.Text.foalSpawned or 'Foal spawned at the breeding ranch.') .. ' ' .. foalLabel(selected))
end


function SpawnMareEntity(ranch, mare)
    if not mare or mare.stage ~= 'pregnancy' then return notify('That mare is not pregnant.') end
    local pregnancyId = tonumber(mare.id)
    if pregnancyId and getSpawnedMarePed(pregnancyId) then
        return notify(('Mare for %s is already spawned.'):format(foalLabel(mare)))
    end
    local maxMares = tonumber(Config.MaxActiveMares) or 3
    local current = 0
    for _, ped in pairs(spawnedMares or {}) do if ped and DoesEntityExist(ped) then current = current + 1 end end
    if current >= maxMares then return notify(('You can only have %s pregnant mares spawned at once.'):format(maxMares)) end

    local hash = loadModel(mare.mother_model or mare.model or Config.DefaultFoalModel)
    if not hash then return notify('Mare model failed to load.') end
    local center = getRanchCenter(ranch) or GetEntityCoords(PlayerPedId())
    local offset = (Config.MareSpawnOffset or vector3(-2.5, -1.5, 0.0))
    local coords = snapToGround(center + offset + vector3(current * 1.5, 0.0, 0.0))
    local ped = CreatePed(hash, coords.x, coords.y, coords.z, GetEntityHeading(PlayerPedId()), false, false, false, false)
    if not ped or not DoesEntityExist(ped) then return notify('Mare spawn failed.') end
    Citizen.InvokeNative(0x283978A15512B2FE, ped, true)
    SetEntityAsMissionEntity(ped, true, true)
    SetBlockingOfNonTemporaryEvents(ped, false)
    FreezeEntityPosition(ped, false)

    -- Let Coal/BCC know which original horse this spawned mare represents.
    -- Coal's live apply code can use this state id when matching owned horse visuals.
    if mare.mother_horse_id then
        pcall(function() Entity(ped).state:set('myHorseId', tonumber(mare.mother_horse_id), true) end)
    end

    -- Apply the mare's Coal custom coat/color from player_horses.
    -- Keep tack off in our local fallback: only use coal_appearance/components.
    local mareAppearance = mare.mother_coal_appearance or mare.coal_appearance or mare.mother_components or mare.components
    if mareAppearance and mareAppearance ~= '' and mareAppearance ~= '{}' then
        applyFoalCoalAppearance(ped, { coal_appearance = mareAppearance, components = mare.mother_components or mare.components })
    end

    -- If Coal is running, let it apply the saved custom visuals using its own code path too.
    -- Then keep forcing mare visual for a few seconds because Coal/BCC variation refreshes
    -- can overwrite the mare expression right after spawn.
    if mare.mother_horse_id then
        pcall(function() TriggerEvent('coal_bcc:ApplyToBccEntity', ped, tonumber(mare.mother_horse_id)) end)
    end
    forceHorseMareVisual(ped)
    enforceMareVisualForAWhile(ped)

    TaskWanderStandard(ped, 10.0, 10)
    spawnedMares[pregnancyId] = ped
    notify(('Pregnant mare spawned for %s.'):format(foalLabel(mare)))
end

function OpenSpawnMareSelectMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:spawnmare')
    page:RegisterElement('header', { value = 'Spawn Pregnant Mare', slot = 'header', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })
    BccUtils.RPC:Call('bcc-horsebreeding:GetPregnantMares', { ranchId = ranch.ranchid }, function(mares)
        local count = 0
        for _, m in ipairs(mares or {}) do
            count = count + 1
            local label = tostring(m.mother_name or ('Mare #' .. count))
            page:RegisterElement('button', { label = label, style = {} }, function()
                SpawnMareEntity(ranch, m)
                OpenMainMenu(ranch)
            end)
        end
        if count == 0 then
            page:RegisterElement('textdisplay', { value = 'No pregnant mares ready to spawn.', slot = 'content', style = {} })
        end
        addBack(page, function() OpenMainMenu(ranch) end)
        HBMenu:Open({ startupPage = page })
    end)
end

function DespawnMares()
    local count = 0
    for _, ped in pairs(spawnedMares or {}) do
        if ped and DoesEntityExist(ped) then DeletePed(ped); count = count + 1 end
    end
    spawnedMares = {}
    notify(count > 0 and 'Pregnant mare despawned.' or 'No pregnant mare is spawned.')
end

function BrushSpawnedMare(ranch, mare)
    local marePed = getSpawnedMarePed(mare.id)
    if not marePed then marePed = getNearestHorsePedToPlayer(4.0) end
    if not marePed then return notify('Spawn the pregnant mare first, then stand beside her to brush.') end
    HBMenu:Close()
    local ok = playAnimalBrushInteraction(marePed, 5000)
    if not ok then return notify(Config.Text.choreCancelled) end
    BccUtils.RPC:Call('bcc-horsebreeding:DoMareCare', { ranchId = ranch.ranchid, pregnancyId = mare.id, action = 'brush' }, function(success, msg)
        notify(msg or (success and 'Mare care increased. Foaling time reduced.' or Config.Text.failed))
    end)
end

function FeedSpawnedMare(ranch, mare, feedType)
    local marePed = getNearestHorsePedToPlayer(4.0)
    if not marePed then marePed = getSpawnedMarePed(mare.id) end
    if not marePed then return notify('Stand beside the pregnant mare to feed her.') end
    local action = feedType == 'sugarcube' and 'feed_sugarcube' or 'feed_haycube'
    HBMenu:Close()
    local ok = playAnimalFeedInteraction(marePed, 5000, 's_horsnack_haycube01x')
    if not ok then return notify(Config.Text.choreCancelled) end
    BccUtils.RPC:Call('bcc-horsebreeding:DoMareCare', { ranchId = ranch.ranchid, pregnancyId = mare.id, action = action }, function(success, msg)
        notify(msg or (success and 'Mare treat given. Foaling time reduced.' or Config.Text.failed))
    end)
end

function OpenSpawnFoalSelectMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:spawnselect')
    page:RegisterElement('header', { value = 'Spawn Foal', slot = 'header', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })

    BccUtils.RPC:Call('bcc-horsebreeding:GetFoals', { ranchId = ranch.ranchid }, function(foals)
        local count = 0
        for _, f in ipairs(foals or {}) do
            if f.stage ~= 'pregnancy' then
                count = count + 1
                local label = ('Foal #%s'):format(count)
                page:RegisterElement('button', { label = label, style = {} }, function()
                    SpawnFoalEntity(ranch, f)
                    OpenMainMenu(ranch)
                end)
            end
        end
        if count == 0 then
            page:RegisterElement('textdisplay', { value = 'No born foals available yet. Pregnant mares will show here after the foal is born.', slot = 'content', style = {} })
        end
        addBack(page, function() OpenMainMenu(ranch) end)
        HBMenu:Open({ startupPage = page })
    end)
end

function OpenAddAdultHorseToStablesMenu(ranch)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:addadult')
    page:RegisterElement('header', { value = 'Add Adult Horse To Stables', slot = 'header', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })

    BccUtils.RPC:Call('bcc-horsebreeding:GetFoals', { ranchId = ranch.ranchid }, function(foals)
        local count = 0
        for _, f in ipairs(foals or {}) do
            if f.stage == 'adult' then
                count = count + 1
                local label = ('Foal #%s'):format(count)
                page:RegisterElement('button', { label = label, style = {} }, function()
                    OpenAddAdultHorseNameMenu(ranch, f, label)
                end)
            end
        end
        if count == 0 then
            page:RegisterElement('textdisplay', { value = 'No adult foals ready to add to stables.', slot = 'content', style = {} })
        end
        addBack(page, function() OpenMainMenu(ranch) end)
        HBMenu:Open({ startupPage = page })
    end)
end

function OpenAddAdultHorseNameMenu(ranch, foal, label)
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:addadult:name:' .. tostring(foal.id))
    local newName = ''
    page:RegisterElement('header', { value = 'Add Adult Horse To Stables', slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = label or foalLabel(foal), slot = 'content', style = {} })
    page:RegisterElement('input', { label = 'Horse Name', placeholder = 'Ranch Born Horse', style = {} }, function(data)
        newName = data.value or ''
    end)
    page:RegisterElement('button', { label = 'Add To BCC Stables', style = {} }, function()
        BccUtils.RPC:Call('bcc-horsebreeding:ClaimFoal', { ranchId = ranch.ranchid, foalId = foal.id, name = newName }, function(success, msg)
            if success then
                if spawnedFoals and spawnedFoals[tonumber(foal.id)] and DoesEntityExist(spawnedFoals[tonumber(foal.id)]) then
                    DeletePed(spawnedFoals[tonumber(foal.id)])
                    spawnedFoals[tonumber(foal.id)] = nil
                    spawnedFoalLabels[tonumber(foal.id)] = nil
                end
                OpenMainMenu(ranch)
            else
                notify(msg or Config.Text.failed or 'Unable to add horse to stables.')
            end
        end)
    end)
    addBack(page, function() OpenAddAdultHorseToStablesMenu(ranch) end)
    HBMenu:Open({ startupPage = page })
end

function SpawnFoalsAtRanch(ranch)
    OpenSpawnFoalSelectMenu(ranch)
end

function DespawnFoal()
    local count = 0
    for _, ped in pairs(spawnedFoals or {}) do
        if ped and DoesEntityExist(ped) then
            DeletePed(ped)
            count = count + 1
        end
    end
    spawnedFoals = {}
    spawnedFoalLabels = {}
    notify(count > 0 and 'Foal despawned.' or 'No foal is spawned.')
end


CreateThread(function()
    while true do
        Wait(0)
        if Config.ShowFoalNumberOverHead ~= false and spawnedFoals then
            local playerPed = PlayerPedId()
            local pcoords = GetEntityCoords(playerPed)
            local any = false
            for foalId, horsePed in pairs(spawnedFoals) do
                if horsePed and DoesEntityExist(horsePed) then
                    local hcoords = GetEntityCoords(horsePed)
                    local dist = #(pcoords - hcoords)
                    if dist <= (Config.FoalNumberDrawDistance or 18.0) then
                        any = true
                        DrawTxt3D(hcoords.x, hcoords.y, hcoords.z + 1.25, spawnedFoalLabels[foalId] or ('Foal #' .. tostring(foalId)))
                    end
                end
            end
            if not any then Wait(500) end
        else
            Wait(1000)
        end
    end
end)


-- Portable temporary breeding ranch state. This is intentionally client-side only:
-- props/blip disappear on pack-up, resource stop, disconnect, or server reset.
local activePortableRanch = nil
local activeRanchBlip = nil
local careProps = {}

local function deleteBlipSafe(blip)
    if not blip then return end
    pcall(function() if blip.Remove then blip:Remove() end end)
    pcall(function() if blip.rawblip then BccUtils.Blips:RemoveBlip(blip.rawblip) end end)
    pcall(function() if type(blip) == 'number' then RemoveBlip(blip) end end)
end

local function createPortableRanchBlip(coords)
    deleteBlipSafe(activeRanchBlip)
    activeRanchBlip = nil

    -- BCC Ranch uses BccUtils.Blip:SetBlip + AddBlipModifier. Use that first.
    pcall(function()
        if BccUtils.Blip and BccUtils.Blip.SetBlip then
            activeRanchBlip = BccUtils.Blip:SetBlip('Horse Breeding Ranch', Config.BreedingBlipSpriteHash or Config.BreedingBlipSprite or -1103135225, Config.BreedingBlipScale or 0.2, coords.x, coords.y, coords.z)
            if Config.BreedingBlipColorModifier and BccUtils.Blips and BccUtils.Blips.AddBlipModifier then
                local modifier = BccUtils.Blips:AddBlipModifier(activeRanchBlip, Config.BreedingBlipColorModifier)
                if modifier and modifier.ApplyModifier then modifier:ApplyModifier() end
            end
        end
    end)

    -- Native fallback if bcc-utils wrapper is different on this server.
    if not activeRanchBlip then
        activeRanchBlip = Citizen.InvokeNative(0x554D9D53F696D002, 1664425300, coords.x, coords.y, coords.z)
        SetBlipSprite(activeRanchBlip, Config.BreedingBlipSpriteHash or -1103135225, true)
        Citizen.InvokeNative(0x9CB1A1623062F402, activeRanchBlip, 'Horse Breeding Ranch')
        if Config.BreedingBlipColorModifier then
            Citizen.InvokeNative(0x662D364ABF16DE2F, activeRanchBlip, joaat(Config.BreedingBlipColorModifier))
        end
    end
end

local function deleteCareProps()
    for _, list in pairs(careProps) do
        for _, obj in ipairs(list) do
            if obj and DoesEntityExist(obj) then DeleteObject(obj) end
        end
    end
    careProps = {}
end

function PackUpBreedingRanch()
    if CancelAllResupplyDeliveries then CancelAllResupplyDeliveries(true) end
    deleteCareProps()
    cleanupChoreProps()
    for _, ped in pairs(spawnedFoals or {}) do
        if ped and DoesEntityExist(ped) then DeletePed(ped) end
    end
    spawnedFoals = {}
    for _, ped in pairs(spawnedMares or {}) do
        if ped and DoesEntityExist(ped) then DeletePed(ped) end
    end
    spawnedMares = {}
    deleteBlipSafe(activeRanchBlip)
    activeRanchBlip = nil
    activePortableRanch = nil
    notify(Config.Text.packupDone or 'Horse breeding ranch packed up.')
end

ensurePortableRanch = function()
    if activePortableRanch then return activePortableRanch end
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local blocked, townName = isInBlockedTown(coords)
    if blocked then
        notify((Config.Text.townBlocked or 'You cannot set up horse breeding in town.') .. ' (' .. tostring(townName) .. ')')
        return nil
    end
    activePortableRanch = {
        ranchid = 0,
        ranchname = 'Temporary Horse Breeding Ranch',
        coords = coords,
        hbZone = { center = vecToTable(coords), radius = Config.RanchUseDistance or 45.0, points = {} }
    }
    createPortableRanchBlip(coords)
    return activePortableRanch
end

local function spawnStaticCareProps(choreKey, baseCoords, baseHeading)
    if careProps[choreKey] then
        for _, obj in ipairs(careProps[choreKey]) do
            if obj and DoesEntityExist(obj) then DeleteObject(obj) end
        end
    end
    careProps[choreKey] = {}
    local props = Config.ChoreProps and Config.ChoreProps[choreKey]
    if not props then return end
    for _, prop in ipairs(props) do
        local hash = loadObjectModel(prop)
        if hash then
            local off = rotateOffset(prop.offset or vector3(0.0, 0.0, 0.0), baseHeading)
            local pos = snapToGround(baseCoords + off)
            local obj = CreateObject(hash, pos.x, pos.y, pos.z, false, true, false, false, false)
            if obj and DoesEntityExist(obj) then
                SetEntityAsMissionEntity(obj, true, true)
                SetEntityHeading(obj, (baseHeading + (prop.headingOffset or 0.0)) % 360.0)
                PlaceObjectOnGroundProperly(obj, true)
                Wait(100)
                PlaceObjectOnGroundProperly(obj, true)
                if choreKey == 'cleanpoop' then
                    local oc = GetEntityCoords(obj)
                    local grounded = snapToGround(oc)
                    SetEntityCoords(obj, grounded.x, grounded.y, grounded.z - 0.03, false, false, false, false)
                    PlaceObjectOnGroundProperly(obj, true)
                end
                FreezeEntityPosition(obj, true)
                careProps[choreKey][#careProps[choreKey]+1] = obj
            end
            SetModelAsNoLongerNeeded(hash)
        end
    end
end

function OpenCareSetupMenu(ranch)
    ranch = ranch or ensurePortableRanch()
    if not ranch then return end
    HBMenu:Close()
    local zone = ensureZoneLoaded(ranch)
    local page = HBMenu:RegisterPage('bcc-horsebreeding:care_setup')
    page:RegisterElement('header', { value = 'Set Foal Care Locations', slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = 'Stand where you want each chore prop, then set it. Props spawn and stay until you pack up or reset.', slot = 'content', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })

    local order = { 'hay', 'water', 'cleanpoop' }
    for _, key in ipairs(order) do
        local chore = Config.Chores[key]
        if chore then
            local setText = (zone.points and zone.points[key]) and 'SET' or 'NOT SET'
            page:RegisterElement('button', { label = chore.label:gsub(' At Location', '') .. ' [' .. setText .. ']', style = {} }, function()
                local ped = PlayerPedId()
                local coords = GetEntityCoords(ped)
                local blocked, townName = isInBlockedTown(coords)
                if blocked then
                    notify((Config.Text.townBlocked or 'You cannot set up horse breeding in town.') .. ' (' .. tostring(townName) .. ')')
                    return OpenCareSetupMenu(ranch)
                end
                zone.points[key] = vecToTable(coords)
                zone.points[key].heading = GetEntityHeading(ped)
                if key == 'hay' or key == 'water' or key == 'cleanpoop' then
                    spawnStaticCareProps(key, coords, GetEntityHeading(ped))
                end
                notify(chore.label:gsub(' At Location', '') .. ' set.')
                OpenCareSetupMenu(ranch)
            end)
        end
    end

    page:RegisterElement('line', { slot = 'content', style = {} })
    page:RegisterElement('button', { label = 'Back', style = {} }, function() OpenMainMenu(ranch) end)
    page:RegisterElement('button', { label = 'Pack Up Breeding Ranch', style = {} }, function() PackUpBreedingRanch(); HBMenu:Close() end)
    HBMenu:Open({ startupPage = page })
end

local function OpenSetupPointMenu(ranch)
    HBMenu:Close()
    local zone = ensureZoneLoaded(ranch)
    local page = HBMenu:RegisterPage('bcc-horsebreeding:setup:points')
    page:RegisterElement('header', { value = 'Horse Breeding Setup', slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = 'Stand at each spot and click the matching button. This saves exact world locations like BCC Ranch chores.', slot = 'content', style = {} })
    page:RegisterElement('line', { slot = 'content', style = {} })

    page:RegisterElement('button', { label = 'Set breeding ranch center here', style = {} }, function()
        local coords = GetEntityCoords(PlayerPedId())
        zone.center = vecToTable(coords)
        ranch.coords = coords
        notify('Breeding center set here.')
        OpenSetupPointMenu(ranch)
    end)

    page:RegisterElement('input', { label = 'Ranch perimeter radius', placeholder = tostring(zone.radius or Config.RanchUseDistance), style = {} }, function(data)
        local radius = tonumber(data.value)
        if radius and radius > 0 then
            zone.radius = radius
            notify('Radius set to ' .. tostring(radius))
        end
    end)

    page:RegisterElement('line', { slot = 'content', style = {} })
    local order = { 'hay', 'water', 'cleanpoop' }
    for _, key in ipairs(order) do
        local chore = Config.Chores[key]
        if chore then
            page:RegisterElement('button', { label = 'Set ' .. chore.label .. ' location here', style = {} }, function()
                local coords = GetEntityCoords(PlayerPedId())
                zone.points[key] = vecToTable(coords)
                notify(chore.label .. ' point set.')
                OpenSetupPointMenu(ranch)
            end)
        end
    end

    page:RegisterElement('line', { slot = 'content', style = {} })
    page:RegisterElement('button', { label = 'Save horse breeding setup', style = {} }, function()
        BccUtils.RPC:Call('bcc-horsebreeding:SaveBreedingZone', { ranchId = ranch.ranchid, zoneData = zone }, function(success)
            if success then refreshBreedingBlips(); HBMenu:Close() else notify(Config.Text.failed) end
        end)
    end)
    page:RegisterElement('button', { label = 'Delete saved horse breeding setup', style = {} }, function()
        BccUtils.RPC:Call('bcc-horsebreeding:ClearBreedingZone', { ranchId = ranch.ranchid }, function(success)
            if success then refreshBreedingBlips(); HBMenu:Close() else notify(Config.Text.failed) end
        end)
    end)
    addBack(page, function() OpenSetupMenu() end)
    HBMenu:Open({ startupPage = page })
end

function OpenSetupMenu()
    HBMenu:Close()
    local page = HBMenu:RegisterPage('bcc-horsebreeding:setup')
    page:RegisterElement('header', { value = 'Horse Breeding Admin Setup', slot = 'header', style = {} })
    page:RegisterElement('textdisplay', { value = 'Pick a ranch, then set center, perimeter, and chore locations from one menu.', slot = 'content', style = {} })
    BccUtils.RPC:Call('bcc-horsebreeding:GetMyRanches', {}, function(ranches)
        if not ranches or #ranches == 0 then
            page:RegisterElement('textdisplay', { value = Config.Text.setupNoRanches, slot = 'content', style = {} })
        else
            for _, ranch in ipairs(ranches) do
                ranch.hbZone = decodeBreedingZone(ranch.horsebreeding_zone) or { points = {} }
                local label = tostring(ranch.ranchname or ('Ranch #' .. tostring(ranch.ranchid)))
                page:RegisterElement('button', { label = label, style = {} }, function()
                    ranch.coords = getRanchCenter(ranch)
                    OpenSetupPointMenu(ranch)
                end)
            end
        end
        page:RegisterElement('button', { label = 'Close', style = {} }, function() HBMenu:Close() end)
        HBMenu:Open({ startupPage = page })
    end)
end


local passiveFoalLastCoords = {}
CreateThread(function()
    while true do
        Wait((Config.PassiveTraining and Config.PassiveTraining.CheckEveryMs) or 5000)
        if Config.PassiveTraining and Config.PassiveTraining.Enabled and activePortableRanch and spawnedFoals then
            local playerPed = PlayerPedId()
            local lastLed = Citizen.InvokeNative(0x693126B5D0457D0D, playerPed)   -- GetLastLedMount
            local isLeading = Citizen.InvokeNative(0xEFC4303DDC6E60D3, playerPed) -- IsPedLeadingHorse
            local currentMount = Citizen.InvokeNative(0x4C8B59171957BCF7, playerPed) -- GetLastMount
            local isMounted = Citizen.InvokeNative(0x460BC76A0E10655E, playerPed) -- IsPedOnMount
            for foalId, horsePed in pairs(spawnedFoals) do
                if horsePed and DoesEntityExist(horsePed) then
                    local action = nil
                    if lastLed == horsePed and isLeading then action = 'groundwork_lasso' end
                    if currentMount == horsePed and isMounted then action = 'groundwork_ride' end
                    if action then
                        local coords = GetEntityCoords(horsePed)
                        local last = passiveFoalLastCoords[foalId]
                        if not last then
                            passiveFoalLastCoords[foalId] = coords
                        else
                            local dist = #(coords - last)
                            if dist >= ((Config.PassiveTraining and Config.PassiveTraining.MinTravelDistance) or 12.0) then
                                passiveFoalLastCoords[foalId] = coords
                                BccUtils.RPC:Call('bcc-horsebreeding:DoHorseChore', { ranchId = activePortableRanch.ranchid, foalId = foalId, chore = action }, function(success, updated)
                                    if success then notifyGain(action == 'groundwork_ride' and 'Riding training gained' or 'Groundwork gained from leading', updated) end
                                end)
                            end
                        end
                    end
                end
            end
        end
    end
end)



-- #################################################
-- bcc-horsebreeding command starts here
-- Edited By: ShAd0wSn1pER117
-- #################################################

if Config.Command and Config.Command ~= '' then
    RegisterCommand(Config.Command, function()
        local ranch = ensurePortableRanch()
        if not ranch then return end
        OpenMainMenu(ranch)
    end, false)
end

-- #################################################
-- bcc-horsebreeding command ends here
-- Edited By: ShAd0wSn1pER117
-- #################################################

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        if PackUpBreedingRanch then PackUpBreedingRanch() end
    end
end)


local function mountedByPlayer(ped)
    if not ped or not DoesEntityExist(ped) then return false end
    local playerPed = PlayerPedId()
    if not IsPedOnMount(playerPed) then return false end
    local mount = GetMount(playerPed)
    return mount == ped
end

local lastAnimalCareVisit = {}

local function getCarePointVector(ranch, key)
    local zone = ranch and ensureZoneLoaded(ranch)
    local point = zone and zone.points and zone.points[key]
    return tableToVector(point)
end

local function sendAnimalToCarePoint(ped, ranch)
    if not ped or not DoesEntityExist(ped) or not ranch then return false end
    if math.random(100) > (tonumber(Config.RanchAnimalAmbientCareChance) or 25) then return false end
    local choices = {}
    for _, key in ipairs({ 'hay', 'water', 'cleanpoop' }) do
        local point = getCarePointVector(ranch, key)
        if point then choices[#choices + 1] = point end
    end
    if #choices == 0 then return false end
    local target = choices[math.random(#choices)]
    TaskGoToCoordAnyMeans(ped, target.x, target.y, target.z, 0.8, 0, false, 786603, 0xbf800000)
    return true
end

CreateThread(function()
    while true do
        Wait(Config.RanchAnimalBoundaryCheckMs or 5000)
        local ranch = activePortableRanch
        if ranch and (spawnedFoals or spawnedMares) then
            local center = getRanchCenter(ranch)
            local radius = tonumber((ranch.hbZone and ranch.hbZone.radius) or Config.RanchAnimalMaxDistance or Config.RanchUseDistance) or 45.0
            local hardRadius = radius + (tonumber(Config.RanchAnimalTeleportBuffer) or 25.0)
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local ownerAttention = tonumber(Config.RanchAnimalOwnerAttentionDistance) or 18.0
            local ownerTooFar = tonumber(Config.RanchAnimalOwnerTooFarDistance) or 28.0

            if center then
                local function keepNear(ped, animalKey)
                    if ped and DoesEntityExist(ped) and not mountedByPlayer(ped) then
                        local coords = GetEntityCoords(ped)
                        local distFromRanch = #(coords - center)
                        local ownerInRanch = #(playerCoords - center) <= radius
                        local distFromOwner = #(coords - playerCoords)

                        if distFromRanch > hardRadius then
                            local pos = snapToGround(center + vector3(math.random(-4, 4) + 0.0, math.random(-4, 4) + 0.0, 0.0))
                            SetEntityCoords(ped, pos.x, pos.y, pos.z, false, false, false, false)
                            TaskWanderStandard(ped, 10.0, 10)
                            return
                        end

                        if distFromRanch > radius then
                            TaskGoToCoordAnyMeans(ped, center.x, center.y, center.z, 1.0, 0, false, 786603, 0xbf800000)
                            return
                        end

                        -- If the owner is at the breeding ranch, mares/foals loosely stay interested in them.
                        if ownerInRanch and distFromOwner > ownerTooFar then
                            local nearOwner = snapToGround(playerCoords + vector3(math.random(-5, 5) + 0.0, math.random(-5, 5) + 0.0, 0.0))
                            TaskGoToCoordAnyMeans(ped, nearOwner.x, nearOwner.y, nearOwner.z, 0.8, 0, false, 786603, 0xbf800000)
                            return
                        end

                        -- Small ambient behavior: sometimes visit hay, water, or manure/bedding spot.
                        if distFromOwner <= ownerAttention then
                            local now = GetGameTimer()
                            if not lastAnimalCareVisit[animalKey] or (now - lastAnimalCareVisit[animalKey]) > 90000 then
                                if sendAnimalToCarePoint(ped, ranch) then
                                    lastAnimalCareVisit[animalKey] = now
                                    return
                                end
                            end
                        end

                        if math.random(100) <= 20 then
                            TaskWanderInArea(ped, center.x, center.y, center.z, math.min(radius, 18.0), 1.0, 3.0)
                        end
                    end
                end
                for id, ped in pairs(spawnedFoals or {}) do keepNear(ped, 'foal:' .. tostring(id)) end
                for id, ped in pairs(spawnedMares or {}) do keepNear(ped, 'mare:' .. tostring(id)) end
            end
        end
    end
end)
