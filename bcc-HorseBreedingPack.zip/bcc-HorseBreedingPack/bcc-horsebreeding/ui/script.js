const box = document.getElementById('hb-notify');
let timer = null;

window.addEventListener('message', (event) => {
  const data = event.data || {};
  if (data.action !== 'hbNotify') return;

  const message = String(data.message || '').trim();
  const duration = Number(data.duration || 3500);
  if (!message) return;

  box.textContent = message;
  box.classList.remove('hidden');

  if (timer) clearTimeout(timer);
  timer = setTimeout(() => {
    box.classList.add('hidden');
  }, duration);
});
