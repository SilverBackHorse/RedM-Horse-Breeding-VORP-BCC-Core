fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'
lua54 'yes'

author 'Custom for Kyle / BCC compatible'
description 'VORP + BCC Ranch + BCC Stables horse breeding, foal care, growth, and stable claiming'
version '0.1.0'

shared_scripts {
    'config/config.lua'
}


server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

client_scripts {
    'client/main.lua'
}

dependencies {
    'vorp_core',
    'bcc-ranch',
    'bcc-stables',
    'feather-menu',
    'bcc-utils',
    'oxmysql'
}
