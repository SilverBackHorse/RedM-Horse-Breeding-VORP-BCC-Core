local Core = exports.vorp_core:GetCore()
local BccUtils = exports['bcc-utils'].initiate()

local function dprint(msg)
    if Config.DevMode then print('^3[bcc-horsebreeding]^7 ' .. tostring(msg)) end
end

local function ensurePlayerHorsesImportSchema()
    -- Keep this resource compatible with older bcc-stables installs.
    -- oxmysql/MariaDB versions vary, so every migration is best-effort and safe to run repeatedly.
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` MODIFY COLUMN `components` LONGTEXT NULL') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `components` LONGTEXT NULL') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `selected` INT(11) NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `gender` ENUM(\'male\', \'female\') DEFAULT \'male\'') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `xp` INT(11) NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `captured` INT(11) NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `health` INT(11) NOT NULL DEFAULT 50') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `stamina` INT(11) NOT NULL DEFAULT 50') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `dead` INT(11) NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `coal_appearance` LONGTEXT DEFAULT NULL') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `coal_tack_colors` LONGTEXT DEFAULT NULL') end)
end


CreateThread(function()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_horses` (
          `id` INT NOT NULL AUTO_INCREMENT,
          `ranch_id` INT NOT NULL,
          `horse_id` INT NOT NULL,
          `owner_identifier` VARCHAR(50) NOT NULL,
          `owner_charid` INT NOT NULL,
          `status` VARCHAR(50) NOT NULL DEFAULT 'ready',
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          UNIQUE KEY `uniq_ranch_horse` (`ranch_id`, `horse_id`),
          KEY `idx_ranch` (`ranch_id`),
          KEY `idx_horse` (`horse_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]])

    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_foals` (
          `id` INT NOT NULL AUTO_INCREMENT,
          `ranch_id` INT NOT NULL,
          `owner_identifier` VARCHAR(50) NOT NULL,
          `owner_charid` INT NOT NULL,
          `mother_horse_id` INT NOT NULL,
          `father_horse_id` INT NOT NULL,
          `name` VARCHAR(100) NOT NULL DEFAULT 'Foal',
          `model` VARCHAR(100) NOT NULL,
          `components` LONGTEXT NULL,
          `scale` FLOAT NOT NULL DEFAULT 0.70,
          `gender` ENUM('male','female') NOT NULL DEFAULT 'male',
          `stage` VARCHAR(30) NOT NULL DEFAULT 'pregnancy',
          `born_at` INT NOT NULL DEFAULT 0,
          `young_at` INT NOT NULL DEFAULT 0,
          `adult_at` INT NOT NULL DEFAULT 0,
          `pregnancy_end` INT NOT NULL,
          `hunger` INT NOT NULL DEFAULT 75,
          `thirst` INT NOT NULL DEFAULT 75,
          `cleanliness` INT NOT NULL DEFAULT 75,
          `bonding` INT NOT NULL DEFAULT 0,
          `training` INT NOT NULL DEFAULT 0,
          `manure` INT NOT NULL DEFAULT 0,
          `claimed` TINYINT(1) NOT NULL DEFAULT 0,
          `foal_number` INT NOT NULL DEFAULT 0,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`),
          KEY `idx_ranch_stage` (`ranch_id`, `stage`),
          KEY `idx_owner` (`owner_charid`, `owner_identifier`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]])

    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_zones` (
          `ranch_id` INT NOT NULL,
          `zone_data` LONGTEXT NOT NULL,
          `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`ranch_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]])

    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS `bcc_horsebreeding_supplies` (
          `ranch_id` INT NOT NULL,
          `supplies` INT NOT NULL DEFAULT 0,
          `last_buy` INT NOT NULL DEFAULT 0,
          PRIMARY KEY (`ranch_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]])

    -- Safe upgrades for older installs of this resource.
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `bonding` INT NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `training` INT NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `manure` INT NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `components` LONGTEXT NULL') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `scale` FLOAT NOT NULL DEFAULT 0.70') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `last_hay_chore` INT NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `last_water_chore` INT NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `last_cleanpoop_chore` INT NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `coal_appearance` LONGTEXT DEFAULT NULL') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `coal_tack_colors` LONGTEXT DEFAULT NULL') end)
    pcall(function() MySQL.query.await('ALTER TABLE `bcc_horsebreeding_foals` ADD COLUMN `foal_number` INT NOT NULL DEFAULT 0') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` MODIFY COLUMN `components` LONGTEXT NULL') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `coal_appearance` LONGTEXT DEFAULT NULL') end)
    pcall(function() MySQL.query.await('ALTER TABLE `player_horses` ADD COLUMN `coal_tack_colors` LONGTEXT DEFAULT NULL') end)
    ensurePlayerHorsesImportSchema()

    dprint('database ready')
end)

local function getChar(src)
    local user = Core.getUser(src)
    if not user then return nil end
    return user.getUsedCharacter
end

local function notify(src, msg, duration)
    -- Same notification style as void_paycheck-vorp: simple VORP tip.
    if src and src > 0 then
        TriggerClientEvent('vorp:Tip', src, tostring(msg or ''), tonumber(duration) or ((Config.Notify and Config.Notify.Duration) or 5000))
    end
end


RegisterNetEvent('bcc-horsebreeding:serverNotify', function(msg, duration)
    notify(source, msg, duration)
end)


local function roundFoalScale(value)
    value = tonumber(value) or 0.6
    return math.floor((value * 10) + 0.5) / 10
end

local function isAllowedFoalScale(value)
    value = roundFoalScale(value)
    for _, allowed in ipairs(Config.FoalAllowedScaleCommands or { 0.6, 0.7, 0.8, 0.9 }) do
        if math.abs(value - tonumber(allowed)) < 0.01 then return true, value end
    end
    return false, value
end

local function decodeJsonTable(raw)
    if type(raw) == 'table' then return raw end
    if type(raw) == 'string' and raw ~= '' then
        local ok, decoded = pcall(json.decode, raw)
        if ok and type(decoded) == 'table' then return decoded end
    end
    return {}
end

local function cleanCoalCoatOnly(raw, scale)
    -- Foals should only carry their Coal coat/body/hair color data.
    -- Do NOT copy parent tack, saddle, bags, blankets, masks, lanterns, etc.
    local data = decodeJsonTable(raw)
    local bah = data.buildAHorse or data
    local clean = { buildAHorse = {} }
    if type(bah.body) == 'table' then clean.buildAHorse.body = bah.body end
    if type(bah.hair) == 'table' then clean.buildAHorse.hair = bah.hair end
    if bah.coatNumber ~= nil then clean.buildAHorse.coatNumber = bah.coatNumber end
    clean.buildAHorse.breedingGenerated = true
    clean.buildAHorse.scale = scale or (Config.FoalScales and Config.FoalScales.foal) or 0.60
    return json.encode(clean)
end

local function setCoalAppearanceScale(raw, scale)
    scale = roundFoalScale(scale)
    local data = decodeJsonTable(raw)
    data.buildAHorse = data.buildAHorse or {}
    data.buildAHorse.scale = scale
    return cleanCoalCoatOnly(data, scale)
end

local function coalAppearanceForPlayerHorse(raw, scale)
    -- BCC Stables/player_horses expects coal_appearance.body at the top level.
    -- The foal/ranch code stores generated coats under buildAHorse for preview/growth.
    -- On import, flatten it so Coal applies the foal's rolled coat instead of the
    -- horse model/parent default appearance. Tack stays empty in coal_tack_colors.
    scale = tonumber(scale) or (Config.FoalScales and Config.FoalScales.stableAdult) or 1.0
    local data = decodeJsonTable(raw)
    local bah = data.buildAHorse or data
    local clean = {}
    if type(bah.body) == 'table' then clean.body = bah.body end
    if type(bah.hair) == 'table' then clean.hair = bah.hair end
    if bah.coatNumber ~= nil then clean.coatNumber = bah.coatNumber end
    clean.breedingGenerated = true
    clean.scale = scale
    return json.encode(clean)
end

local function updateFoalScaleOnly(foalId, scale)
    scale = roundFoalScale(scale)
    local row = MySQL.single.await('SELECT coal_appearance FROM bcc_horsebreeding_foals WHERE id = ? LIMIT 1', { foalId })
    local coal = row and setCoalAppearanceScale(row.coal_appearance, scale) or nil
    if coal then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET scale = ?, coal_appearance = ? WHERE id = ?', { scale, coal, foalId })
    else
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET scale = ? WHERE id = ?', { scale, foalId })
    end
end

local function getFoalCareAverage(f)
    local maxValue = tonumber(Config.Care and Config.Care.MaxValue) or 100
    local hunger = tonumber(f.hunger) or 0
    local thirst = tonumber(f.thirst) or 0
    local clean = tonumber(f.cleanliness) or 0
    local trained = tonumber(f.training) or 0
    local bond = tonumber(f.bonding) or 0
    return math.max(0, math.min(maxValue, (hunger + thirst + clean + trained + bond) / 5))
end

local function getGrowthSpeedMultiplier(f)
    if not (Config.Care and Config.Care.StatBasedGrowthEnabled) then return 1.0 end
    local avg = getFoalCareAverage(f)
    local minAvg = tonumber(Config.Care.StatGrowthMinAverage) or 0
    local maxMult = tonumber(Config.Care.StatGrowthMaxMultiplier) or 2.0
    if maxMult < 1.0 then maxMult = 1.0 end
    if avg <= minAvg then return 1.0 end
    local pct = math.min(1.0, (avg - minAvg) / math.max(1.0, 100.0 - minAvg))
    return 1.0 + ((maxMult - 1.0) * pct)
end

local function getScaleForGrowth(now, f)
    local bornAt = tonumber(f.born_at or 0) or 0
    if bornAt <= 0 then return 'foal', Config.FoalScales.foal or 0.6 end

    local total = ((tonumber(Config.FoalToYoungSeconds) or 43200) + (tonumber(Config.YoungToAdultSeconds) or 43200))
    if total <= 0 then total = 86400 end

    local elapsed = math.max(0, now - bornAt) * getGrowthSpeedMultiplier(f)
    local q1 = total * 0.25
    local q2 = total * 0.50
    local q3 = total * 0.75

    if elapsed >= total then
        return 'adult', Config.FoalScales.adult or 0.9
    elseif elapsed >= q3 then
        return 'young', Config.FoalScales.adult or 0.9
    elseif elapsed >= q2 then
        return 'young', Config.FoalScales.young or 0.8
    elseif elapsed >= q1 then
        return 'foal', Config.FoalScales.foalMid or 0.7
    end
    return 'foal', Config.FoalScales.foal or 0.6
end

local function isRanchAllowed(charid, ranchId)
    ranchId = tonumber(ranchId)
    if not ranchId then return false end
    if Config.StrictBccRanchPermission == false then return true end
    local owned = MySQL.query.await('SELECT 1 FROM bcc_ranch WHERE ranchid = ? AND charidentifier = ? LIMIT 1', { ranchId, charid })
    if owned and #owned > 0 then return true end
    local emp = MySQL.query.await('SELECT 1 FROM bcc_ranch_employees WHERE ranch_id = ? AND character_id = ? LIMIT 1', { ranchId, charid })
    return emp and #emp > 0
end

local function updateFoalStagesForRanch(ranchId)
    local now = os.time()
    local foals = MySQL.query.await('SELECT * FROM bcc_horsebreeding_foals WHERE ranch_id = ? AND claimed = 0', { ranchId }) or {}
    for _, f in ipairs(foals) do
        local stage = f.stage
        if stage == 'pregnancy' and now >= tonumber(f.pregnancy_end or 0) then
            local bornAt = now
            local youngAt = bornAt + (tonumber(Config.FoalToYoungSeconds) or 43200)
            local adultAt = bornAt + (tonumber(Config.FoalToYoungSeconds) or 43200) + (tonumber(Config.YoungToAdultSeconds) or 43200)
            local scale = Config.FoalScales.foal or 0.6
            MySQL.update.await('UPDATE bcc_horsebreeding_foals SET stage = ?, born_at = ?, young_at = ?, adult_at = ?, scale = ?, coal_appearance = ? WHERE id = ?', {
                'foal', bornAt, youngAt, adultAt, scale, setCoalAppearanceScale(f.coal_appearance, scale), f.id
            })
            MySQL.update.await('UPDATE bcc_horsebreeding_horses SET status = ? WHERE ranch_id = ? AND horse_id = ?', { 'ready', ranchId, f.mother_horse_id })
        elseif stage == 'foal' or stage == 'young' or stage == 'adult' then
            local newStage, newScale = getScaleForGrowth(now, f)
            local oldScale = roundFoalScale(f.scale or 0)
            if newStage ~= stage or math.abs(oldScale - roundFoalScale(newScale)) > 0.01 then
                MySQL.update.await('UPDATE bcc_horsebreeding_foals SET stage = ?, scale = ?, coal_appearance = ? WHERE id = ?', {
                    newStage, roundFoalScale(newScale), setCoalAppearanceScale(f.coal_appearance, newScale), f.id
                })
            end
        end
    end
end

local function refreshFoalNumbersForRanch(ranchId)
    ranchId = tonumber(ranchId)
    if not ranchId then return end
    local rows = MySQL.query.await([[
        SELECT id, foal_number
        FROM bcc_horsebreeding_foals
        WHERE ranch_id = ? AND claimed = 0
        ORDER BY id ASC
    ]], { ranchId }) or {}
    for index, row in ipairs(rows) do
        if tonumber(row.foal_number or 0) ~= index then
            MySQL.update.await('UPDATE bcc_horsebreeding_foals SET foal_number = ? WHERE id = ?', { index, row.id })
        end
    end
end

CreateThread(function()
    local minutes = tonumber(Config.FoalGrowthDbUpdateMinutes) or 1
    if minutes < 1 then minutes = 1 end
    while true do
        Wait(minutes * 60 * 1000)
        local ranchRows = MySQL.query.await('SELECT DISTINCT ranch_id FROM bcc_horsebreeding_foals WHERE claimed = 0 AND stage IN (?, ?, ?)', { 'foal', 'young', 'adult' }) or {}
        for _, row in ipairs(ranchRows) do
            updateFoalStagesForRanch(row.ranch_id)
        end
    end
end)

local function inheritModel(mother, father)
    local pick = math.random(1, 100)
    if pick <= 50 and mother and mother.model then return mother.model end
    if father and father.model then return father.model end
    return Config.DefaultFoalModel
end

local function randomFoalCoatNum()
    local blocked = { [874] = true, [880] = true, [892] = true, [893] = true, [990] = true }
    for i = 900, 987 do blocked[i] = true end
    local num
    repeat
        num = math.random(845, 999)
    until not blocked[num]
    return num
end

local function randomFoalTint()
    return math.random(2, 254)
end

local function buildRandomCoalAppearance(scale)
    local coat = randomFoalCoatNum()
    local palette = 'metaped_tint_horse'
    local t0, t1, t2 = randomFoalTint(), randomFoalTint(), randomFoalTint()
    return {
        body = {
            hand = {
                drawable = 'p_c_horse_01_hand_000',
                albedo = ('p_c_horse_01_hand_000_C0_%03d_ab'):format(coat),
                normal = 'p_c_horse_01_hand_000_C0_001_nm',
                material = 'p_c_horse_01_hand_000_C0_001_m',
                palette = palette, tint0 = t0, tint1 = t1, tint2 = t2
            },
            head = {
                drawable = 'p_c_horse_01_head_000',
                albedo = ('p_c_horse_01_head_000_C0_%03d_ab'):format(coat),
                normal = 'p_c_horse_01_head_000_C0_001_nm',
                material = 'p_c_horse_01_head_000_C0_001_m',
                palette = palette, tint0 = t0, tint1 = t1, tint2 = t2
            },
            mis2 = {
                drawable = 'p_c_horse_01_mis2_000',
                albedo = ('p_c_horse_01_mis2_000_C0_%03d_ab'):format(coat),
                normal = 'p_c_horse_01_mis2_000_C0_001_nm',
                material = 'p_c_horse_01_mis2_000_C0_001_m',
                palette = palette, tint0 = t0, tint1 = t1, tint2 = t2
            }
        },
        scale = scale or (Config.FoalScales and Config.FoalScales.foal) or 0.60,
        breedingGenerated = true,
        coatNumber = coat
    }
end

local function getCleanFoalComponents()
    -- Leave BCC/Stables equipment empty. Players buy tack later in stables.
    return '{}'
end

local function generateFoalCoalAppearance()
    return json.encode({ buildAHorse = buildRandomCoalAppearance(Config.FoalScales and Config.FoalScales.foal or 0.60) })
end


local function attachBreedingZones(rows)
    for _, ranch in ipairs(rows or {}) do
        local zone = MySQL.single.await('SELECT zone_data FROM bcc_horsebreeding_zones WHERE ranch_id = ? LIMIT 1', { ranch.ranchid })
        if zone and zone.zone_data then
            ranch.horsebreeding_zone = zone.zone_data
        end
    end
    return rows
end

BccUtils.RPC:Register('bcc-horsebreeding:GetMyRanches', function(_, cb, src)
    local char = getChar(src)
    if not char then return cb({}) end
    local charid = char.charIdentifier
    local rows

    if Config.StrictBccRanchPermission == false then
        -- Testing / easy mode: show all ranches so saved horse-breeding zones can be used even if
        -- the BCC Ranch employee/owner lookup is not matching your database yet.
        rows = MySQL.query.await([[
            SELECT ranchid, ranchname, ranchcoords, ranch_radius_limit FROM bcc_ranch
        ]]) or {}
    else
        rows = MySQL.query.await([[
            SELECT ranchid, ranchname, ranchcoords, ranch_radius_limit FROM bcc_ranch WHERE charidentifier = ?
            UNION
            SELECT r.ranchid, r.ranchname, r.ranchcoords, r.ranch_radius_limit
            FROM bcc_ranch r INNER JOIN bcc_ranch_employees e ON e.ranch_id = r.ranchid
            WHERE e.character_id = ?
        ]], { charid, charid }) or {}
    end

    cb(attachBreedingZones(rows))
end)

BccUtils.RPC:Register('bcc-horsebreeding:SaveBreedingZone', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb(false) end
    local ranchId = tonumber(params.ranchId)
    local zoneData = params.zoneData
    if not ranchId or type(zoneData) ~= 'table' then return cb(false) end
    if not isRanchAllowed(char.charIdentifier, ranchId) then return cb(false) end
    local encoded = json.encode(zoneData)
    MySQL.insert.await('INSERT INTO bcc_horsebreeding_zones (ranch_id, zone_data) VALUES (?, ?) ON DUPLICATE KEY UPDATE zone_data = VALUES(zone_data)', { ranchId, encoded })
    notify(src, Config.Text.setupSaved)
    cb(true)
end)

BccUtils.RPC:Register('bcc-horsebreeding:ClearBreedingZone', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb(false) end
    local ranchId = tonumber(params.ranchId)
    if not ranchId or not isRanchAllowed(char.charIdentifier, ranchId) then return cb(false) end
    MySQL.update.await('DELETE FROM bcc_horsebreeding_zones WHERE ranch_id = ?', { ranchId })
    notify(src, Config.Text.setupCleared)
    cb(true)
end)

BccUtils.RPC:Register('bcc-horsebreeding:GetMyHorses', function(_, cb, src)
    local char = getChar(src)
    if not char then return cb({}) end
    local rows = MySQL.query.await('SELECT id, name, model, gender, xp, health, stamina, selected FROM player_horses WHERE identifier = ? AND charid = ? AND dead = 0 ORDER BY selected DESC, name ASC', { char.identifier, char.charIdentifier }) or {}
    cb(rows)
end)

BccUtils.RPC:Register('bcc-horsebreeding:RegisterHorseAtRanch', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb(false) end
    local ranchId = tonumber(params.ranchId)
    local horseId = tonumber(params.horseId)
    if not isRanchAllowed(char.charIdentifier, ranchId) then return cb(false) end
    local horse = MySQL.single.await('SELECT id FROM player_horses WHERE id = ? AND identifier = ? AND charid = ? AND dead = 0', { horseId, char.identifier, char.charIdentifier })
    if not horse then return cb(false) end
    MySQL.insert.await('INSERT INTO bcc_horsebreeding_horses (ranch_id, horse_id, owner_identifier, owner_charid, status) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status)', { ranchId, horseId, char.identifier, char.charIdentifier, 'ready' })
    notify(src, Config.Text.registered)
    cb(true)
end)

BccUtils.RPC:Register('bcc-horsebreeding:GetRanchHorses', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb({}) end
    local ranchId = tonumber(params.ranchId)
    if not isRanchAllowed(char.charIdentifier, ranchId) then return cb({}) end
    updateFoalStagesForRanch(ranchId)
    refreshFoalNumbersForRanch(ranchId)
    local rows = MySQL.query.await([[
        SELECT bh.status, ph.id, ph.name, ph.model, ph.gender, ph.xp, ph.health, ph.stamina
        FROM bcc_horsebreeding_horses bh
        INNER JOIN player_horses ph ON ph.id = bh.horse_id
        WHERE bh.ranch_id = ? AND ph.dead = 0
        ORDER BY ph.gender, ph.name
    ]], { ranchId }) or {}
    cb(rows)
end)

BccUtils.RPC:Register('bcc-horsebreeding:BreedHorses', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb({ success = false, message = 'Character not loaded.' }) end
    local ranchId = tonumber(params.ranchId)
    local mareId = tonumber(params.mareId)
    local stallionId = tonumber(params.stallionId)
    if not ranchId or not mareId or not stallionId or mareId == stallionId then
        return cb({ success = false, message = 'Select one mare and one stallion first.' })
    end
    if not isRanchAllowed(char.charIdentifier, ranchId) then
        return cb({ success = false, message = 'You cannot breed horses at this ranch.' })
    end

    local mare = MySQL.single.await([[SELECT ph.* FROM bcc_horsebreeding_horses bh INNER JOIN player_horses ph ON ph.id = bh.horse_id WHERE bh.ranch_id = ? AND bh.horse_id = ? AND bh.status = 'ready' AND ph.gender = 'female' AND ph.dead = 0]], { ranchId, mareId })
    local stallion = MySQL.single.await([[SELECT ph.* FROM bcc_horsebreeding_horses bh INNER JOIN player_horses ph ON ph.id = bh.horse_id WHERE bh.ranch_id = ? AND bh.horse_id = ? AND bh.status = 'ready' AND ph.gender = 'male' AND ph.dead = 0]], { ranchId, stallionId })

    if not mare then
        local pregnant = MySQL.single.await([[SELECT 1 FROM bcc_horsebreeding_horses WHERE ranch_id = ? AND horse_id = ? AND status = 'pregnant' LIMIT 1]], { ranchId, mareId })
        if pregnant then
            return cb({ success = false, message = 'That mare is already pregnant.' })
        end
        return cb({ success = false, message = 'Selected mare is not ready for breeding.' })
    end
    if not stallion then
        return cb({ success = false, message = 'Selected stallion is not ready for breeding.' })
    end

    local now = os.time()
    local model = inheritModel(mare, stallion)
    local components = getCleanFoalComponents()
    local coalAppearance = generateFoalCoalAppearance()
    local gender = math.random(1, 2) == 1 and 'male' or 'female'
    local pregnancyEnd = now + (tonumber(Config.PregnancySeconds) or 86400)

    local ok, insertId = pcall(function()
        return MySQL.insert.await([[INSERT INTO bcc_horsebreeding_foals (ranch_id, owner_identifier, owner_charid, mother_horse_id, father_horse_id, model, components, coal_appearance, coal_tack_colors, scale, gender, stage, pregnancy_end)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pregnancy', ?)]], { ranchId, char.identifier, char.charIdentifier, mareId, stallionId, model, components, coalAppearance, '{}', Config.FoalScales.foal or 0.60, gender, pregnancyEnd })
    end)

    if not ok or not insertId then
        dprint('Coal appearance insert failed, trying fallback insert: ' .. tostring(insertId))
        ok, insertId = pcall(function()
            return MySQL.insert.await([[INSERT INTO bcc_horsebreeding_foals (ranch_id, owner_identifier, owner_charid, mother_horse_id, father_horse_id, model, components, scale, gender, stage, pregnancy_end)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pregnancy', ?)]], { ranchId, char.identifier, char.charIdentifier, mareId, stallionId, model, components, Config.FoalScales.foal or 0.60, gender, pregnancyEnd })
        end)
    end

    if not ok or not insertId then
        dprint('Breeding insert failed: ' .. tostring(insertId))
        return cb({ success = false, message = 'Breeding failed to save. Check database columns.' })
    end

    MySQL.update.await('UPDATE bcc_horsebreeding_horses SET status = ? WHERE ranch_id = ? AND horse_id = ?', { 'pregnant', ranchId, mareId })
    refreshFoalNumbersForRanch(ranchId)
    -- Keep the source stable horse marked as female so Coal/BCC and breeding stay in sync.
    MySQL.update.await('UPDATE player_horses SET gender = ? WHERE id = ? AND identifier = ? AND charid = ?', { 'female', mareId, char.identifier, char.charIdentifier })
    notify(src, Config.Text.breedStarted or 'Breeding started.')
    cb({ success = true, message = 'Breeding started. Mare pregnancy saved.' })
end)

BccUtils.RPC:Register('bcc-horsebreeding:GetFoals', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb({}) end
    local ranchId = tonumber(params.ranchId)
    if not isRanchAllowed(char.charIdentifier, ranchId) then return cb({}) end
    updateFoalStagesForRanch(ranchId)
    refreshFoalNumbersForRanch(ranchId)
    local rows = MySQL.query.await([[
        SELECT f.*, mom.name AS mother_name, dad.name AS father_name
        FROM bcc_horsebreeding_foals f
        LEFT JOIN player_horses mom ON mom.id = f.mother_horse_id
        LEFT JOIN player_horses dad ON dad.id = f.father_horse_id
        WHERE f.ranch_id = ? AND f.claimed = 0
        ORDER BY f.foal_number ASC, f.id ASC
    ]], { ranchId }) or {}
    cb(rows)

end)

local tryRemoveCareItem

BccUtils.RPC:Register('bcc-horsebreeding:GetPregnantMares', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb({}) end
    local ranchId = tonumber(params.ranchId)
    if not ranchId or not isRanchAllowed(char.charIdentifier, ranchId) then return cb({}) end
    updateFoalStagesForRanch(ranchId)
    refreshFoalNumbersForRanch(ranchId)
    local rows = MySQL.query.await([[
        SELECT f.id, f.foal_number, f.stage, f.pregnancy_end, f.mother_horse_id, mom.name AS mother_name, mom.model AS mother_model, mom.gender AS mother_gender, mom.components AS mother_components, mom.coal_appearance AS mother_coal_appearance, mom.coal_tack_colors AS mother_coal_tack_colors
        FROM bcc_horsebreeding_foals f
        LEFT JOIN player_horses mom ON mom.id = f.mother_horse_id
        WHERE f.ranch_id = ? AND f.claimed = 0 AND f.stage = 'pregnancy'
        ORDER BY f.foal_number ASC, f.id ASC
    ]], { ranchId }) or {}
    cb(rows)
end)

local function breedingZoneHasCareLocations(ranchId)
    local zone = MySQL.single.await('SELECT zone_data FROM bcc_horsebreeding_zones WHERE ranch_id = ? LIMIT 1', { ranchId })
    if not zone or not zone.zone_data then return false end
    local ok, data = pcall(json.decode, zone.zone_data)
    if not ok or type(data) ~= 'table' or type(data.points) ~= 'table' then return false end
    return data.points.hay ~= nil and data.points.water ~= nil and data.points.cleanpoop ~= nil
end

local function reducePregnancyTime(foalId, seconds)
    local now = os.time()
    seconds = tonumber(seconds) or 0
    if seconds <= 0 then return end
    MySQL.update.await('UPDATE bcc_horsebreeding_foals SET pregnancy_end = GREATEST(?, pregnancy_end - ?) WHERE id = ? AND stage = ?', { now + 60, seconds, foalId, 'pregnancy' })
end

BccUtils.RPC:Register('bcc-horsebreeding:DoMareCare', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb(false, Config.Text.failed) end
    local ranchId = tonumber(params.ranchId)
    local pregnancyId = tonumber(params.pregnancyId)
    local action = tostring(params.action or '')
    if not ranchId or not pregnancyId or action == '' then return cb(false, Config.Text.failed) end
    if not isRanchAllowed(char.charIdentifier, ranchId) then return cb(false, Config.Text.failed) end
    local foal = MySQL.single.await('SELECT * FROM bcc_horsebreeding_foals WHERE id = ? AND ranch_id = ? AND claimed = 0 AND stage = ?', { pregnancyId, ranchId, 'pregnancy' })
    if not foal then return cb(false, 'That mare is not pregnant anymore.') end
    if Config.RanchSupplies and Config.RanchSupplies.Enabled then
        local ok, msg = hasEnoughSupplies(ranchId)
        if not ok then return cb(false, msg) end
        ok, msg = consumeSupplies(ranchId)
        if not ok then return cb(false, msg) end
    end
    if action == 'brush' then
        if not tryRemoveCareItem(src, 'brush') then return cb(false, 'Missing brush.') end
        reducePregnancyTime(pregnancyId, Config.MareCare.BrushPregnancyBonusSeconds or 900)
        return cb(true, Config.Text.mareBrushDone or 'Mare brushed. Foaling time reduced.')
    elseif action == 'feed_haycube' then
        if not tryRemoveCareItem(src, 'feed_haycube') then return cb(false, 'Missing hay cube.') end
        reducePregnancyTime(pregnancyId, Config.MareCare.HayCubePregnancyBonusSeconds or 900)
        return cb(true, Config.Text.mareTreatDone or 'Mare fed. Foaling time reduced.')
    elseif action == 'feed_sugarcube' then
        if not tryRemoveCareItem(src, 'feed_sugarcube') then return cb(false, 'Missing sugar cube.') end
        reducePregnancyTime(pregnancyId, Config.MareCare.SugarCubePregnancyBonusSeconds or 1200)
        return cb(true, Config.Text.mareTreatDone or 'Mare fed. Foaling time reduced.')
    end
    cb(false, Config.Text.failed)
end)

function tryRemoveCareItem(src, action)
    if not Config.RequireCareItems then return true end
    local item = Config.CareItems[action]
    if not item then return true end
    local ok, count = pcall(function() return exports.vorp_inventory:getItemCount(src, nil, item) end)
    if ok and tonumber(count) and tonumber(count) > 0 then
        pcall(function() exports.vorp_inventory:subItem(src, item, 1) end)
        return true
    end
    return false
end

BccUtils.RPC:Register('bcc-horsebreeding:CareFoal', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb(false) end
    local foalId = tonumber(params.foalId)
    local action = tostring(params.action or '')
    local foal = MySQL.single.await('SELECT * FROM bcc_horsebreeding_foals WHERE id = ? AND claimed = 0', { foalId })
    if not foal or not isRanchAllowed(char.charIdentifier, foal.ranch_id) then return cb(false) end
    if action ~= 'feed' and action ~= 'water' and action ~= 'brush' then return cb(false) end
    if not tryRemoveCareItem(src, action) then return cb(false) end

    if action == 'feed' then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET hunger = LEAST(?, hunger + ?) WHERE id = ?', { Config.Care.MaxValue, Config.Care.FeedAmount, foalId })
    elseif action == 'water' then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET thirst = LEAST(?, thirst + ?) WHERE id = ?', { Config.Care.MaxValue, Config.Care.WaterAmount, foalId })
    elseif action == 'brush' then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET cleanliness = LEAST(?, cleanliness + ?) WHERE id = ?', { Config.Care.MaxValue, Config.Care.BrushAmount, foalId })
    end
    notify(src, Config.Text.careDone)
    cb(true)
end)


local function clampCare(value)
    value = tonumber(value) or 0
    if value < 0 then return 0 end
    if value > Config.Care.MaxValue then return Config.Care.MaxValue end
    return value
end


local function getSupplies(ranchId)
    local row = MySQL.single.await('SELECT supplies, last_buy FROM bcc_horsebreeding_supplies WHERE ranch_id = ? LIMIT 1', { ranchId })
    if not row then
        MySQL.insert.await('INSERT INTO bcc_horsebreeding_supplies (ranch_id, supplies, last_buy) VALUES (?, 0, 0)', { ranchId })
        return { supplies = 0, last_buy = 0 }
    end
    return row
end

local function choreRequiresSupplies(choreKey)
    if not Config.RanchSupplies or Config.RanchSupplies.Enabled == false then return false end
    local list = Config.RanchSupplies.RequiredForChores or { hay = true, water = true, cleanpoop = true }
    return list[choreKey] == true
end

local function hasEnoughSupplies(ranchId)
    if not Config.RanchSupplies or Config.RanchSupplies.Enabled == false then return true, nil end
    local row = getSupplies(ranchId)
    local supplies = tonumber(row.supplies) or 0
    local cost = tonumber(Config.RanchSupplies.ChoreCost) or 15
    if supplies <= 0 or supplies < cost then
        return false, Config.Text.noSupplies or 'Ranch supplies are empty. Buy supplies before doing chores.'
    end
    return true, nil
end

local function consumeSupplies(ranchId)
    local ok, msg = hasEnoughSupplies(ranchId)
    if not ok then return false, msg end
    local cost = tonumber(Config.RanchSupplies.ChoreCost) or 15
    MySQL.update.await('UPDATE bcc_horsebreeding_supplies SET supplies = GREATEST(0, supplies - ?) WHERE ranch_id = ?', { cost, ranchId })
    return true, nil
end

local function checkAndSetChoreCooldown(foal, choreKey)
    local col = nil
    if choreKey == 'hay' then col = 'last_hay_chore' end
    if choreKey == 'water' then col = 'last_water_chore' end
    if choreKey == 'cleanpoop' then col = 'last_cleanpoop_chore' end
    if not col then return true, nil end
    local now = os.time()
    local cooldown = (tonumber(Config.Care.ChoreCooldownMinutes) or 10) * 60
    local last = tonumber(foal[col] or 0) or 0
    if last > 0 and now - last < cooldown then
        local left = math.ceil((cooldown - (now - last)) / 60)
        return false, (Config.Text.choreCooldown or 'That chore is on cooldown.') .. (' Wait %s min.'):format(left)
    end
    MySQL.update.await(('UPDATE bcc_horsebreeding_foals SET %s = ? WHERE id = ?'):format(col), { now, foal.id })
    return true, nil
end

local function choreCompleteMessage(choreKey)
    if choreKey == 'hay' then return 'Increased feeding care.' end
    if choreKey == 'water' then return 'Increased watering care.' end
    if choreKey == 'cleanpoop' then return 'Increased clean bedding care.' end
    if choreKey == 'brush' then return 'Increased cleanliness and bonding.' end
    if choreKey == 'feed_haycube' then return 'Increased food and bonding.' end
    if choreKey == 'feed_sugarcube' then return 'Increased bonding.' end
    if choreKey == 'groundwork_lasso' then return 'Increased groundwork training.' end
    if choreKey == 'groundwork_ride' then return 'Increased riding training.' end
    return Config.Text.careDone or 'Care updated.'
end

local function applyCareGrowthBonus(foalId)
    if not Config.Care.GrowthBonusEnabled then return end
    local f = MySQL.single.await('SELECT * FROM bcc_horsebreeding_foals WHERE id = ?', { foalId })
    if not f or f.stage == 'pregnancy' or f.stage == 'adult' then return end
    local hunger = tonumber(f.hunger) or 0
    local thirst = tonumber(f.thirst) or 0
    local clean = tonumber(f.cleanliness) or 0
    local trained = tonumber(f.training) or 0
    local bond = tonumber(f.bonding) or 0
    local manure = tonumber(f.manure) or 0
    local avg = (hunger + thirst + clean + trained + bond + manure) / 6
    local threshold = tonumber(Config.Care.GrowthBonusThreshold) or 65
    if avg < threshold then return end
    local bonus = math.floor(((avg - threshold) / math.max(1, 100 - threshold)) * (tonumber(Config.Care.MaxGrowthBonusSecondsPerChore) or 600))
    if bonus <= 0 then return end
    local now = os.time()
    if f.stage == 'foal' and tonumber(f.young_at or 0) > now then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET young_at = GREATEST(?, young_at - ?) WHERE id = ?', { now + 60, bonus, foalId })
    elseif f.stage == 'young' and tonumber(f.adult_at or 0) > now then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET adult_at = GREATEST(?, adult_at - ?) WHERE id = ?', { now + 60, bonus, foalId })
    end
end

local function getFoalStatsRow(foalId)
    return MySQL.single.await('SELECT id, hunger, thirst, cleanliness, bonding, training, manure, stage, young_at, adult_at FROM bcc_horsebreeding_foals WHERE id = ?', { foalId })
end


BccUtils.RPC:Register('bcc-horsebreeding:GetRanchSupplies', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb({ supplies = 0 }) end
    local ranchId = tonumber(params.ranchId)
    if not ranchId or not isRanchAllowed(char.charIdentifier, ranchId) then return cb({ supplies = 0 }) end
    local row = getSupplies(ranchId)
    cb({ supplies = tonumber(row.supplies) or 0, lastBuy = tonumber(row.last_buy) or 0 })
end)

BccUtils.RPC:Register('bcc-horsebreeding:BuyRanchSupplies', function(params, cb, src)
    local user = Core.getUser(src)
    if not user then return cb(false, Config.Text.failed) end
    local char = user.getUsedCharacter
    if not char then return cb(false, Config.Text.failed) end
    local ranchId = tonumber(params.ranchId)
    if not ranchId or not isRanchAllowed(char.charIdentifier, ranchId) then return cb(false, Config.Text.failed) end
    local row = getSupplies(ranchId)
    local now = os.time()
    local cooldown = (tonumber(Config.RanchSupplies.BuyCooldownMinutes) or 25) * 60
    local last = tonumber(row.last_buy or 0) or 0
    if last > 0 and now - last < cooldown then
        local left = math.ceil((cooldown - (now - last)) / 60)
        return cb(false, (Config.Text.supplyCooldown or 'You must wait before buying more ranch supplies.') .. (' Wait %s min.'):format(left))
    end
    local currency = tostring(params.currency or 'cash')
    local isCash = currency ~= 'gold'
    local price = isCash and (tonumber(Config.RanchSupplies.CashPrice) or 25) or (tonumber(Config.RanchSupplies.GoldPrice) or 1)
    local currencyType = isCash and 0 or 1
    local balance = isCash and (tonumber(char.money) or 0) or (tonumber(char.gold) or 0)
    if balance < price then return cb(false, Config.Text.notEnoughMoney or 'You do not have enough money.') end

    -- Match BCC Stables' working VORP payment style exactly:
    -- character.money/character.gold check first, then character.removeCurrency(type, amount).
    char.removeCurrency(currencyType, price)
    MySQL.insert.await([[INSERT INTO bcc_horsebreeding_supplies (ranch_id, supplies, last_buy) VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE supplies = LEAST(?, supplies + ?), last_buy = VALUES(last_buy)]], {
        ranchId, Config.RanchSupplies.BuyAmount or 45, now, Config.RanchSupplies.MaxValue or 100, Config.RanchSupplies.BuyAmount or 45
    })
    local updated = getSupplies(ranchId)
    cb(true, (Config.Text.suppliesBought or 'Ranch supplies increased.') .. (' Supplies: %s%%'):format(tonumber(updated.supplies) or 0))
end)


BccUtils.RPC:Register('bcc-horsebreeding:CompleteResupplyDelivery', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb(false, Config.Text.failed) end
    local ranchId = tonumber(params and params.ranchId)
    if not ranchId or not isRanchAllowed(char.charIdentifier, ranchId) then return cb(false, Config.Text.failed) end
    local gain = tonumber(Config.Resupply and Config.Resupply.SupplyGain) or 60
    local maxVal = tonumber(Config.Resupply and Config.Resupply.MaxValue) or (tonumber(Config.RanchSupplies and Config.RanchSupplies.MaxValue) or 100)
    MySQL.insert.await([[INSERT INTO bcc_horsebreeding_supplies (ranch_id, supplies, last_buy) VALUES (?, ?, 0)
        ON DUPLICATE KEY UPDATE supplies = LEAST(?, supplies + ?)]], { ranchId, gain, maxVal, gain })
    local row = getSupplies(ranchId)
    cb(true, ('Resupply delivered. Ranch supplies: %s%%'):format(tonumber(row.supplies) or 0))
end)


BccUtils.RPC:Register('bcc-horsebreeding:CanDoHorseChore', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb(false, Config.Text.failed) end
    local ranchId = tonumber(params.ranchId)
    local foalId = tonumber(params.foalId)
    local choreKey = tostring(params.chore or '')
    if not ranchId or not foalId or choreKey == '' then return cb(false, Config.Text.failed) end
    if not isRanchAllowed(char.charIdentifier, ranchId) then return cb(false, Config.Text.failed) end
    local foal = MySQL.single.await('SELECT * FROM bcc_horsebreeding_foals WHERE id = ? AND ranch_id = ? AND claimed = 0', { foalId, ranchId })
    if not foal or foal.stage == 'pregnancy' then return cb(false, Config.Text.failed) end
    if choreRequiresSupplies(choreKey) then
        local suppliesOk, suppliesMsg = hasEnoughSupplies(ranchId)
        if not suppliesOk then return cb(false, suppliesMsg) end
    end
    if choreKey == 'hay' or choreKey == 'water' or choreKey == 'cleanpoop' then
        local col = choreKey == 'hay' and 'last_hay_chore' or (choreKey == 'water' and 'last_water_chore' or 'last_cleanpoop_chore')
        local now = os.time()
        local cooldown = (tonumber(Config.Care.ChoreCooldownMinutes) or 10) * 60
        local last = tonumber(foal[col] or 0) or 0
        if last > 0 and now - last < cooldown then
            local left = math.ceil((cooldown - (now - last)) / 60)
            return cb(false, (Config.Text.choreCooldown or 'That chore is on cooldown.') .. (' Wait %s min.'):format(left))
        end
    end
    cb(true)
end)

BccUtils.RPC:Register('bcc-horsebreeding:DoHorseChore', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb(false) end
    local ranchId = tonumber(params.ranchId)
    local foalId = tonumber(params.foalId)
    local choreKey = tostring(params.chore or '')
    if not ranchId or not foalId or choreKey == '' then return cb(false) end
    if not isRanchAllowed(char.charIdentifier, ranchId) then return cb(false) end

    local foal = MySQL.single.await('SELECT * FROM bcc_horsebreeding_foals WHERE id = ? AND ranch_id = ? AND claimed = 0', { foalId, ranchId })
    if not foal or foal.stage == 'pregnancy' then return cb(false) end

    if choreKey == 'hay' or choreKey == 'water' or choreKey == 'cleanpoop' then
        local coolOk, coolMsg = checkAndSetChoreCooldown(foal, choreKey)
        if not coolOk then return cb(false, nil, coolMsg) end
    end
    if choreRequiresSupplies(choreKey) then
        local suppliesOk, suppliesMsg = consumeSupplies(ranchId)
        if not suppliesOk then return cb(false, nil, suppliesMsg) end
    end

    local chore = Config.Chores[choreKey]
    if chore and not tryRemoveCareItem(src, chore.action or choreKey) then return cb(false) end
    if choreKey == 'brush' and not tryRemoveCareItem(src, 'brush') then return cb(false) end

    if choreKey == 'hay' then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET hunger = LEAST(?, hunger + ?), bonding = LEAST(?, bonding + 2) WHERE id = ?', {
            Config.Care.MaxValue, Config.Care.FeedAmount, Config.Care.MaxValue, foalId
        })
    elseif choreKey == 'water' then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET thirst = LEAST(?, thirst + ?), bonding = LEAST(?, bonding + 2) WHERE id = ?', {
            Config.Care.MaxValue, Config.Care.WaterAmount, Config.Care.MaxValue, foalId
        })
    elseif choreKey == 'brush' then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET cleanliness = LEAST(?, cleanliness + ?), bonding = LEAST(?, bonding + 5), training = LEAST(?, training + 2) WHERE id = ?', {
            Config.Care.MaxValue, Config.Care.BrushAmount, Config.Care.MaxValue, Config.Care.MaxValue, foalId
        })
    elseif choreKey == 'feed_haycube' then
        if not tryRemoveCareItem(src, 'feed_haycube') then return cb(false) end
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET hunger = LEAST(?, hunger + ?), bonding = LEAST(?, bonding + ?) WHERE id = ?', {
            Config.Care.MaxValue, Config.Care.DirectFeedHayCubeAmount or 18, Config.Care.MaxValue, Config.Care.DirectFeedBondHayCubeAmount or 4, foalId
        })
    elseif choreKey == 'feed_sugarcube' then
        if not tryRemoveCareItem(src, 'feed_sugarcube') then return cb(false) end
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET hunger = LEAST(?, hunger + ?), bonding = LEAST(?, bonding + ?), training = LEAST(?, training + ?) WHERE id = ?', {
            Config.Care.MaxValue, Config.Care.DirectFeedSugarCubeAmount or 10, Config.Care.MaxValue, Config.Care.DirectFeedBondSugarCubeAmount or 8, Config.Care.MaxValue, Config.Care.DirectFeedTrainingSugarCubeAmount or 1, foalId
        })
    elseif choreKey == 'cleanpoop' then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET cleanliness = LEAST(?, cleanliness + ?), manure = LEAST(?, manure + ?) WHERE id = ?', {
            Config.Care.MaxValue, Config.Care.CleanPoopAmount, Config.Care.MaxValue, Config.Care.CleanPoopAmount, foalId
        })
    elseif choreKey == 'groundwork_lasso' then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET bonding = LEAST(?, bonding + ?), training = LEAST(?, training + ?) WHERE id = ?', {
            Config.Care.MaxValue, Config.PassiveTraining.LassoBondAmount or 3, Config.Care.MaxValue, Config.PassiveTraining.LassoTrainingAmount or 5, foalId
        })
    elseif choreKey == 'groundwork_ride' then
        MySQL.update.await('UPDATE bcc_horsebreeding_foals SET bonding = LEAST(?, bonding + ?), training = LEAST(?, training + ?) WHERE id = ?', {
            Config.Care.MaxValue, Config.PassiveTraining.RidingBondAmount or 2, Config.Care.MaxValue, Config.PassiveTraining.RidingTrainingAmount or 6, foalId
        })
    else
        return cb(false)
    end

    applyCareGrowthBonus(foalId)
    local updated = getFoalStatsRow(foalId)
    updated.message = choreCompleteMessage(choreKey)
    cb(true, updated)
end)



local function importAdultFoalToStables(foal, char, src, importName)
    if not foal or not char then return false, 'Missing foal or character.' end
    local name = tostring(importName or foal.name or 'Ranch Born Horse')
    if #name < 1 then name = 'Ranch Born Horse' end

    local careAverage = math.floor(((tonumber(foal.hunger) or 100) + (tonumber(foal.thirst) or 100) + (tonumber(foal.cleanliness) or 100)) / 3)
    local training = tonumber(foal.training) or 100
    local bonding = tonumber(foal.bonding) or 100
    local xp = math.random(Config.BornHorseDefaults.xpBonusMin, Config.BornHorseDefaults.xpBonusMax) + training + math.floor(bonding / 2)
    local health = clampCare(Config.BornHorseDefaults.health + math.floor(careAverage / 10))
    local stamina = clampCare(Config.BornHorseDefaults.stamina + math.floor(training / 10))

    local coalSource = foal.coal_appearance
    if not coalSource or coalSource == '' or coalSource == '{}' then
        coalSource = generateFoalCoalAppearance()
    end
    local coalAppearance = coalAppearanceForPlayerHorse(coalSource, Config.FoalScales.stableAdult or 1.0)
    local coalTackColors = '{}'
    local components = getCleanFoalComponents()

    ensurePlayerHorsesImportSchema()

    local ok, insertedOrErr = pcall(function()
        return MySQL.insert.await([[INSERT INTO player_horses (identifier, charid, selected, name, model, components, gender, xp, captured, health, stamina, dead, coal_appearance, coal_tack_colors)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)]], {
            char.identifier,
            char.charIdentifier,
            Config.BornHorseDefaults.selected,
            name,
            foal.model,
            components,
            foal.gender,
            xp,
            Config.BornHorseDefaults.captured,
            health,
            stamina,
            coalAppearance,
            coalTackColors
        })
    end)

    if not ok then
        local err = tostring(insertedOrErr)
        dprint('Auto/import insert failed: ' .. err)
        if src and src > 0 then notify(src, 'Import SQL failed: ' .. err, 12000) end
        return false, 'Import SQL failed: ' .. err
    end

    local inserted = tonumber(insertedOrErr) or 0
    if inserted <= 0 then
        return false, 'Import failed: player_horses insert returned no id.'
    end

    MySQL.update.await('DELETE FROM bcc_horsebreeding_foals WHERE id = ?', { foal.id })
    refreshFoalNumbersForRanch(foal.ranch_id)
    return true, inserted
end

BccUtils.RPC:Register('bcc-horsebreeding:ClaimFoal', function(params, cb, src)
    local char = getChar(src)
    if not char then return cb(false, Config.Text.failed or 'No character found.') end
    local foalId = tonumber(params.foalId)
    local name = tostring(params.name or 'Ranch Born Horse')
    if #name < 1 then name = 'Ranch Born Horse' end
    if not foalId then return cb(false, 'No foal selected.') end

    updateFoalStagesForRanch(tonumber(params.ranchId) or 0)
    local foal = MySQL.single.await('SELECT * FROM bcc_horsebreeding_foals WHERE id = ? AND claimed = 0', { foalId })
    if not foal then return cb(false, 'Foal not found or already claimed.') end
    if not isRanchAllowed(char.charIdentifier, foal.ranch_id) then return cb(false, Config.Text.failed or 'Not allowed at this ranch.') end
    if foal.stage ~= 'adult' then notify(src, Config.Text.notReady) return cb(false, Config.Text.notReady or 'That foal is not adult yet.') end

    local minCare = tonumber(Config.Care.MinCareToClaimAdult) or 0
    if tonumber(foal.hunger) < minCare or tonumber(foal.thirst) < minCare or tonumber(foal.cleanliness) < minCare then
        return cb(false, ('Adult needs at least %s hunger/thirst/cleanliness to import.'):format(minCare))
    end

    local careAverage = math.floor(((tonumber(foal.hunger) or 0) + (tonumber(foal.thirst) or 0) + (tonumber(foal.cleanliness) or 0)) / 3)
    local training = tonumber(foal.training) or 0
    local bonding = tonumber(foal.bonding) or 0
    local xp = math.random(Config.BornHorseDefaults.xpBonusMin, Config.BornHorseDefaults.xpBonusMax) + training + math.floor(bonding / 2)
    local health = clampCare(Config.BornHorseDefaults.health + math.floor(careAverage / 10))
    local stamina = clampCare(Config.BornHorseDefaults.stamina + math.floor(training / 10))

    local coalSource = foal.coal_appearance
    if not coalSource or coalSource == '' or coalSource == '{}' then
        coalSource = generateFoalCoalAppearance()
    end
    local coalAppearance = coalAppearanceForPlayerHorse(coalSource, Config.FoalScales.stableAdult or 1.0)
    local coalTackColors = '{}'
    local components = getCleanFoalComponents()

    ensurePlayerHorsesImportSchema()

    local ok, insertedOrErr = pcall(function()
        return MySQL.insert.await([[INSERT INTO player_horses (identifier, charid, selected, name, model, components, gender, xp, captured, health, stamina, dead, coal_appearance, coal_tack_colors)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)]], {
            char.identifier,
            char.charIdentifier,
            Config.BornHorseDefaults.selected,
            name,
            foal.model,
            components,
            foal.gender,
            xp,
            Config.BornHorseDefaults.captured,
            health,
            stamina,
            coalAppearance,
            coalTackColors
        })
    end)

    if not ok then
        local err = tostring(insertedOrErr)
        dprint('ClaimFoal insert failed: ' .. err)
        notify(src, 'Import SQL failed: ' .. err, 12000)
        return cb(false, 'Import SQL failed: ' .. err)
    end

    local inserted = tonumber(insertedOrErr) or 0
    if inserted > 0 then
        -- The adult is now a normal BCC stable horse, so remove the ranch foal row.
        MySQL.update.await('DELETE FROM bcc_horsebreeding_foals WHERE id = ?', { foalId })
        refreshFoalNumbersForRanch(foal.ranch_id)
        notify(src, Config.Text.claimed)
        return cb(true, Config.Text.claimed)
    end
    notify(src, 'Import failed: player_horses insert returned no id.', 12000)
    cb(false, 'Import failed: player_horses insert returned no id.')
end)



local function registerFoalCareUsableItems()
    if not Config.RegisterUsableFoalCareItems then return end
    if not exports or not exports.vorp_inventory or not exports.vorp_inventory.registerUsableItem then return end
    local items = Config.CareItems or {}

    local function closeInv(src)
        pcall(function() exports.vorp_inventory:closeInventory(src) end)
    end

    if items.brush then
        exports.vorp_inventory:registerUsableItem(items.brush, function(data)
            local src = data.source
            closeInv(src)
            TriggerClientEvent('bcc-horsebreeding:UseFoalCareItem', src, 'brush', items.brush)
        end)
    end
    if items.feed_haycube then
        exports.vorp_inventory:registerUsableItem(items.feed_haycube, function(data)
            local src = data.source
            closeInv(src)
            TriggerClientEvent('bcc-horsebreeding:UseFoalCareItem', src, 'haycube', items.feed_haycube)
        end)
    end
    if items.feed_sugarcube then
        exports.vorp_inventory:registerUsableItem(items.feed_sugarcube, function(data)
            local src = data.source
            closeInv(src)
            TriggerClientEvent('bcc-horsebreeding:UseFoalCareItem', src, 'sugarcube', items.feed_sugarcube)
        end)
    end
end

CreateThread(function()
    Wait(1500)
    registerFoalCareUsableItems()
end)


CreateThread(function()
    while true do
        Wait((Config.MareCare and Config.MareCare.PassiveCheckMinutes or 10) * 60000)
        if Config.MareCare and Config.MareCare.PassivePregnancyBoostEnabled then
            local bonus = tonumber(Config.MareCare.PassivePregnancyBonusSeconds) or 300
            local now = os.time()
            local rows = MySQL.query.await([[SELECT id, ranch_id FROM bcc_horsebreeding_foals WHERE claimed = 0 AND stage = 'pregnancy' AND pregnancy_end > ?]], { now + 60 }) or {}
            for _, row in ipairs(rows) do
                local ranchId = tonumber(row.ranch_id)
                local supplies = getSupplies(ranchId)
                if (tonumber(supplies.supplies) or 0) > 0 and breedingZoneHasCareLocations(ranchId) then
                    reducePregnancyTime(row.id, bonus)
                end
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait((Config.Care.DecayEveryMinutes or 60) * 60000)
        local amount = tonumber(Config.Care.DecayAmount) or 5
        MySQL.update.await([[UPDATE bcc_horsebreeding_foals
            SET hunger = GREATEST(0, hunger - ?), thirst = GREATEST(0, thirst - ?), cleanliness = GREATEST(0, cleanliness - ?), manure = GREATEST(0, manure - ?)
            WHERE claimed = 0 AND stage IN ('foal','young','adult')]], { amount, amount, amount, amount })
    end
end)
