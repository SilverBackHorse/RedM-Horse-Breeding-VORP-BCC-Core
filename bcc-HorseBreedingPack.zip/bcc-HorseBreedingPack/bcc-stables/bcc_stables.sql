-- BCC Stables SQL - safe/idempotent installer
-- Run after your framework inventory SQL so the `items` table exists.

CREATE TABLE IF NOT EXISTS `player_horses` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(50) NOT NULL,
  `charid` INT(11) NOT NULL,
  `selected` INT(11) NOT NULL DEFAULT 0,
  `name` VARCHAR(100) NOT NULL,
  `model` VARCHAR(100) NOT NULL,
  `components` LONGTEXT NULL,
  `gender` ENUM('male', 'female') DEFAULT 'male',
  `xp` INT(11) NOT NULL DEFAULT 0,
  `captured` INT(11) NOT NULL DEFAULT 0,
  `born` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `health` INT(11) NOT NULL DEFAULT 50,
  `stamina` INT(11) NOT NULL DEFAULT 50,
  `writhe` INT(11) NOT NULL DEFAULT 0,
  `dead` INT(11) NOT NULL DEFAULT 0,
  `breedable` TINYINT(1) DEFAULT NULL,
  `inBreed` TINYINT(1) DEFAULT NULL,
  `coal_appearance` LONGTEXT DEFAULT NULL,
  `coal_tack_colors` LONGTEXT DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Compatibility helpers: avoids MySQL/MariaDB version problems with ADD COLUMN IF NOT EXISTS / CREATE INDEX IF NOT EXISTS.
DROP PROCEDURE IF EXISTS `bcc_safe_add_column`;
DELIMITER $$
CREATE PROCEDURE `bcc_safe_add_column`(IN p_table VARCHAR(64), IN p_column VARCHAR(64), IN p_definition TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND COLUMN_NAME = p_column
  ) THEN
    SET @sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS `bcc_safe_add_index`;
DELIMITER $$
CREATE PROCEDURE `bcc_safe_add_index`(IN p_table VARCHAR(64), IN p_index VARCHAR(64), IN p_definition TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND INDEX_NAME = p_index
  ) THEN
    SET @sql = CONCAT('CREATE INDEX `', p_index, '` ON `', p_table, '` ', p_definition);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;
END$$
DELIMITER ;

CALL `bcc_safe_add_column`('player_horses', 'selected', 'INT(11) NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('player_horses', 'components', 'LONGTEXT NULL');
CALL `bcc_safe_add_column`('player_horses', 'gender', "ENUM('male', 'female') DEFAULT 'male'");
CALL `bcc_safe_add_column`('player_horses', 'xp', 'INT(11) NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('player_horses', 'captured', 'INT(11) NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('player_horses', 'born', 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP');
CALL `bcc_safe_add_column`('player_horses', 'health', 'INT(11) NOT NULL DEFAULT 50');
CALL `bcc_safe_add_column`('player_horses', 'stamina', 'INT(11) NOT NULL DEFAULT 50');
CALL `bcc_safe_add_column`('player_horses', 'writhe', 'INT(11) NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('player_horses', 'dead', 'INT(11) NOT NULL DEFAULT 0');
CALL `bcc_safe_add_column`('player_horses', 'breedable', 'TINYINT(1) DEFAULT NULL');
CALL `bcc_safe_add_column`('player_horses', 'inBreed', 'TINYINT(1) DEFAULT NULL');
CALL `bcc_safe_add_column`('player_horses', 'coal_appearance', 'LONGTEXT DEFAULT NULL');
CALL `bcc_safe_add_column`('player_horses', 'coal_tack_colors', 'LONGTEXT DEFAULT NULL');

ALTER TABLE `player_horses` MODIFY COLUMN `components` LONGTEXT NULL;
CALL `bcc_safe_add_index`('player_horses', 'idx_charid', '(`charid`)');
CALL `bcc_safe_add_index`('player_horses', 'idx_identifier', '(`identifier`)');

-- Requires your framework `items` table to already exist.
INSERT INTO `items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`, `desc`)
VALUES
  ('oil_lantern', 'Oil Lantern', 1, 1, 'item_standard', 1, 'A portable light source.'),
  ('consumable_horse_reviver', 'Horse Reviver', 3, 1, 'item_standard', 1, 'Curative compound for injured horse.'),
  ('consumable_haycube', 'Haycube', 10, 1, 'item_standard', 1, 'A compact cube of hay.'),
  ('horsebrush', 'Horse Brush', 5, 1, 'item_standard', 1, 'A brush used for grooming horses.'),
  ('consumable_apple', 'Apple', 10, 1, 'item_standard', 1, 'A juicy and delicious fruit.'),
  ('consumable_carrots', 'Carrots', 10, 1, 'item_standard', 1, 'An orange root vegetable commonly used in cooking.'),
  ('diamond', 'Diamond', 20, 1, 'item_standard', 1, 'A precious gemstone known for its brilliance and value.')
ON DUPLICATE KEY UPDATE
  `label`=VALUES(`label`),
  `limit`=VALUES(`limit`),
  `can_remove`=VALUES(`can_remove`),
  `type`=VALUES(`type`),
  `usable`=VALUES(`usable`),
  `desc`=VALUES(`desc`);

DROP PROCEDURE IF EXISTS `bcc_safe_add_column`;
DROP PROCEDURE IF EXISTS `bcc_safe_add_index`;
