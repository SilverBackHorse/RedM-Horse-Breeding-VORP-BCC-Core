Horses = { -- Gold to Dollar Ratio Based on 1899 Gold Price / sellPrice is 60% of cashPrice / Cash Price is Regular Game Price
	{
		breed = 'American Paint',
		colors = {-- Only Players with Specified Job will See that Horse to Purchase in the Menu
			['a_c_horse_americanpaint_greyovero']     = { color = 'Grey Overo',     cashPrice = 1425, goldPrice = 120, invLimit = 200, job = {} }, -- Job Example: {'police', 'doctor'}
            ['a_c_horse_americanpaint_overo']         = { color = 'Overo',          cashPrice = 1130, goldPrice = 116,  invLimit = 200, job = {} },
			['a_c_horse_americanpaint_splashedwhite'] = { color = 'Splashed White', cashPrice = 1140, goldPrice = 116,  invLimit = 200, job = {} },
			['a_c_horse_americanpaint_tobiano']       = { color = 'Tobiano',        cashPrice = 1140, goldPrice = 116,  invLimit = 200, job = {} },
		}
	},
	{
		breed = 'American Standardbred',
		colors = {
            ['a_c_horse_americanstandardbred_black']              = { color = 'Black',                cashPrice = 1130, goldPrice = 116,  invLimit = 200, job = {} },
            ['a_c_horse_americanstandardbred_buckskin']           = { color = 'Buckskin',             cashPrice = 1130, goldPrice = 116,  invLimit = 200, job = {} },
            ['a_c_horse_americanstandardbred_lightbuckskin']      = { color = 'Light Buckskin',       cashPrice = 1130, goldPrice = 116,  invLimit = 200, job = {} },
            ['a_c_horse_americanstandardbred_palominodapple']     = { color = 'Palomino Dapple',      cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
            ['a_c_horse_americanstandardbred_silvertailbuckskin'] = { color = 'Silver Tail Buckskin', cashPrice = 1400, goldPrice = 119, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Andalusian',
		colors = {
            ['a_c_horse_andalusian_darkbay']  = { color = 'Dark Bay',  cashPrice = 1140, goldPrice = 116,  invLimit = 200, job = {} },
			['a_c_horse_andalusian_perlino']  = { color = 'Perlino',   cashPrice = 1450, goldPrice = 121, invLimit = 200, job = {} },
			['a_c_horse_andalusian_rosegray'] = { color = 'Rose Gray', cashPrice = 1440, goldPrice = 121, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Appaloosa',
		colors = {
			['a_c_horse_appaloosa_blacksnowflake'] = { color = 'Snow Flake',     cashPrice = 1900, goldPrice = 143, invLimit = 200, job = {} },
            ['a_c_horse_appaloosa_blanket']        = { color = 'Blanket',        cashPrice = 1200, goldPrice = 19,  invLimit = 200, job = {} },
			['a_c_horse_appaloosa_brownleopard']   = { color = 'Brown Leopard',  cashPrice = 1450, goldPrice = 121, invLimit = 200, job = {} },
            ['a_c_horse_appaloosa_fewspotted_pc']  = { color = 'Few Spotted',    cashPrice = 140, goldPrice = 1116,  invLimit = 200, job = {} },
			['a_c_horse_appaloosa_leopard']        = { color = 'Leopard',        cashPrice = 1430, goldPrice = 120, invLimit = 200, job = {} },
			['a_c_horse_appaloosa_leopardblanket'] = { color = 'Lepard Blanket', cashPrice = 1130, goldPrice = 116,  invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Arabian',
		colors = {
            ['a_c_horse_arabian_black']            = { color = 'Black',           cashPrice = 1250, goldPrice = 160, invLimit = 200 ,job = {} },
            ['a_c_horse_arabian_grey']             = { color = 'Grey',            cashPrice = 1150, goldPrice = 155, invLimit = 200 ,job = {} },
            ['a_c_horse_arabian_redchestnut']      = { color = 'Red Chestnut',    cashPrice = 1350,  goldPrice = 116, invLimit = 200 ,job = {} },
			['a_c_horse_arabian_redchestnut_pc']   = { color = 'Red Chestnut II', cashPrice = 1350,  goldPrice = 116, invLimit = 200 ,job = {} },
            ['a_c_horse_arabian_rosegreybay']      = { color = 'Rose Grey Bay',   cashPrice = 1350, goldPrice = 65, invLimit = 200, job = {} },
			['a_c_horse_arabian_warpedbrindle_pc'] = { color = 'Warped Brindle',  cashPrice = 1650,  goldPrice = 131, invLimit = 200 ,job = {} },
			['a_c_horse_arabian_white']            = { color = 'White',           cashPrice = 2500, goldPrice = 172, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Ardennes',
		colors = {
            ['a_c_horse_ardennes_bayroan']        = { color = 'Bay Roan',        cashPrice = 1140,  goldPrice = 116,  invLimit = 200, job = {} },
			['a_c_horse_ardennes_irongreyroan']   = { color = 'Iron Grey Roan',  cashPrice = 1200, goldPrice = 158, invLimit = 200, job = {} },
			['a_c_horse_ardennes_strawberryroan'] = { color = 'Strawberry Roan', cashPrice = 1450,  goldPrice = 121, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Belgian Draft',
		colors = {
			['a_c_horse_belgian_blondchestnut'] = { color = 'Blond Chestnut', cashPrice = 1120, goldPrice = 115, invLimit = 200, job = {} },
			['a_c_horse_belgian_mealychestnut'] = { color = 'Mealy Chestnut', cashPrice = 1120, goldPrice = 115, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Breton',
		colors = {
			['a_c_horse_breton_grullodun']      = { color = 'Grullo Dun',    cashPrice = 1550, goldPrice = 126, invLimit = 200, job = {} },
			['a_c_horse_breton_mealydapplebay'] = { color = 'Meally Dapple', cashPrice = 1950, goldPrice = 145, invLimit = 200, job = {} },
			['a_c_horse_breton_redroan']        = { color = 'Red Roan',      cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
			['a_c_horse_breton_sealbrown']      = { color = 'Seal Brown',    cashPrice = 1550, goldPrice = 126, invLimit = 200, job = {} },
			['a_c_horse_breton_sorrel']         = { color = 'Sorrel',        cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
			['a_c_horse_breton_steelgrey']      = { color = 'Steel Grey',    cashPrice = 1950, goldPrice = 145, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Criollo',
		colors = {
			['a_c_horse_criollo_baybrindle']    = { color = 'Bay Brindle',     cashPrice = 1550, goldPrice = 126, invLimit = 200, job = {} },
			['a_c_horse_criollo_bayframeovero'] = { color = 'Bay Frame Overo', cashPrice = 1950, goldPrice = 145, invLimit = 200, job = {} },
			['a_c_horse_criollo_blueroanovero'] = { color = 'Blue Roan Overo', cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
			['a_c_horse_criollo_dun']           = { color = 'Dun',             cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
			['a_c_horse_criollo_marblesabino']  = { color = 'Marble Sabino',   cashPrice = 1950, goldPrice = 145, invLimit = 200, job = {} },
			['a_c_horse_criollo_sorrelovero']   = { color = 'Sorrel Overo',    cashPrice = 1550, goldPrice = 126, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Dutch Warmblood',
		colors = {
			['a_c_horse_dutchwarmblood_chocolateroan'] = { color = 'Chocolate Roan', cashPrice = 1450, goldPrice = 121, invLimit = 200, job = {} },
			['a_c_horse_dutchwarmblood_sealbrown']     = { color = 'Seal Brown',     cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
			['a_c_horse_dutchwarmblood_sootybuckskin'] = { color = 'Sooty Buckskin', cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Gypsy Cob',
		colors = {
			['a_c_horse_gypsycob_palominoblagdon'] = { color = 'Palomino Blagdon', cashPrice = 1550, goldPrice = 126, invLimit = 200, job = {} },
			['a_c_horse_gypsycob_piebald']         = { color = 'Piebald',          cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
			['a_c_horse_gypsycob_skewbald']        = { color = 'Skewbald',         cashPrice = 1550, goldPrice = 126, invLimit = 200, job = {} },
			['a_c_horse_gypsycob_splashedbay']     = { color = 'Splashed Bay',     cashPrice = 1950, goldPrice = 145, invLimit = 200, job = {} },
			['a_c_horse_gypsycob_splashedpiebald'] = { color = 'Splashed Piebald', cashPrice = 1950, goldPrice = 145, invLimit = 200, job = {} },
			['a_c_horse_gypsycob_whiteblagdon']    = { color = 'White Blagdon',    cashPrice = 1150, goldPrice = 117,  invLimit = 250, job = {} },
		}
	},
	{
		breed = 'Hungarian Halfbred',
		colors = {
			['a_c_horse_hungarianhalfbred_darkdapplegrey'] = { color = 'Dapple Dark Grey', cashPrice = 1150, goldPrice = 117, invLimit = 200, job = {} },
            ['a_c_horse_hungarianhalfbred_flaxenchestnut'] = { color = 'Flaxen Chestnut',  cashPrice = 1130, goldPrice = 116, invLimit = 200, job = {} },
			['a_c_horse_hungarianhalfbred_liverchestnut']  = { color = 'Liver Chestnut',   cashPrice = 1150, goldPrice = 117, invLimit = 200, job = {} },
			['a_c_horse_hungarianhalfbred_piebaldtobiano'] = { color = 'Piebald Tobiano',  cashPrice = 1130, goldPrice = 116, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Kentucky Saddler',
		colors = {
            ['a_c_horse_kentuckysaddle_black']                 = { color = 'Black',               cashPrice = 50,  goldPrice = 2,  invLimit = 200, job = {} },
			['a_c_horse_kentuckysaddle_buttermilkbuckskin_pc'] = { color = 'Buttermilk Buckskin', cashPrice = 1240, goldPrice = 111, invLimit = 200, job = {} },
			['a_c_horse_kentuckysaddle_chestnutpinto']         = { color = 'Chestnut Pinto',      cashPrice = 1150,  goldPrice = 112,  invLimit = 200, job = {} },
			['a_c_horse_kentuckysaddle_grey']                  = { color = 'Grey',                cashPrice = 1150,  goldPrice = 112,  invLimit = 200, job = {} },
			['a_c_horse_kentuckysaddle_silverbay']             = { color = 'Silver Bay',          cashPrice = 1150,  goldPrice = 112,  invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Kladruber',
		colors = {
			['a_c_horse_kladruber_black']          = { color = 'Black',            cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
			['a_c_horse_kladruber_cremello']       = { color = 'Cremello',         cashPrice = 1550, goldPrice = 126, invLimit = 200, job = {} },
			['a_c_horse_kladruber_dapplerosegrey'] = { color = 'Dapple Rose Grey', cashPrice = 1950, goldPrice = 145, invLimit = 200, job = {} },
			['a_c_horse_kladruber_grey']           = { color = 'Grey',             cashPrice = 1550, goldPrice = 126, invLimit = 200, job = {} },
			['a_c_horse_kladruber_silver']         = { color = 'Silver',           cashPrice = 1950, goldPrice = 145, invLimit = 200, job = {} },
			['a_c_horse_kladruber_white']          = { color = 'White',            cashPrice = 1150, goldPrice = 117,  invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Missouri Fox Trotter',
		colors = {
			['a_c_horse_missourifoxtrotter_amberchampagne']    = { color = 'Amber Champagne',     cashPrice = 1950,  goldPrice = 145, invLimit = 200, job = {} },
            ['a_c_horse_missourifoxtrotter_blacktovero']       = { color = 'Black Tovero',        cashPrice = 1125, goldPrice = 154, invLimit = 200, job = {} },
            ['a_c_horse_missourifoxtrotter_blueroan']          = { color = 'Blue Roan',           cashPrice = 1125, goldPrice = 154, invLimit = 200, job = {} },
            ['a_c_horse_missourifoxtrotter_buckskinbrindle']   = { color = 'Buckskin Brindle',    cashPrice = 1125, goldPrice = 154, invLimit = 200, job = {} },
            ['a_c_horse_missourifoxtrotter_dapplegrey']        = { color = 'Dapple Grey',         cashPrice = 1125, goldPrice = 154, invLimit = 200, job = {} },
			['a_c_horse_missourifoxtrotter_sablechampagne']    = { color = 'Sable Champagne',     cashPrice = 1950,  goldPrice = 145, invLimit = 200, job = {} },
			['a_c_horse_missourifoxtrotter_silverdapplepinto'] = { color = 'Silver Dapple Pinto', cashPrice = 1950,  goldPrice = 1415, invLimit = 200, job = {} },			
		}
	},
	{
		breed = 'Morgan',
		colors = {
			['a_c_horse_morgan_bay']              = { color = 'Bay',             cashPrice = 1155, goldPrice = 112, invLimit = 200, job = {} },
			['a_c_horse_morgan_bayroan']          = { color = 'Bay Roan',        cashPrice = 1155, goldPrice = 112, invLimit = 200, job = {} },
			['a_c_horse_morgan_flaxenchestnut']   = { color = 'Flaxen Chestnut', cashPrice = 1155, goldPrice = 112, invLimit = 200, job = {} },
			['a_c_horse_morgan_liverchestnut_pc'] = { color = 'Liver Chestnut',  cashPrice = 1155, goldPrice = 112, invLimit = 200, job = {} },
            ['a_c_horse_morgan_palomino']         = { color = 'Palomino',        cashPrice = 15, goldPrice = 1, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Mustang',
		colors = {
            ['a_c_horse_mustang_blackovero']      = { color = 'Black Overo',       cashPrice = 500, goldPrice = 24, invLimit = 200, job = {} },
			['a_c_horse_mustang_buckskin']        = { color = 'Buckskin',          cashPrice = 500, goldPrice = 24, invLimit = 200, job = {} },
            ['a_c_horse_mustang_chestnuttovero']  = { color = 'Chestnut Tovero',   cashPrice = 500, goldPrice = 24, invLimit = 200, job = {} },
			['a_c_horse_mustang_goldendun']       = { color = 'Golden Dun',        cashPrice = 500, goldPrice = 24, invLimit = 200, job = {} },
            ['a_c_horse_mustang_grullodun']       = { color = 'Grullo Dun',        cashPrice = 130, goldPrice = 6,  invLimit = 200, job = {} },
            ['a_c_horse_mustang_reddunovero']     = { color = 'Red Dun Overo',     cashPrice = 500, goldPrice = 24, invLimit = 200, job = {} },
			['a_c_horse_mustang_tigerstripedbay'] = { color = 'Tiger Striped Bay', cashPrice = 350, goldPrice = 16, invLimit = 200, job = {} },
			['a_c_horse_mustang_wildbay']         = { color = 'Wild Bay',          cashPrice = 130, goldPrice = 6,  invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Nokota',
		colors = {
            ['a_c_horse_nokota_blueroan']          = { color = 'Blue Roan',           cashPrice = 130, goldPrice = 6,  invLimit = 200, job = {} },
			['a_c_horse_nokota_reversedappleroan'] = { color = 'Reverse Dapple Roan', cashPrice = 450, goldPrice = 21, invLimit = 200, job = {} },
			['a_c_horse_nokota_whiteroan']         = { color = 'White Roan',          cashPrice = 130, goldPrice = 6 , invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Norfolk Roadster',
		colors = {
			['a_c_horse_norfolkroadster_black']           = { color = 'Black',            cashPrice = 150, goldPrice = 7,  invLimit = 200, job = {} },
			['a_c_horse_norfolkroadster_dappledbuckskin'] = { color = 'Dappled Buckskin', cashPrice = 950, goldPrice = 45, invLimit = 200, job = {} },
			['a_c_horse_norfolkroadster_piebaldroan']     = { color = 'Piebald Roan',     cashPrice = 550, goldPrice = 26, invLimit = 200, job = {} },
			['a_c_horse_norfolkroadster_rosegrey']        = { color = 'Rose Grey',        cashPrice = 550, goldPrice = 26, invLimit = 200, job = {} },
			['a_c_horse_norfolkroadster_speckledgrey']    = { color = 'Speckled Grey',    cashPrice = 150, goldPrice = 7,  invLimit = 200, job = {} },
			['a_c_horse_norfolkroadster_spottedtricolor'] = { color = 'Spotted Tricolor', cashPrice = 950, goldPrice = 45, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Shire',
		colors = {
            ['a_c_horse_shire_darkbay']    = { color = 'Dark Bay',    cashPrice = 120, goldPrice = 5, invLimit = 200, job = {} },
			['a_c_horse_shire_lightgrey']  = { color = 'Light Grey',  cashPrice = 120, goldPrice = 5, invLimit = 200, job = {} },
			['a_c_horse_shire_ravenblack'] = { color = 'Raven Black', cashPrice = 130, goldPrice = 6, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Suffolk Punch',
		colors = {
			['a_c_horse_suffolkpunch_redchestnut'] = { color = 'Red Chestnut', cashPrice = 120, goldPrice = 5, invLimit = 200, job = {} },
			['a_c_horse_suffolkpunch_sorrel']      = { color = 'Sorrel',       cashPrice = 120, goldPrice = 5, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Tennessee Walker',
		colors = {
			['a_c_horse_tennesseewalker_blackrabicano']   = { color = 'Black Rabicano', cashPrice = 60,  goldPrice = 3, invLimit = 200, job = {} },
			['a_c_horse_tennesseewalker_chestnut']        = { color = 'Chestnut',       cashPrice = 60,  goldPrice = 3, invLimit = 200, job = {} },
			['a_c_horse_tennesseewalker_dapplebay']       = { color = 'Dapple Bay',     cashPrice = 60,  goldPrice = 3, invLimit = 200, job = {} },
            ['a_c_horse_tennesseewalker_flaxenroan']      = { color = 'Flaxen Roan',    cashPrice = 150, goldPrice = 7, invLimit = 200, job = {} },
            ['a_c_horse_tennesseewalker_goldpalomino_pc'] = { color = 'Gold Palomino',  cashPrice = 60,  goldPrice = 3, invLimit = 200, job = {} },
			['a_c_horse_tennesseewalker_mahoganybay']     = { color = 'Mahogany Bay',   cashPrice = 60,  goldPrice = 3, invLimit = 200, job = {} },
			['a_c_horse_tennesseewalker_redroan']         = { color = 'Red Roan',       cashPrice = 60,  goldPrice = 3, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Thoroughbred',
		colors = {
			['a_c_horse_thoroughbred_blackchestnut']      = { color = 'Black Chestnut', cashPrice = 550, goldPrice = 26, invLimit = 200, job = {} },
			['a_c_horse_thoroughbred_bloodbay']           = { color = 'Blood Bay',      cashPrice = 130, goldPrice = 6,  invLimit = 200, job = {} },
			['a_c_horse_thoroughbred_brindle']            = { color = 'Brindle',        cashPrice = 450, goldPrice = 21, invLimit = 200, job = {} },
            ['a_c_horse_thoroughbred_dapplegrey']         = { color = 'Dapple Grey',    cashPrice = 130, goldPrice = 6,  invLimit = 200, job = {} },
			['a_c_horse_thoroughbred_reversedappleblack'] = { color = 'Dapple Black',   cashPrice = 550, goldPrice = 26, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Turkoman',
		colors = {
            ['a_c_horse_turkoman_black']    = { color = 'Black',    cashPrice = 1000, goldPrice = 48, invLimit = 200, job = {} },
			['a_c_horse_turkoman_chestnut'] = { color = 'Chestnut', cashPrice = 1000, goldPrice = 48, invLimit = 200, job = {} },
            ['a_c_horse_turkoman_darkbay']  = { color = 'Dark Bay', cashPrice = 925,  goldPrice = 44, invLimit = 200, job = {} },
			['a_c_horse_turkoman_gold']     = { color = 'Gold',     cashPrice = 950,  goldPrice = 45, invLimit = 200, job = {} },
            ['a_c_horse_turkoman_grey']     = { color = 'Grey',     cashPrice = 1000, goldPrice = 48, invLimit = 200, job = {} },
            ['a_c_horse_turkoman_perlino']  = { color = 'Perlino',  cashPrice = 1000, goldPrice = 48, invLimit = 200, job = {} },
			['a_c_horse_turkoman_silver']   = { color = 'Silver',   cashPrice = 950,  goldPrice = 45, invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Special',
		colors = {
            ['a_c_horse_buell_warvets']              = { color = 'Cremello Gold', cashPrice = 600,  goldPrice = 29,  invLimit = 200, job = {} },
			['a_c_horse_eagleflies']                 = { color = 'Eagle Flies',   cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_bill']                  = { color = 'Brown Jack',    cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_charles']               = { color = 'Spot',          cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_charles_endlesssummer'] = { color = 'Falmouth',      cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_dutch']                 = { color = 'Arthur',        cashPrice = 2500, goldPrice = 120, invLimit = 200, job = {} },
			['a_c_horse_gang_hosea']                 = { color = 'Silver Dollar', cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_javier']                = { color = 'Boaz',          cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_john']                  = { color = 'Old Boy',       cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_karen']                 = { color = 'Old Belle',     cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_kieran']                = { color = 'Branwen',       cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_lenny']                 = { color = 'Mag',           cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_micah']                 = { color = 'Ghost',         cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_sadie']                 = { color = 'Bob',           cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_sadie_endlesssummer']   = { color = 'Sadie',         cashPrice = 1500, goldPrice = 72,  invLimit = 200, job = {} },
			['a_c_horse_gang_sean']                  = { color = 'Ennis',         cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_trelawney']             = { color = 'Gwydion',       cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_uncle']                 = { color = 'Nell 1',        cashPrice = 2000, goldPrice = 97,  invLimit = 200, job = {} },
			['a_c_horse_gang_uncle_endlesssummer']   = { color = 'Nell 2',        cashPrice = 1500, goldPrice = 72,  invLimit = 200, job = {} },
            ['a_c_horse_john_endlesssummer']         = { color = 'John',          cashPrice = 1500, goldPrice = 72,  invLimit = 200, job = {} },
		}
	},
	{
		breed = 'Other',
		colors = {
            ['a_c_donkey_01']                   = { color = 'Donkey',  cashPrice = 15, goldPrice = 1, invLimit = 200, job = {} },
			['a_c_horse_mp_mangy_backup']       = { color = 'Mangy',   cashPrice = 15, goldPrice = 1, invLimit = 200, job = {} },
			['a_c_horsemule_01']                = { color = 'Mule',    cashPrice = 15, goldPrice = 1, invLimit = 200, job = {} },
			['a_c_horsemulepainted_01']         = { color = 'Zebra',   cashPrice = 15, goldPrice = 1, invLimit = 200, job = {} },
            ['a_c_horse_murfreebrood_mange_01'] = { color = 'Mange 1', cashPrice = 15, goldPrice = 1, invLimit = 200, job = {} },
            ['a_c_horse_murfreebrood_mange_02'] = { color = 'Mange 2', cashPrice = 15, goldPrice = 1, invLimit = 200, job = {} },
            ['a_c_horse_murfreebrood_mange_03'] = { color = 'Mange 3', cashPrice = 15, goldPrice = 1, invLimit = 200, job = {} },
		}
	}
}
