BCC Horse Breeding Pack SQL Install

Recommended install:
1. Import INSTALL_ALL_HORSEBREEDING_PACK.sql once.
2. You do NOT need to import the other SQL files if you use this all-in-one installer.
3. It is safe to run again if a user already has player_horses/BCC Stables installed.

What it does:
- Creates player_horses if missing.
- Adds missing BCC Stables columns if player_horses already exists.
- Adds Coal columns: coal_appearance and coal_tack_colors.
- Makes player_horses.components LONGTEXT NULL.
- Creates all bcc_horsebreeding tables.
- Creates coal_stables_horses.
- Inserts BCC Stables item rows only if the framework items table exists.

If someone already imported the old SQLs, they can still run this installer to patch missing columns.
