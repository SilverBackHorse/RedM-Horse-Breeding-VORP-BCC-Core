        --"mp_horselantern_harness_001",
        --"mp_horselantern_harness_001_ab",
        --"mp_horselantern_harness_001_nm",
        --"mp_horselantern_harness_001_m"

--=====================================================================
--  COAL COUNTY TACK CATALOGUE
--=====================================================================
CoalTack = CoalTack or {}
local T = CoalTack

-- Shared MetaPed tint palettes for tack tints
-- If Beauty_Menu has already created B.PALETTES, reuse it.
-- Otherwise fall back to a local copy so Tack still works on its own.
local T_PALETTES = (CoalBeauty and CoalBeauty._data and CoalBeauty._data.PALETTES) or {
    P1  = "metaped_tint_horse",
    P2  = "metaped_tint_horse_leather",
    P3  = "metaped_tint_generic",
    P4  = "metaped_tint_animal",
    P5  = "metaped_tint_combined_leather",
    P6  = "metaped_tint_genericclean",
    P7  = "metaped_tint_eye",
    P8  = "metaped_tint_hair",
    P9  = "metaped_tint_leather",
    P10 = "metaped_tint_hat",
    P11 = "metaped_tint_mpadv",
    P12 = "metaped_tint_makeup",
    P13 = "metaped_tint_generic_weathered",
}

-- Categories shown in the Tack & Services main menu
-- Order here is the order you see on the left side of the menu
T.Categories = {
    { id = "harness",        label = "Harness"         },
    { id = "bridles",        label = "Bridle"          },
    { id = "blankets",       label = "Blanket"         },
    { id = "blanket_tint0",  label = "Blanket Tint 0"  },
    { id = "blanket_tint1",  label = "Blanket Tint 1"  },
    { id = "blanket_tint2",  label = "Blanket Tint 2"  },

    { id = "saddles",        label = "Saddle"          },
    { id = "saddle_tint0",   label = "Saddle Tint 0"   },
    { id = "saddle_tint1",   label = "Saddle Tint 1"   },
    { id = "saddle_tint2",   label = "Saddle Tint 2"   },

    -- 🔽 NEW
    { id = "stirrups",       label = "Stirrups"        },
    { id = "stirrups_tint0", label = "Stirrup Tint 0"  },
    { id = "stirrups_tint1", label = "Stirrup Tint 1"  },
    { id = "stirrups_tint2", label = "Stirrup Tint 2"  },

    { id = "saddlebags",      label = "Saddlebags"        },
    { id = "saddlebags_tint0",label = "Saddlebag Tint 0"  },
    { id = "saddlebags_tint1",label = "Saddlebag Tint 1"  },
    { id = "saddlebags_tint2",label = "Saddlebag Tint 2"  },

    { id = "bedrolls",        label = "Bedrolls"          },
    { id = "bedroll_tint0",   label = "Bedroll Tint 0"    },
    { id = "bedroll_tint1",   label = "Bedroll Tint 1"    },
    { id = "bedroll_tint2",   label = "Bedroll Tint 2"    },

    { id = "holsters",        label = "holster"          },
    { id = "holsters_tint0",  label = "holsters Tint 0"   },
    { id = "holsters_tint1",  label = "holsters Tint 1"   },
    { id = "holsters_tint2",  label = "holsters Tint 2"   },
    { id = "horns",        label = "Horns" },
    { id = "horns_tint0",  label = "Horn Tint 0" },
    { id = "horns_tint1",  label = "Horn Tint 1" },
    { id = "horns_tint2",  label = "Horn Tint 2" },
}



-- Helper: build P1–P8 tint items for a single drawable/material
local function BuildTackTintList(baseIdPrefix, baseLabelPrefix, drawable, albedo, normal, material)
    local list = {}

    -- "no tint" option
    table.insert(list, {
        id      = baseIdPrefix .. "_none",
        label   = "No " .. baseLabelPrefix,
        price   = 0,
        desc    = "Use the default " .. string.lower(baseLabelPrefix) .. ".",
        -- no palette / tint fields => nothing applied
    })

    local palettes = {
        { key = "P1", order = 1, suffix = " (P1)" },
        { key = "P2", order = 2, suffix = " (P2)" },
        { key = "P3", order = 3, suffix = " (P3)" },
        { key = "P4", order = 4, suffix = " (P4)" },
        { key = "P5", order = 5, suffix = " (P5)" },
        { key = "P6", order = 6, suffix = " (P6)" },
        { key = "P7", order = 7, suffix = " (P7)" },
        { key = "P8", order = 8, suffix = " (P8)" },
    }

    for _, p in ipairs(palettes) do
        -- Only allow 2–254 so 0/1 are never offered
        for i = 2, 254 do
            table.insert(list, {
                id      = string.format("%s_%s_%d", baseIdPrefix, p.key, i),
                label   = string.format("%s %d%s", baseLabelPrefix, i, p.suffix),
                price   = 1,
                desc    = string.format("%s tint index %d%s", baseLabelPrefix, i, p.suffix),

                sortIndex = p.order * 1000 + i,

                palette = T_PALETTES[p.key],
                tint0   = i,
                tint1   = i,
                tint2   = i,

                drawable = drawable,
                albedo   = albedo,
                normal   = normal,
                material = material,
            })
        end
    end


    return list
end

-- 
--
-- =========================================================
-- OFFLINE BLANKET SUPPORT (from data/blankets.json)
-- =========================================================
local function LoadOfflineBlankets(list)
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/blankets.json")
    if not raw then return end

    local decoded = json.decode(raw)
    for i, rec in ipairs(decoded) do
        table.insert(list, {
            id = "blanket_" .. i,
            label = rec.name,
            desc = "Offline blanket",
            price = 80,

            -- shop info
            shopItemHash = GetHashKey(rec.name),

            -- tint + palette
            palette = rec.palette,
            tint0 = rec.tint0,
            tint1 = rec.tint1,
            tint2 = rec.tint2,

            -- swatch (for menu color chips)
            swatchTexture = rec.swatchTexture,
            swatchPalette = rec.swatchPalette,
            swatchTint0 = rec.swatchTint0,
            swatchTint1 = rec.swatchTint1,
            swatchTint2 = rec.swatchTint2,

            -- mesh/material data
            drawable = rec.drawable,
            albedo   = rec.albedo,
            normal   = rec.normal,
            material = rec.material,
        })
    end
end

-----------------------------------------------------------------------------
-- =========================================================
--  data/saddles.json
-- =========================================================
local function CoalTack_LoadOfflineSaddles(list)
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/saddles.json")
    if not raw or raw == "" then
        print("[CoalTack] saddles.json optional/empty; skipping offline saddles.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[CoalTack] ERROR decoding saddles.json:", decoded)
        return
    end

    local added = 0
    for i, rec in ipairs(decoded) do
        local name = rec.name
        if type(name) == "string" and name ~= "" then
            local assets = rec.assets
            if (not assets or type(assets) ~= "table" or #assets == 0) and rec.drawable then
                assets = {
                    {
                        drawable = rec.drawable,
                        albedo   = rec.albedo,
                        normal   = rec.normal,
                        material = rec.material,
                        palette  = rec.palette,
                        tint0    = rec.tint0,
                        tint1    = rec.tint1,
                        tint2    = rec.tint2,
                    }
                }
            end

            table.insert(list, {
                id            = string.format("saddle_offline_%03d", i),
                label         = rec.label or name,
                price         = tonumber(rec.price) or 80,
                desc          = "Imported saddle from the offline item database.",
                shopItemHash  = GetHashKey(name),
                rawName       = name,
                name          = name,
                source        = "offline",
                swatchTexture = rec.swatchTexture,
                swatchPalette = rec.swatchPalette,
                swatchTint0   = rec.swatchTint0,
                swatchTint1   = rec.swatchTint1,
                swatchTint2   = rec.swatchTint2,
                palette       = rec.palette,
                tint0         = rec.tint0,
                tint1         = rec.tint1,
                tint2         = rec.tint2,
                assets        = assets or {},
            })

            added = added + 1
        end
    end

    print(("[CoalTack] Added %d offline saddles from saddles.json with full asset payloads."):format(added))
end

-- =========================================================
--  data/saddlebags.json
-- =========================================================
local function CoalTack_LoadOfflineSaddleBags(list)
    -- list = existing saddle bag item list to append to
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/saddlebags.json")
    if not raw or raw == "" then
        print("[CoalTack] saddlebags.json optional/empty; skipping offline saddle bags.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[CoalTack] ERROR decoding saddlebags.json:", decoded)
        return
    end

    -- Turn raw item name into something readable in the menu
    local function prettyLabel(rawName)
        -- Try to strip common prefixes
        rawName = rawName
            :gsub("^horse_equipment_saddlebags_", "")

        local parts = {}
        for part in rawName:gmatch("[^_]+") do
            parts[#parts+1] = part
        end

        local style   = parts[1] or "??"
        local variant = parts[#parts] or ""

        return string.format("Saddlebags %s-%s", style, variant)
    end

    local added = 0
    for i, rec in ipairs(decoded) do
        local name = rec.name
        if type(name) == "string" and name ~= "" then
            local hash = GetHashKey(name)

            table.insert(list, {
                id           = string.format("saddlebags_offline_%03d", i),
                label        = prettyLabel(name),
                price        = 60,     -- tweak as you like
                desc         = "Imported saddle bags from the offline item database.",
                shopItemHash = hash,   -- treated like normal tack by the client
                rawName      = name,
                source       = "offline",
            })

            added = added + 1
        end
    end

    print(("[CoalTack] Added %d offline saddle bags from saddlebags.json."):format(added))
end
---------------------------------------------------
-- =========================================================
local function LoadOfflineBedrolls(intoList)
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/bedrolls.json")
    if not raw then
        print("[CoalTack] bedrolls.json optional/empty; skipping offline bedrolls.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[CoalTack] ERROR: failed to decode bedrolls.json:", decoded)
        return
    end

    local count = 0

    for i, rec in ipairs(decoded) do
        local name = rec.name
        if type(name) == "string" and name ~= "" then
            -- show raw name in menu for now
            local label = name

            table.insert(intoList, {
                id           = string.format("bedroll_offline_%03d", i),
                label        = label,
                price        = 0,
                desc         = "Imported bedroll from the offline item database.",
                shopItemHash = name,      -- 👈 let ApplyTackItem handle this
                rawName      = name,
                source       = "offline",
            })

            count = count + 1
        end
    end

    print(("[CoalTack] Added %d offline bedrolls into tack menu from bedrolls.json.")
        :format(count))
end
------------------------------------------------------
-- =========================================================
-- =========================================================
--  data/holsters.json
-- =========================================================
-- =========================================================
--  data/holsters.json
-- =========================================================
local function CoalTack_LoadOfflineholsters(list)
    -- list = existing holsters item list to append to
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/holsters.json")
    if not raw or raw == "" then
        print("[CoalTack] holsters.json optional/empty; skipping offline holsters.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[CoalTack] ERROR decoding holsters.json:", decoded)
        return
    end

    local added = 0

    -- holsters.json is an array of { name = "..." } records
    for i, rec in ipairs(decoded) do
        local rawName = rec and rec.name
        if type(rawName) == "string" and rawName ~= "" then
            local itemHash = GetHashKey(rawName)

            table.insert(list, {
                id           = ("holsters_offline_%03d"):format(i),
                label        = rawName,                          -- raw for debugging
                desc         = ("Offline holsters: %s"):format(rawName),
                price        = 0,
                shopItemHash = itemHash,
                rawName      = rawName,
                fromOffline  = true,
            })

            added = added + 1
        end
    end

    print(("[CoalTack] Added %d offline holsters from holsters.json."):format(added))
end
---------------------------------------------------
----------------------------
-- Offline horn asset data
----------------------------
local HornAssetsByName = {}

local function LoadHornsAssets()
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/horns.json")
    if not raw or raw == "" then
        print("[coal_stables] horns.json optional/empty; horn tints skipped.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[coal_stables] ERROR decoding horns.json:", decoded)
        return
    end

    for _, rec in ipairs(decoded) do
        if rec.name and rec.assets then
            HornAssetsByName[rec.name] = rec.assets
        end
    end

    print(("[coal_stables] Loaded %d horn asset records."):format(#decoded))
end

LoadHornsAssets()

---------------------------------------------------
-- Simple helper to build blanket tint items using the shared palettes
---------------------------------------------------
local function GenerateBlanketTintItems(startIndex, endIndex, opts)
    local items = {}

    local idPrefix     = opts.idPrefix    or "BlanketTint"
    local labelPrefix  = opts.labelPrefix or "Blanket Tint"
    local descPrefix   = opts.descPrefix  or "Blanket tint index"
    local labelSuffix  = opts.labelSuffix or ""

    local palette      = opts.palette
    local paletteOrder = opts.paletteOrder or 0

    local drawable     = opts.drawable
    local albedo       = opts.albedo
    local normal       = opts.normal
    local material     = opts.material

    -- which tint channel this list controls: 0, 1, or 2
    local channel      = opts.channel or 0

    local orderOffset = paletteOrder * 1000

    for i = startIndex, endIndex do
        local tint0, tint1, tint2 = nil, nil, nil
        if channel == 0 then
            tint0 = i
        elseif channel == 1 then
            tint1 = i
        elseif channel == 2 then
            tint2 = i
        end

        table.insert(items, {
            id        = idPrefix .. "_" .. i,
            label     = string.format("%s %d%s", labelPrefix, i, labelSuffix),
            price     = 1,
            desc      = string.format("%s %d%s", descPrefix, i, labelSuffix),

            sortIndex = orderOffset + i,

            palette   = palette,
            tint0     = tint0,
            tint1     = tint1,
            tint2     = tint2,

            drawable  = drawable,
            albedo    = albedo,
            normal    = normal,
            material  = material,
        })
    end

    return items
end
---------------------------------------------------
-- =========================================================
--  data/stirrups.json
-- =========================================================
local function CoalTack_LoadOfflineStirrups(list)
    -- list = existing stirrup item list to append to
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/stirrups.json")
    if not raw or raw == "" then
        print("[CoalTack] stirrups.json optional/empty; skipping offline stirrups.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[CoalTack] ERROR decoding stirrups.json:", decoded)
        return
    end

    local added = 0

    for i, rec in ipairs(decoded) do
        local rawName = rec and rec.name
        if type(rawName) == "string" and rawName ~= "" then
            local hash = GetHashKey(rawName)

            table.insert(list, {
                id           = ("stirrups_offline_%03d"):format(i),
                label        = rawName,  -- raw for now, like saddles/holsters
                price        = 40,       -- tweak price as you like
                desc         = ("Offline stirrups: %s"):format(rawName),
                shopItemHash = hash,
                rawName      = rawName,
                fromOffline  = true,
            })

            added = added + 1
        end
    end

    print(("[CoalTack] Added %d offline stirrups from stirrups.json."):format(added))
end
---------------------------------------------------
-- Items per category (using real shop item hashes)
T.Items = { 
    ----------------------------------------------------------------
    -- BRIDLES (combined category, all 4 styles in one row)
    ----------------------------------------------------------------
    bridles = (function()
        local list = {}

        -- No bridle option
        table.insert(list, {
            id           = "no_bridle_combined",
            label        = "No Bridle",
            price        = 0,
            desc         = "Ride without a bridle upgrade.",
            shopItemHash = false,
        })

        local function addBridleStyle(styleIndex, styleLabel, drawable)
            -- styleIndex keeps styles grouped in order
            for i = 2, 254 do
                table.insert(list, {
                    id      = string.format("bridles_style_%03d_p8_%d", styleIndex, i),
                    label   = string.format("%s %d (P8)", styleLabel, i),
                    price   = 1,
                    desc    = string.format("%s tint index %d (P8).", styleLabel, i),

                    sortIndex = styleIndex * 1000 + i,

                    palette = T_PALETTES.P8,
                    tint0   = i,
                    tint1   = i,
                    tint2   = i,

                    drawable = drawable,
                    -- all styles share this texture set in your current setup
                    albedo   = "p_c_horse_01_uppr_002_c0_999_ab",
                    normal   = "p_c_horse_01_uppr_002_c0_000_nm",
                    material = "p_c_horse_01_uppr_002_c0_000_m",
                })
            end
        end

        addBridleStyle(1, "Bridle Style 001", "p_c_horse_01_uppr_001")
        addBridleStyle(2, "Bridle Style 002", "p_c_horse_01_uppr_002")
        addBridleStyle(3, "Bridle Style 003", "p_c_horse_01_uppr_003")
        addBridleStyle(4, "Bridle Style 004", "p_c_horse_01_uppr_004")

        return list
    end)(),

    ----------------------------------------------------------------
    bridle_style_001 = (function()
        local list = {}

        -- No harness option
        table.insert(list, {
            id           = "no_bridle",
            label        = "No Bridle",
            price        = 0,
            desc         = "Nothing.",
            shopItemHash = false,
        })

        -- P8 palette, tint indices 2–254
        for i = 2, 254 do
            table.insert(list, {
                id      = string.format("bridle_style_001_p8_%d", i),
                label   = string.format("Horse Bridle 001 %d (P8)", i),
                price   = 1,
                desc    = string.format("Horse bridle 001 tint index %d (P8).", i),

                -- ensure stable ordering in the menu
                sortIndex = i,

                palette = T_PALETTES.P8,
                tint0   = i,
                tint1   = i,
                tint2   = i,

            drawable   = "p_c_horse_01_uppr_001",
            albedo     = "p_c_horse_01_uppr_002_c0_999_ab",
            normal     = "p_c_horse_01_uppr_002_c0_000_nm",
            material   = "p_c_horse_01_uppr_002_c0_000_m",
            })
        end

        return list
    end)(),
    -------------------------------------------------------------------------------------
    ----------------------------------------------------------------
    bridle_style_002 = (function()
        local list = {}

        -- No harness option
        table.insert(list, {
            id           = "no_bridle",
            label        = "No Bridle",
            price        = 0,
            desc         = "Nothing.",
            shopItemHash = false,
        })

        -- P8 palette, tint indices 2–254
        for i = 2, 254 do
            table.insert(list, {
                id      = string.format("bridle_style_002_p8_%d", i),
                label   = string.format("Horse Bridle 002 %d (P8)", i),
                price   = 1,
                desc    = string.format("Horse bridle 002 tint index %d (P8).", i),

                -- ensure stable ordering in the menu
                sortIndex = i,

                palette = T_PALETTES.P8,
                tint0   = i,
                tint1   = i,
                tint2   = i,

            drawable   = "p_c_horse_01_uppr_002",
            albedo     = "p_c_horse_01_uppr_002_c0_999_ab",
            normal     = "p_c_horse_01_uppr_002_c0_000_nm",
            material   = "p_c_horse_01_uppr_002_c0_000_m",
            })
        end

        return list
    end)(),
    -------------------------------------------------------------------------------------
    ----------------------------------------------------------------
    bridle_style_003 = (function()
        local list = {}

        -- No harness option
        table.insert(list, {
            id           = "no_bridle",
            label        = "No Bridle",
            price        = 0,
            desc         = "Nothing.",
            shopItemHash = false,
        })

        -- P8 palette, tint indices 2–254
        for i = 2, 254 do
            table.insert(list, {
                id      = string.format("bridle_style_003_p8_%d", i),
                label   = string.format("Horse Bridle 003 %d (P8)", i),
                price   = 1,
                desc    = string.format("Horse bridle 003 tint index %d (P8).", i),

                -- ensure stable ordering in the menu
                sortIndex = i,

                palette = T_PALETTES.P8,
                tint0   = i,
                tint1   = i,
                tint2   = i,

            drawable   = "p_c_horse_01_uppr_003",
            albedo     = "p_c_horse_01_uppr_002_c0_999_ab",
            normal     = "p_c_horse_01_uppr_002_c0_000_nm",
            material   = "p_c_horse_01_uppr_002_c0_000_m",
            })
        end

        return list
    end)(),
    -------------------------------------------------------------------------------------
    ----------------------------------------------------------------
    bridle_style_004 = (function()
        local list = {}

        -- No harness option
        table.insert(list, {
            id           = "no_bridle",
            label        = "No Bridle",
            price        = 0,
            desc         = "Nothing.",
            shopItemHash = false,
        })

        -- P8 palette, tint indices 2–254
        for i = 2, 254 do
            table.insert(list, {
                id      = string.format("bridle_style_004_p8_%d", i),
                label   = string.format("Horse Bridle 004 %d (P8)", i),
                price   = 1,
                desc    = string.format("Horse bridle 004 tint index %d (P8).", i),

                -- ensure stable ordering in the menu
                sortIndex = i,

                palette = T_PALETTES.P8,
                tint0   = i,
                tint1   = i,
                tint2   = i,

            drawable   = "p_c_horse_01_uppr_004",
            albedo     = "p_c_horse_01_uppr_002_c0_999_ab",
            normal     = "p_c_horse_01_uppr_002_c0_000_nm",
            material   = "p_c_horse_01_uppr_002_c0_000_m",
            })
        end

        return list
    end)(),
 
    ----------------------------------------------------------------
    -- HARNESS (Horse Harness, P8 tints 2–254)
    ----------------------------------------------------------------
    harness = (function()
        local list = {}

        -- No harness option
        table.insert(list, {
            id           = "none_harness",
            label        = "No Horse Harness",
            price        = 0,
            desc         = "Ride without a horse harness.",
            shopItemHash = false,
        })

        -- P8 palette, tint indices 2–254
        for i = 2, 254 do
            table.insert(list, {
                id      = string.format("harness_p8_%d", i),
                label   = string.format("Horse Harness %d (P8)", i),
                price   = 1,
                desc    = string.format("Horse harness tint index %d (P8).", i),

                -- ensure stable ordering in the menu
                sortIndex = i,

                palette = T_PALETTES.P8,
                tint0   = i,
                tint1   = i,
                tint2   = i,

                drawable = "mp_horselantern_harness_001",
                albedo   = "mp_horselantern_harness_001_ab",
                normal   = "mp_horselantern_harness_001_nm",
                material = "mp_horselantern_harness_001_m",
            })
        end

        return list
    end)(),

    ----------------------------------------------------------------
    ----------------------------------------------------------------
    -- BLANKETS – role blankets (fixed) + tintable overlay
    ----------------------------------------------------------------
    blankets = (function()
        local list = {}

        -- 0) No blanket
        table.insert(list, {
            id           = "none_blanket",
            label        = "No Blanket",
            price        = 0,
            desc         = "Remove any saddle blanket upgrade.",
            shopItemHash = false,
        })

        -- Offline blankets from blankets.json
        LoadOfflineBlankets(list)
        return list
    end)(),

     ----------------------------------------------------------------
    -- BLANKET TINT 0 – controls tint0
    ----------------------------------------------------------------
    blanket_tint0 = (function()
        local list  = {}

        table.insert(list, {
            id           = "none_blanket_tint0",
            label        = "No Tint 0",
            price        = 0,
            desc         = "Use the blanket's original primary color.",
            shopItemHash = false,
        })

        local function addPaletteVariant(pKey, paletteOrder)
            local suffix = string.format(" (%s)", pKey)
            local items = GenerateBlanketTintItems(2, 254, {
                idPrefix     = "BlanketTint0_" .. pKey,
                labelPrefix  = "Tint 0",
                descPrefix   = "Tint 0 index",
                labelSuffix  = suffix,

                palette      = T_PALETTES[pKey],
                paletteOrder = paletteOrder,
                channel      = 0,   -- 👈 tint0

                drawable     = "p_c_horse_01_acc2_001",
                albedo       = "p_c_horse_01_acc2_001_c1_999_ab",
                normal       = "p_c_horse_01_acc2_001_c1_000_nm",
                material     = "p_c_horse_01_acc2_001_c1_000_m",
            })

            for _, it in ipairs(items) do
                list[#list+1] = it
            end
        end

        addPaletteVariant("P1", 1)
        addPaletteVariant("P2", 2)
        addPaletteVariant("P3", 3)
        addPaletteVariant("P4", 4)
        addPaletteVariant("P5", 5)
        addPaletteVariant("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- BLANKET TINT 1 – controls tint1
    ----------------------------------------------------------------
    blanket_tint1 = (function()
        local list  = {}

        table.insert(list, {
            id           = "none_blanket_tint1",
            label        = "No Tint 1",
            price        = 0,
            desc         = "Use the blanket's original secondary color.",
            shopItemHash = false,
        })

        local function addPaletteVariant(pKey, paletteOrder)
            local suffix = string.format(" (%s)", pKey)
            local items = GenerateBlanketTintItems(2, 254, {
                idPrefix     = "BlanketTint1_" .. pKey,
                labelPrefix  = "Tint 1",
                descPrefix   = "Tint 1 index",
                labelSuffix  = suffix,

                palette      = T_PALETTES[pKey],
                paletteOrder = paletteOrder,
                channel      = 1,   -- 👈 tint1

                drawable     = "p_c_horse_01_acc2_001",
                albedo       = "p_c_horse_01_acc2_001_c1_999_ab",
                normal       = "p_c_horse_01_acc2_001_c1_000_nm",
                material     = "p_c_horse_01_acc2_001_c1_000_m",
            })

            for _, it in ipairs(items) do
                list[#list+1] = it
            end
        end

        addPaletteVariant("P1", 1)
        addPaletteVariant("P2", 2)
        addPaletteVariant("P3", 3)
        addPaletteVariant("P4", 4)
        addPaletteVariant("P5", 5)
        addPaletteVariant("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- BLANKET TINT 2 – controls tint2
    ----------------------------------------------------------------
    blanket_tint2 = (function()
        local list  = {}

        table.insert(list, {
            id           = "none_blanket_tint2",
            label        = "No Tint 2",
            price        = 0,
            desc         = "Use the blanket's original accent color.",
            shopItemHash = false,
        })

        local function addPaletteVariant(pKey, paletteOrder)
            local suffix = string.format(" (%s)", pKey)
            local items = GenerateBlanketTintItems(2, 254, {
                idPrefix     = "BlanketTint2_" .. pKey,
                labelPrefix  = "Tint 2",
                descPrefix   = "Tint 2 index",
                labelSuffix  = suffix,

                palette      = T_PALETTES[pKey],
                paletteOrder = paletteOrder,
                channel      = 2,   -- 👈 tint2

                drawable     = "p_c_horse_01_acc2_001",
                albedo       = "p_c_horse_01_acc2_001_c1_999_ab",
                normal       = "p_c_horse_01_acc2_001_c1_000_nm",
                material     = "p_c_horse_01_acc2_001_c1_000_m",
            })

            for _, it in ipairs(items) do
                list[#list+1] = it
            end
        end

        addPaletteVariant("P1", 1)
        addPaletteVariant("P2", 2)
        addPaletteVariant("P3", 3)
        addPaletteVariant("P4", 4)
        addPaletteVariant("P5", 5)
        addPaletteVariant("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- SADDLES – offline saddles from data/saddles.json
    ----------------------------------------------------------------
    saddles = (function()
        local list = {}

        -- 0) Default saddle option
        table.insert(list, {
            id           = "none_saddle",
            label        = "Default Saddle",
            price        = 0,
            desc         = "Use the horse's default saddle.",
            shopItemHash = false,
        })

        ------------------------------------------------------------
        -- Offline saddles from saddles.json
        ------------------------------------------------------------
        CoalTack_LoadOfflineSaddles(list)

        return list
    end)(),
------------------
    ----------------------------------------------------------------
    -- SADDLE TINT 0 – controls tint0 for all saddle assets
    ----------------------------------------------------------------
    saddle_tint0 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_saddle_tint0",
            label        = "No Saddle Tint 0",
            price        = 0,
            desc         = "Use the saddle's original primary tint.",
            shopItemHash = false,
        })

        local function addPaletteVariant(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("SaddleTint0_%s_%d", pKey, i),
                    label     = string.format("Saddle Tint 0 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Saddle tint0 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    -- Just the tint payload – the client will pick the saddle drawables
                    palette   = paletteName,
                    tint0     = i,
                    -- tint1/tint2 left nil so they don't override those channels
                })
            end
        end

        -- Choose the palettes you like for saddles
        addPaletteVariant("P2", 2)  -- metaped_tint_horse_leather
        addPaletteVariant("P5", 5)  -- metaped_tint_combined_leather
        addPaletteVariant("P9", 9)  -- metaped_tint_leather (if present)

        return list
    end)(),

    ----------------------------------------------------------------
    -- SADDLE TINT 1 – controls tint1 for all saddle assets
    ----------------------------------------------------------------
    saddle_tint1 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_saddle_tint1",
            label        = "No Saddle Tint 1",
            price        = 0,
            desc         = "Use the saddle's original secondary tint.",
            shopItemHash = false,
        })

        local function addPaletteVariant(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("SaddleTint1_%s_%d", pKey, i),
                    label     = string.format("Saddle Tint 1 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Saddle tint1 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint1     = i,
                })
            end
        end

        addPaletteVariant("P2", 2)
        addPaletteVariant("P5", 5)
        addPaletteVariant("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- SADDLE TINT 2 – controls tint2 for all saddle assets
    ----------------------------------------------------------------
    saddle_tint2 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_saddle_tint2",
            label        = "No Saddle Tint 2",
            price        = 0,
            desc         = "Use the saddle's original accent tint.",
            shopItemHash = false,
        })

        local function addPaletteVariant(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("SaddleTint2_%s_%d", pKey, i),
                    label     = string.format("Saddle Tint 2 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Saddle tint2 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint2     = i,
                })
            end
        end

        addPaletteVariant("P2", 2)
        addPaletteVariant("P5", 5)
        addPaletteVariant("P9", 9)

        return list
    end)(),

------------------
    ----------------------------------------------------------------
    -- SADDLEBAGS – offline saddle bags from data/saddlebags.json
    ----------------------------------------------------------------
    saddlebags = (function()
        local list = {}

        -- 0) No saddle bags option
        table.insert(list, {
            id           = "none_saddlebags",
            label        = "No Saddle Bags",
            price        = 0,
            desc         = "Ride without saddle bags.",
            shopItemHash = false,
        })

        -- Offline saddle bags from JSON
        CoalTack_LoadOfflineSaddleBags(list)

        return list
    end)(),

    ----------------------------------------------------------------
    ----------------------------------------------------------------
    -- SADDLEBAG TINT 0 – primary channel
    ----------------------------------------------------------------
    saddlebags_tint0 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_saddlebags_tint0",
            label        = "No Saddlebag Tint 0",
            price        = 0,
            desc         = "Use the saddlebag's original primary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("SaddlebagTint0_%s_%d", pKey, i),
                    label     = string.format("Saddlebag Tint 0 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Saddlebag tint0 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint0     = i,   -- only tint0
                })
            end
        end

        addPaletteFamily("P2", 2)  -- leather
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- SADDLEBAG TINT 1 – secondary channel
    ----------------------------------------------------------------
    saddlebags_tint1 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_saddlebags_tint1",
            label        = "No Saddlebag Tint 1",
            price        = 0,
            desc         = "Use the saddlebag's original secondary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("SaddlebagTint1_%s_%d", pKey, i),
                    label     = string.format("Saddlebag Tint 1 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Saddlebag tint1 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint1     = i,   -- only tint1
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- SADDLEBAG TINT 2 – accent channel
    ----------------------------------------------------------------
    saddlebags_tint2 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_saddlebags_tint2",
            label        = "No Saddlebag Tint 2",
            price        = 0,
            desc         = "Use the saddlebag's original accent tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("SaddlebagTint2_%s_%d", pKey, i),
                    label     = string.format("Saddlebag Tint 2 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Saddlebag tint2 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint2     = i,   -- only tint2
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

-------------------------------------------------
  ----------------------------------------------------------------
    -- STIRRUPS – offline stirrups from data/stirrups.json
    ----------------------------------------------------------------
    stirrups = (function()
        local list = {}

        -- 0) Default stirrups
        table.insert(list, {
            id           = "none_stirrups",
            label        = "Default Stirrups",
            price        = 0,
            desc         = "Use the horse's default stirrups.",
            shopItemHash = false,
        })

        -- Offline stirrups from JSON
        CoalTack_LoadOfflineStirrups(list)

        return list
    end)(),

    ----------------------------------------------------------------
    -- STIRRUPS TINT 0 – controls tint0 for stirrup assets
    ----------------------------------------------------------------
    stirrups_tint0 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_stirrups_tint0",
            label        = "No Stirrup Tint 0",
            price        = 0,
            desc         = "Use the stirrup's original primary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("StirrupsTint0_%s_%d", pKey, i),
                    label     = string.format("Stirrup Tint 0 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Stirrup tint0 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint0     = i,   -- only touch tint0
                })
            end
        end

        addPaletteFamily("P2", 2)  -- leather-ish
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- STIRRUPS TINT 1 – controls tint1 for stirrup assets
    ----------------------------------------------------------------
    stirrups_tint1 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_stirrups_tint1",
            label        = "No Stirrup Tint 1",
            price        = 0,
            desc         = "Use the stirrup's original secondary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("StirrupsTint1_%s_%d", pKey, i),
                    label     = string.format("Stirrup Tint 1 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Stirrup tint1 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint1     = i,
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- STIRRUPS TINT 2 – controls tint2 for stirrup assets
    ----------------------------------------------------------------
    stirrups_tint2 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_stirrups_tint2",
            label        = "No Stirrup Tint 2",
            price        = 0,
            desc         = "Use the stirrup's original accent tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("StirrupsTint2_%s_%d", pKey, i),
                    label     = string.format("Stirrup Tint 2 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Stirrup tint2 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint2     = i,
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),
-------------------------------------------------
    ----------------------------------------------------------------
    -- BEDROLLS
    ----------------------------------------------------------------
    bedrolls = (function()

        local list = {
            {
                id           = "none_bedroll",
                label        = "No Bedroll Upgrade",
                price        = 0,
                desc         = "No bedroll attached to the saddle.",
                shopItemHash = false,
            },
        }

        -- pull in everything from data/bedrolls.json
        LoadOfflineBedrolls(list)

        return list
    end)(),

        ----------------------------------------------------------------
    -- BEDROLL TINT 0 / 1 / 2 – tint overlays for bedroll assets
    ----------------------------------------------------------------
    bedroll_tint0 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_bedroll_tint0",
            label        = "No Bedroll Tint 0",
            price        = 0,
            desc         = "Use the bedroll's original primary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("BedrollTint0_%s_%d", pKey, i),
                    label     = string.format("Bedroll Tint 0 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Bedroll tint0 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint0     = i,
                })
            end
        end

        -- Use the same leather-ish palettes as saddles / bags
        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    bedroll_tint1 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_bedroll_tint1",
            label        = "No Bedroll Tint 1",
            price        = 0,
            desc         = "Use the bedroll's original secondary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("BedrollTint1_%s_%d", pKey, i),
                    label     = string.format("Bedroll Tint 1 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Bedroll tint1 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint1     = i,
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    bedroll_tint2 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_bedroll_tint2",
            label        = "No Bedroll Tint 2",
            price        = 0,
            desc         = "Use the bedroll's original accent tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("BedrollTint2_%s_%d", pKey, i),
                    label     = string.format("Bedroll Tint 2 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Bedroll tint2 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint2     = i,
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),


    ----------------------------------------------------------------
    -- holsters – placeholder
    ----------------------------------------------------------------
        holsters = (function()
            local list = {
                {
                    id = "none_holsters",
                    label = "None",
                    desc  = "No extra holsters.",
                    price = 0,
                    shopItemHash = false,
                },
            }

            -- Append items from data/holsters.json
            CoalTack_LoadOfflineholsters(list)
            return list
        end)(),
    ----------------------------------------------------------------
    -- holsters TINT 0 – primary channel
    ----------------------------------------------------------------
    holsters_tint0 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_holsters_tint0",
            label        = "No holsters Tint 0",
            price        = 0,
            desc         = "Use the holsters's original primary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("holstersTint0_%s_%d", pKey, i),
                    label     = string.format("holsters Tint 0 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("holsters tint0 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint0     = i,   -- only channel 0
                })
            end
        end

        -- Leather-y palettes: same family as saddles/bags
        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- holsters TINT 1 – secondary channel
    ----------------------------------------------------------------
    holsters_tint1 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_holsters_tint1",
            label        = "No holsters Tint 1",
            price        = 0,
            desc         = "Use the holsters's original secondary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("holstersTint1_%s_%d", pKey, i),
                    label     = string.format("holsters Tint 1 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("holsters tint1 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint1     = i,   -- only channel 1
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- holsters TINT 2 – accent channel
    ----------------------------------------------------------------
    holsters_tint2 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_holsters_tint2",
            label        = "No holsters Tint 2",
            price        = 0,
            desc         = "Use the holsters's original accent tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("holstersTint2_%s_%d", pKey, i),
                    label     = string.format("holsters Tint 2 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("holsters tint2 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint2     = i,   -- only channel 2
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

---------------------------------------------
horns = (function()
    local list = {}

    -- No horn option
    table.insert(list, {
        id           = "none_horn",
        label        = "No Horn",
        price        = 0,
        desc         = "Remove the saddle horn upgrade.",
        shopItemHash = false,
    })

    -- Offline horns from horns.json
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/horns.json")
    if raw then
        local ok, decoded = pcall(json.decode, raw)
        if ok and type(decoded) == "table" then
            local added = 0
            for i, rec in ipairs(decoded) do
                local rawName = rec.name
                if rawName then
                    local itemHash = GetHashKey(rawName)
                    table.insert(list, {
                        id           = ("horns_offline_%03d"):format(i),
                        label        = rawName,
                        price        = 40,
                        desc         = ("Offline horn: %s"):format(rawName),
                        shopItemHash = itemHash,
                        rawName      = rawName,
                        fromOffline  = true,
                    })
                    added = added + 1
                end
            end
            print(("[CoalTack] Added %d offline horns."):format(added))
        end
    end

    return list
end)(),
---------------------------------------------
    ----------------------------------------------------------------
    -- HORN TINT 0 – primary channel
    ----------------------------------------------------------------
    horns_tint0 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_horns_tint0",
            label        = "No Horn Tint 0",
            price        = 0,
            desc         = "Use the horn's original primary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("HornTint0_%s_%d", pKey, i),
                    label     = string.format("Horn Tint 0 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Horn tint0 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint0     = i,   -- only channel 0
                })
            end
        end

        -- Leather-ish palettes, same family as saddles/bags
        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- HORN TINT 1 – secondary channel
    ----------------------------------------------------------------
    horns_tint1 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_horns_tint1",
            label        = "No Horn Tint 1",
            price        = 0,
            desc         = "Use the horn's original secondary tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("HornTint1_%s_%d", pKey, i),
                    label     = string.format("Horn Tint 1 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Horn tint1 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint1     = i,   -- only channel 1
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

    ----------------------------------------------------------------
    -- HORN TINT 2 – accent / tertiary
    ----------------------------------------------------------------
    horns_tint2 = (function()
        local list = {}

        table.insert(list, {
            id           = "none_horns_tint2",
            label        = "No Horn Tint 2",
            price        = 0,
            desc         = "Use the horn's original accent tint.",
            shopItemHash = false,
        })

        local function addPaletteFamily(pKey, paletteOrder)
            local paletteName = T_PALETTES[pKey]
            if not paletteName then return end

            for i = 2, 254 do
                table.insert(list, {
                    id        = string.format("HornTint2_%s_%d", pKey, i),
                    label     = string.format("Horn Tint 2 - %d (%s)", i, pKey),
                    price     = 1,
                    desc      = string.format("Horn tint2 index %d (%s)", i, pKey),

                    sortIndex = paletteOrder * 1000 + i,

                    palette   = paletteName,
                    tint2     = i,   -- only channel 2
                })
            end
        end

        addPaletteFamily("P2", 2)
        addPaletteFamily("P5", 5)
        addPaletteFamily("P9", 9)

        return list
    end)(),

---------------------------------------------
}   -- << this closes T.Items

---------------------------------------------------------------

-- Helpers: ordered lists for menus
function T.GetCategories()
    return T.Categories
end

function T.GetItemsForCategory(catId)
    local list = T.Items[catId] or {}

    table.sort(list, function(a, b)
        -- First: price
        if a.price ~= b.price then
            return a.price < b.price
        end

        -- Second: explicit sortIndex if both have it
        if a.sortIndex and b.sortIndex then
            return a.sortIndex < b.sortIndex
        end

        -- Last fallback: label
        return a.label < b.label
    end)

    return list
end