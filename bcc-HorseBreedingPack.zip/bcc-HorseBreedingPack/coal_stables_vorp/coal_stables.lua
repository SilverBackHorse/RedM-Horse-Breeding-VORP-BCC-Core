--=====================================================================
--  COAL COUNTY STABLES - CONFIG
--=====================================================================

CoalStables = CoalStables or {}
CoalStables.Config = CoalStables.Config or {}

local Config = CoalStables.Config

-- Stable locations (add as many as you like)
Config.Stables = {
    {
        id = "valentine",
        name = "Valentine Custom Coats",
        coords = vector3(-374.33, 786.83, 116.17),
        heading = 90.0,
        showBlip = true,
        blipSprite = 1210165179,
        blipScale = 0.6,
    },
    {
        id = "strawberry",
        name = "Strawberry Custom Coats",
        coords = vector3(-1813.0, -569.0, 156.0),
        heading = 50.0,
        showBlip = true,
        blipSprite = 1210165179,
        blipScale = 0.6,
    },
    {
        id = "blackwater",
        name = "Blackwater Custom Coats",
        coords = vector3(-875.0, -1366.0, 43.5),
        heading = 180.0,
        showBlip = true,
        blipSprite = 1210165179,
        blipScale = 0.6,
    }
}

-- Horse tiers – 
Config.Tiers = {

    Morgan_Tier = {
        label = "Morgan",
        speed = 0.85,
        accel = 0.85,
        handling = 0.9,
        bravery = 0.8,
        health = 0.9,
        stamina = 0.9,
        priceMult = 0.5,
    },

    Tennessee_Walker_Tier = {
        label = "Tennessee Walker",
        speed = 0.95,
        accel = 0.95,
        handling = 1.0,
        bravery = 1.0,
        health = 1.1,
        stamina = 1.1,
        priceMult = 0.8,
    },

    American_Standardbred_Tier = {
        label = "American Standardbred",
        speed = 1.0,
        accel = 1.0,
        handling = 1.1,
        bravery = 1.2,
        health = 1.15,
        stamina = 1.2,
        priceMult = 1.0,
    },

    Thoroughbred_Tier = {
        label = "Thoroughbred",
        speed = 1.15,
        accel = 1.2,
        handling = 1.0,
        bravery = 1.0,
        health = 1.0,
        stamina = 1.25,
        priceMult = 1.35,
    },

    Mustang_Tier = {
        label = "Mustang",
        speed = 1.1,
        accel = 1.05,
        handling = 0.95,
        bravery = 1.3,
        health = 1.25,
        stamina = 1.15,
        priceMult = 1.25,
    },

    Andalusian_Tier = {
        label = "Andalusian",
        speed = 1.2,
        accel = 1.15,
        handling = 1.05,
        bravery = 1.4,
        health = 1.3,
        stamina = 1.3,
        priceMult = 1.6,
    },

    Arabian_Tier = {
        label = "Arabian",
        speed = 1.2,
        accel = 1.2,
        handling = 1.1,
        bravery = 1.0,
        health = 0.95,
        stamina = 1.35,
        priceMult = 1.5,
    },

    Ardennes_Tier = {
        label = "Ardennes",
        speed = 0.9,
        accel = 0.85,
        handling = 0.9,
        bravery = 1.3,
        health = 1.4,
        stamina = 1.1,
        priceMult = 0.9,
    },

    Appaloosa_Tier = {
        label = "Appaloosa",
        speed = 1.0,
        accel = 0.95,
        handling = 1.0,
        bravery = 1.1,
        health = 1.1,
        stamina = 1.15,
        priceMult = 1.0,
    },

    American_Paint_Tier = {
        label = "American Paint",
        speed = 0.95,
        accel = 0.95,
        handling = 1.0,
        bravery = 1.0,
        health = 1.05,
        stamina = 1.05,
        priceMult = 0.85,
    },

    Belgian_Tier = {
        label = "Belgian",
        speed = 0.9,
        accel = 0.85,
        handling = 0.9,
        bravery = 1.2,
        health = 1.35,
        stamina = 1.1,
        priceMult = 0.9,
    },

    Breton_Tier = {
        label = "Breton",
        speed = 1.0,
        accel = 0.95,
        handling = 0.95,
        bravery = 1.2,
        health = 1.25,
        stamina = 1.15,
        priceMult = 1.1,
    },

  --  Buell_Tier = {
   --     label = "Buell",
   --     speed = 1.05,
   --     accel = 1.0,
  --      handling = 1.1,
  --      bravery = 1.3,
   --     health = 1.3,
  --      stamina = 1.2,
 --       priceMult = 1.4,
 --   },

    Criollo_Tier = {
        label = "Criollo",
        speed = 1.05,
        accel = 1.0,
        handling = 1.0,
        bravery = 1.2,
        health = 1.2,
        stamina = 1.25,
        priceMult = 1.2,
    },

    Dutch_Warmblood_Tier = {
        label = "Dutch Warmblood",
        speed = 1.05,
        accel = 1.05,
        handling = 1.05,
        bravery = 1.1,
        health = 1.15,
        stamina = 1.15,
        priceMult = 1.15,
    },

  --  EagleFlies_Tier = {
 --       label = "Eagle Flies' Horse",
 --       speed = 1.15,
  --      accel = 1.1,
  --      handling = 1.05,
  --      bravery = 1.3,
  --      health = 1.25,
  --      stamina = 1.3,
   --     priceMult = 1.5,
  --  },

  --  Gang_Tier = {
   --     label = "Van der Linde Gang",
   --     speed = 1.0,
   --     accel = 1.0,
   --     handling = 1.0,
    --    bravery = 1.1,
    --    health = 1.15,
    --    stamina = 1.15,
    --    priceMult = 1.0,
   -- },

    GypsyCob_Tier = {
        label = "Gypsy Cob",
        speed = 0.95,
        accel = 0.9,
        handling = 0.95,
        bravery = 1.2,
        health = 1.25,
        stamina = 1.0,
        priceMult = 0.9,
    },

    Hungarian_Halfbred_Tier = {
        label = "Hungarian Halfbred",
        speed = 1.05,
        accel = 1.0,
        handling = 1.0,
        bravery = 1.2,
        health = 1.25,
        stamina = 1.15,
        priceMult = 1.2,
    },

   -- John_Tier = {
   --     label = "John's Horse",
   --     speed = 1.05,
   --     accel = 1.0,
   --     handling = 1.05,
   --     bravery = 1.2,
  --      health = 1.2,
  --      stamina = 1.2,
  --      priceMult = 1.25,
 --   },

    Kentucky_Saddler_Tier = {
        label = "Kentucky Saddler",
        speed = 0.95,
        accel = 0.95,
        handling = 1.0,
        bravery = 1.0,
        health = 1.0,
        stamina = 1.0,
        priceMult = 0.8,
    },

    Kladruber_Tier = {
        label = "Kladruber",
        speed = 1.0,
        accel = 0.95,
        handling = 1.05,
        bravery = 1.2,
        health = 1.3,
        stamina = 1.1,
        priceMult = 1.2,
    },

    Missouri_Foxtrotter_Tier = {
        label = "Missouri Fox Trotter",
        speed = 1.1,
        accel = 1.05,
        handling = 1.1,
        bravery = 1.15,
        health = 1.15,
        stamina = 1.25,
        priceMult = 1.3,
    },

 --   Mangy_Tier = {
 --       label = "Mangy",
  --      speed = 0.8,
 --       accel = 0.8,
  --      handling = 0.8,
  --      bravery = 0.7,
  --      health = 0.8,
  --      stamina = 0.8,
  --      priceMult = 0.2,
  --  },

 --   Murfreebrood_Tier = {
  --      label = "Murfree Brood",
   --     speed = 0.85,
   --     accel = 0.8,
     --   handling = 0.8,
   --     bravery = 0.8,
   --     health = 0.9,
    --    stamina = 0.85,
   --     priceMult = 0.3,
  --  },

    Nokota_Tier = {
        label = "Nokota",
        speed = 1.05,
        accel = 1.05,
        handling = 0.95,
        bravery = 1.25,
        health = 1.2,
        stamina = 1.2,
        priceMult = 1.2,
    },

    Norfolk_Roadster_Tier = {
        label = "Norfolk Roadster",
        speed = 1.1,
        accel = 1.1,
        handling = 1.05,
        bravery = 1.0,
        health = 1.05,
        stamina = 1.25,
        priceMult = 1.3,
    },

    Shire_Tier = {
        label = "Shire",
        speed = 0.9,
        accel = 0.85,
        handling = 0.9,
        bravery = 1.3,
        health = 1.4,
        stamina = 1.0,
        priceMult = 0.9,
    },

    Suffolk_Punch_Tier = {
        label = "Suffolk Punch",
        speed = 0.9,
        accel = 0.85,
        handling = 0.9,
        bravery = 1.25,
        health = 1.35,
        stamina = 1.0,
        priceMult = 0.9,
    },

    Turkoman_Tier = {
        label = "Turkoman",
        speed = 1.15,
        accel = 1.1,
        handling = 1.0,
        bravery = 1.2,
        health = 1.2,
        stamina = 1.25,
        priceMult = 1.5,
    },

 --   Winter_Tier = {
 --       label = "Winter Horse",
  --      speed = 1.1,
  --      accel = 1.05,
   --     handling = 1.0,
   --     bravery = 1.1,
   --     health = 1.15,
   --     stamina = 1.2,
   --     priceMult = 1.3,
  --  },

   -- Mule_Tier = {
   --     label = "Mule",
  --      speed = 0.85,
   --     accel = 0.85,
   --     handling = 0.95,
   --     bravery = 1.1,
  --      health = 1.1,
  --      stamina = 1.0,
--        priceMult = 0.6,
 --   },
}

-- Base price before tier multipliers
Config.BasePrice = 40.0

-- Max global stats – “Coal County doesn’t do slow”
Config.MaxStats = {
    speed   = 2.25,
    accel   = 2.25,
    health  = 2.4,
    stamina = 2.4,
}
--up/down arrow keys to select horse
--left/right arrow keys to change model
-- Horses
Config.Horses = {
    {
        id = "Morgan",--20
        name = "Morgan",
        model = {
        "A_C_Horse_Morgan_Bay", 
        "A_C_Horse_Morgan_BayRoan", 
        "A_C_Horse_Morgan_Flaxenchestnut",
        "A_C_Horse_Morgan_Liverchestnut_PC",
        "A_C_Horse_Morgan_Palomino",
        },
        tier = "Morgan_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
        {
        id = "Kentucky_Saddler",--32
        name = "Kentucky Saddler",
        model = {
        "a_c_horse_kentuckysaddle_black",
        "a_c_horse_kentuckysaddle_buttermilkbuckskin_pc",
        "a_c_horse_kentuckysaddle_chestnutpinto",
        "a_c_horse_kentuckysaddle_grey",
        "a_c_horse_kentuckysaddle_silverbay",
        },
        tier = "Kentucky_Saddler_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Tennessee_Walker",--32
        name = "Tennessee Walker",
        model = {
        "a_c_horse_tennesseewalker_blackrabicano",
        "a_c_horse_tennesseewalker_chestnut",
        "a_c_horse_tennesseewalker_dapplebay",
        "a_c_horse_tennesseewalker_Flaxenroan",
        "a_c_horse_tennesseewalker_GoldPalomino_pc",
        "a_c_horse_tennesseewalker_MahoganyBay",
        "a_c_horse_tennesseewalker_Redroan",
        },
        tier = "Tennessee_Walker_Tier",
        lawOnly = false,
        outlawOnly = false,
    },

        {
        id = "American_Paint",--34
        name = "American Paint",
        model = {
        "a_c_horse_americanpaint_greyovero",
        "a_c_horse_americanpaint_overo",
        "a_c_horse_americanpaint_splashedwhite",
        "a_c_horse_americanpaint_tobiano",
        },
        tier = "American_Paint_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Ardennes",--36
        name = "Ardennes",
        model = {
        "a_c_horse_ardennes_bayroan",
        "a_c_horse_ardennes_irongreyroan",
        "a_c_horse_ardennes_strawberryroan",
        },
        tier = "Ardennes_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
        {
        id = "Belgian",--36
        name = "Belgian",
        model = {
        "a_c_horse_belgian_blondchestnut",
        "a_c_horse_belgian_mealychestnut",
        },
        tier = "Belgian_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
        {
        id = "GypsyCob",--36
        name = "Gypsy Cob",
        model = {
        "a_c_horse_gypsycob_palominoblagdon",
        "a_c_horse_gypsycob_piebald",
        "a_c_horse_gypsycob_skewbald",
        "a_c_horse_gypsycob_splashedbay",
        "a_c_horse_gypsycob_splashedpiebald",
        "a_c_horse_gypsycob_whiteblagdon",
        },
        tier = "GypsyCob_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
        {
        id = "Shire",--36
        name = "Shire",
        model = {
        "a_c_horse_shire_darkbay",
        "a_c_horse_shire_lightgrey",
        "a_c_horse_shire_ravenblack",
        },
        tier = "Shire_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Suffolk_Punch",--36
        name = "Suffolk Punch",
        model = {
        "a_c_horse_suffolkpunch_redchestnut",
        "a_c_horse_suffolkpunch_sorrel",
        },
        tier = "Suffolk_Punch_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "American_Standardbred",--40
        name = "American Standardbred",
        model = {
        "a_c_horse_americanstandardbred_black",
        "a_c_horse_americanstandardbred_buckskin",
        "a_c_horse_americanstandardbred_lightbuckskin",
        "a_c_horse_americanstandardbred_palominodapple",
        "a_c_horse_americanstandardbred_silvertailbuckskin",
        },
        tier = "American_Standardbred_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Appaloosa",--40
        name = "Appaloosa",
        model = {
        "a_c_horse_appaloosa_blacksnowflake",
        "a_c_horse_appaloosa_blanket",
        "a_c_horse_appaloosa_brownleopard",
        "a_c_horse_appaloosa_fewspotted_pc",
        "a_c_horse_appaloosa_leopard",
        "a_c_horse_appaloosa_leopardblanket",
        },
        tier = "Appaloosa_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
        {
        id = "Gang",--40
        name = "Gang",
        model = {
        "a_c_horse_gang_bill",
        "a_c_horse_gang_charles",
        "a_c_horse_gang_charles_endlesssummer",
        "a_c_horse_gang_dutch",
        "a_c_horse_gang_hosea",
        "a_c_horse_gang_javier",
        "a_c_horse_gang_john",
        "a_c_horse_gang_karen",
        "a_c_horse_gang_kieran",
        "a_c_horse_gang_lenny",
        "a_c_horse_gang_micah",
        "a_c_horse_gang_sadie",
        "a_c_horse_gang_sadie_endlesssummer",
        "a_c_horse_gang_sean",
        "a_c_horse_gang_trelawney",
        "a_c_horse_gang_uncle",
        "a_c_horse_gang_uncle_endlesssummer",
        },
        tier = "Gang_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Breton",--44
        name = "Breton",
        model = {
        "a_c_horse_breton_grullodun",
        "a_c_horse_breton_mealydapplebay",
        "a_c_horse_breton_redroan",
        "a_c_horse_breton_sealbrown",
        "a_c_horse_breton_sorrel",
        "a_c_horse_breton_steelgrey",
        },
        tier = "Breton_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
            {
        id = "Dutch_Warmblood",--46
        name = "Dutch Warmblood",
        model = {
        "a_c_horse_dutchwarmblood_chocolateroan",
        "a_c_horse_dutchwarmblood_sealbrown",
        "a_c_horse_dutchwarmblood_sootybuckskin",
        },
        tier = "Dutch_Warmblood_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Criollo",--48
        name = "Criollo",
        model = {
        "a_c_horse_criollo_baybrindle",
        "a_c_horse_criollo_bayframeovero",
        "a_c_horse_criollo_blueroanovero",
        "a_c_horse_criollo_dun",
        "a_c_horse_criollo_marblesabino",
        "a_c_horse_criollo_sorrelovero",
        },
        tier = "Criollo_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
        {
        id = "Hungarian_Halfbred",--48
        name = "Hungarian Halfbred",
        model = {
        "a_c_horse_hungarianhalfbred_darkdapplegrey",
        "a_c_horse_hungarianhalfbred_flaxenchestnut",
        "a_c_horse_hungarianhalfbred_liverchestnut",
        "a_c_horse_hungarianhalfbred_piebaldtobiano",
        },
        tier = "Hungarian_Halfbred_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
        {
        id = "Kladruber",--48
        name = "Kladruber",
        model = {
        "a_c_horse_kladruber_black",
        "a_c_horse_kladruber_cremello",
        "a_c_horse_kladruber_dapplerosegrey",
        "a_c_horse_kladruber_grey",
        "a_c_horse_kladruber_silver",
        "a_c_horse_kladruber_white",
        },
        tier = "Kladruber_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
        {
        id = "Nokota",--48
        name = "Nokota",
        model = {
        "a_c_horse_nokota_blueroan",
        "a_c_horse_nokota_reversedappleroan",
        "a_c_horse_nokota_whiteroan",
        },
        tier = "Nokota_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Mustang",--50
        name = "Mustang",
        model = {
        "a_c_horse_mustang_blackovero",
        "a_c_horse_mustang_buckskin",
        "a_c_horse_mustang_chestnuttovero",
        "a_c_horse_mustang_goldendun",
        "a_c_horse_mustang_grullodun",
        "a_c_horse_mustang_reddunovero",
        "a_c_horse_mustang_tigerstripedbay",
        "a_c_horse_mustang_wildbay",
        },
        tier = "Mustang_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
            {
        id = "Missouri_Foxtrotter",--52
        name = "Missouri Fox Trotter",
        model = {
        "a_c_horse_missourifoxtrotter_amberchampagne",
        "a_c_horse_missourifoxtrotter_blacktovero",
        "a_c_horse_missourifoxtrotter_blueroan",
        "a_c_horse_missourifoxtrotter_buckskinbrindle",
        "a_c_horse_missourifoxtrotter_dapplegrey",
        "a_c_horse_missourifoxtrotter_sablechampagne",
        "a_c_horse_missourifoxtrotter_silverdapplepinto",
        },
        tier = "Missouri_Foxtrotter_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
        {
        id = "Norfolk_Roadster",--52
        name = "Norfolk Roadster",
        model = {
        "a_c_horse_norfolkroadster_black",
        "a_c_horse_norfolkroadster_dappledbuckskin",
        "a_c_horse_norfolkroadster_piebaldroan",
        "a_c_horse_norfolkroadster_rosegrey",
        "a_c_horse_norfolkroadster_speckledgrey",
        "a_c_horse_norfolkroadster_spottedtricolor",
        },
        tier = "Norfolk_Roadster_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Thoroughbred",--54
        name = "Thoroughbred",
        model = {
        "a_c_horse_thoroughbred_blackchestnut",
        "a_c_horse_thoroughbred_bloodbay",
        "a_c_horse_thoroughbred_brindle",
        "a_c_horse_thoroughbred_dapplegrey",
        "a_c_horse_thoroughbred_reversedappleblack",
        },
        tier = "Thoroughbred_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Arabian",--60
        name = "Arabian",
        model = {
        "a_c_horse_arabian_black",
        "a_c_horse_arabian_grey",
        "a_c_horse_arabian_redchestnut",
        "a_c_horse_arabian_redchestnut_pc",
        "a_c_horse_arabian_rosegreybay",
        "a_c_horse_arabian_warpedbrindle_pc",
        "a_c_horse_arabian_white",
        },
        tier = "Arabian_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
            {
        id = "Turkoman",--60
        name = "Turkoman",
        model = {
        "a_c_horse_turkoman_black",
        "a_c_horse_turkoman_chestnut",
        "a_c_horse_turkoman_darkbay",
        "a_c_horse_turkoman_gold",
        "a_c_horse_turkoman_grey",
        "a_c_horse_turkoman_perlino",
        "a_c_horse_turkoman_silver",
        },
        tier = "Turkoman_Tier",
        lawOnly = false,
        outlawOnly = false,
    },
    {
        id = "Andalusian",--64
        name = "Andalusian",
        model = {
        "a_c_horse_andalusian_darkbay",
        "a_c_horse_andalusian_perlino",
        "a_c_horse_andalusian_rosegray",
        },
        tier = "Andalusian_Tier",
        lawOnly = false,
        outlawOnly = false,
    },

  --  {
   --     id = "Buell_War_Veteran",
    --    name = "Buell (War Veteran)",
    --    model = {
    --        "A_C_Horse_Buell_WarVets",
     --       "A_C_Horse_Buell_WarVets",
    --   },
   --     tier = "Buell_Tier",
    --    lawOnly = false,
   --     outlawOnly = false,
    --},

    --{
      --  id = "Eagle",
      --  name = "Eagle",
     --   model = {
      --  "A_C_Horse_EagleFlies",
     --   "A_C_Horse_EagleFlies",
    --    },
    --    tier = "EagleFlies_Tier",
     --   lawOnly = false,
     --   outlawOnly = false,
   -- },
   -- {
    --    id = "John_Endless_Summer",
    --    name = "John's Horse - Endless Summer",
    --    model = {
   --     "A_C_Horse_John_EndlessSummer",
   --     "A_C_Horse_John_EndlessSummer",
   --     },
   --     tier = "John_Tier",
  --      lawOnly = false,
   --     outlawOnly = false,
  --  },
   -- {
    --    id = "Mangy",
   --     name = "Mangy",
   --     model = {
  --      "A_C_Horse_MP_Mangy_Backup",
   --     "A_C_Horse_MP_Mangy_Backup",
   --     },
   --     tier = "Mangy_Tier",
    --    lawOnly = false,
    --    outlawOnly = false,
 --  },
   -- {
    --    id = "Murfreebrood",
     --   name = "Murfree Brood",
    --    model = {
    --    "a_c_horse_murfreebrood_mange_01",
    --    "a_c_horse_murfreebrood_mange_02",
    --    "a_c_horse_murfreebrood_mange_03",
    --    },
    --    tier = "Murfreebrood_Tier",
    --    lawOnly = false,
   --     outlawOnly = true,
  --  },
   -- {
    --    id = "Winter02_01",
    --    name = "Winter Horse - 02",
     --   model = {
     --   "A_C_Horse_Winter02_01",
     --   "A_C_Horse_Winter02_01",
     --   },
     --   tier = "Winter_Tier",
    --    lawOnly = false,
     --   outlawOnly = false,
  --  },
   -- {
   --     id = "Mule",
    --    name = "Mule",
    --    model = {
    --    "a_c_horsemule_01",
    --    "a_c_horsemulepainted_01",
    --    },
    --    tier = "Mule_Tier",
    --    lawOnly = false,
    --    outlawOnly = false,
 --   },
}

--------------------------------------------------------------
--=====================================================================
--  HELPERS
--=====================================================================

function CoalStables.GetTierStats(tierName)
    local tier = Config.Tiers[tierName]
    if not tier then
        -- Fallback is a “plain” mount
        return {
            label = "Plain Mount",
            speed = 1.0,
            accel = 1.0,
            handling = 1.0,
            bravery = 1.0,
            health = 1.0,
            stamina = 1.0,
            priceMult = 1.0,
        }
    end
    return tier
end

-- Clamp helper
local function clamp(value, min, max)
    if value < min then return min end
    if value > max then return max end
    return value
end

-- Builds a final stat block for a given horse id
function CoalStables.GetHorseData(horseId)
    for _, horse in ipairs(Config.Horses) do
        if horse.id == horseId then
            local tierStats = CoalStables.GetTierStats(horse.tier)

            -- Support either models = { ... } or model = "..."
            local models = horse.models
            if not models then
                if type(horse.model) == "table" then
                    models = horse.model
                elseif type(horse.model) == "string" then
                    models = { horse.model }
                else
                    models = {}
                end
            end

            local model = models[1] or horse.model  -- default model

            local speed   = clamp(tierStats.speed,   0.8, Config.MaxStats.speed)
            local accel   = clamp(tierStats.accel,   0.8, Config.MaxStats.accel)
            local health  = clamp(tierStats.health,  0.8, Config.MaxStats.health)
            local stamina = clamp(tierStats.stamina, 0.8, Config.MaxStats.stamina)

            local price = math.floor((Config.BasePrice * (tierStats.priceMult or 1.0)) + 0.5)

            return {
                id         = horse.id,
                name       = horse.name,
                model      = model,      -- default model
                models     = models,     -- all variants
                tier       = horse.tier,
                tierLabel  = tierStats.label,
                speed      = speed,
                accel      = accel,
                handling   = tierStats.handling or 1.0,
                bravery    = tierStats.bravery or 1.0,
                health     = health,
                stamina    = stamina,
                price      = price,
                lawOnly    = horse.lawOnly or false,
                outlawOnly = horse.outlawOnly or false,
            }
        end
    end

    return nil
end

-- Used in menus – returns a simple list of options for UI
function CoalStables.GetBuyableHorses(filter)
    local results = {}

    for _, horse in ipairs(Config.Horses) do
        local data = CoalStables.GetHorseData(horse.id)
        if data then
            local ok = true

            if filter then
                if filter.law and not data.lawOnly and not filter.includeNonLaw then
                    ok = false
                end
                if filter.outlaw and not data.outlawOnly and not filter.includeNonOutlaw then
                    ok = false
                end
            end

            if ok then
                table.insert(results, data)
            end
        end
    end

    return results
end