-- BuildATack.lua
-- Simple data module for the Build-A-Tack Workshop

CoalBuildATack = CoalBuildATack or {}
local BT = {}

-- Which resource to load JSON from
local BA_TACK_RESNAME = GetCurrentResourceName and GetCurrentResourceName() or "coal_stables"

function CoalBuildATack.SetDataResourceName(resName)
    if type(resName) == "string" and resName ~= "" then
        BA_TACK_RESNAME = resName
    end
end

-----------------------------------------------------------------------
-- Shared palettes: reuse Beauty / Build-A-Horse palettes if present
-----------------------------------------------------------------------
local T_PALETTES =
    (CoalBeauty and CoalBeauty._data and CoalBeauty._data.PALETTES)
    or {
        P1  = "metaped_tint_horse",
        P2  = "metaped_tint_horse_leather",
        P3  = "metaped_tint_generic",
        P4  = "metaped_tint_animal",
        P5  = "metaped_tint_combined_leather",
        P6  = "metaped_tint_genericclean",
        P7  = "metaped_tint_eye",
        P8  = "metaped_tint_hair",
        P9  = "metaped_tint_leather",
        P10 = "metaped_tint_hat",
        P11 = "metaped_tint_mpadv",
        P12 = "metaped_tint_makeup",
        P13 = "metaped_tint_generic_weathered",
    }

BT.PALETTES = T_PALETTES

local function BuildPaletteItems()
    local items      = {}
    local orderedIds = {}

    for key in pairs(T_PALETTES) do
        orderedIds[#orderedIds+1] = key
    end

    table.sort(orderedIds, function(a, b)
        local na = tonumber(a:match("^P(%d+)$") or 99)
        local nb = tonumber(b:match("^P(%d+)$") or 99)
        return na < nb
    end)

    for _, key in ipairs(orderedIds) do
        local paletteName = T_PALETTES[key]
        items[#items+1] = {
            id        = key,
            label     = string.format("Palette %s", key),
            palette   = paletteName,
            sortIndex = tonumber(key:match("^P(%d+)$")) or 0,
        }
    end

    return items
end

-----------------------------------------------------------------------
-- JSON loading helpers
-----------------------------------------------------------------------
local function LoadJson(file)
    local raw = LoadResourceFile(BA_TACK_RESNAME, "data/" .. file)
    if not raw or raw == "" then
        print(("[BuildATack] missing file: data/%s"):format(file))
        return {}
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print(("[BuildATack] ERROR decoding %s: %s"):format(file, tostring(decoded)))
        return {}
    end

    return decoded
end

local SADDLES    = LoadJson("saddles.json")
local STIRRUPS   = LoadJson("stirrups.json")
local HORNS      = LoadJson("horns.json")
local BLANKETS   = LoadJson("blankets.json")
local SADDLEBAGS = LoadJson("saddlebags.json")
local HOLSTERS   = LoadJson("holsters.json") or {}

-- Harness styles: try harness.json first; if it's missing, fall back to a single
-- built-in harness asset so Build-A-Tack can run without coal_tackroom.lua.
local HARNESS    = LoadJson("harness.json") or {}

if not HARNESS or #HARNESS == 0 then
    HARNESS = {
        {
            name   = "horse_harness_standard",
            label  = "Standard Harness",
            assets = {
                {
                    drawable = "mp_horselantern_harness_001",
                    albedo   = "mp_horselantern_harness_001_ab",
                    normal   = "mp_horselantern_harness_001_nm",
                    material = "mp_horselantern_harness_001_m",
                    palette  = T_PALETTES.P2 or "metaped_tint_horse_leather",
                    tint0    = 138,
                    tint1    = 138,
                    tint2    = 138,
                },
            },
        },
    }
end


-----------------------------------------------------------------------
-- Category list for the UI
-----------------------------------------------------------------------
BT.Categories = {
        -- Blankets
    { id = "Blanket_style",   label = "Blanket Style" },
    { id = "Blanket_palette", label = "Blanket Palette" },
    { id = "Blanket_tint0",   label = "Blanket Primary Tint",   useItemLabel = false },
    { id = "Blanket_tint1",   label = "Blanket Secondary Tint", useItemLabel = false },
    { id = "Blanket_tint2",   label = "Blanket Accent Tint",    useItemLabel = false },

    -- Saddles
    { id = "Saddle_style",   label = "Saddle Style" },
    { id = "Saddle_palette", label = "Saddle Palette" },
    { id = "Saddle_tint0",   label = "Saddle Primary Tint",   useItemLabel = false },
    { id = "Saddle_tint1",   label = "Saddle Secondary Tint", useItemLabel = false },
    { id = "Saddle_tint2",   label = "Saddle Accent Tint",    useItemLabel = false },

    -- Stirrups
    { id = "Stirrups_style",   label = "Stirrups Style" },
    { id = "Stirrups_palette", label = "Stirrups Palette" },
    { id = "Stirrups_tint0",   label = "Stirrups Primary Tint",   useItemLabel = false },
    { id = "Stirrups_tint1",   label = "Stirrups Secondary Tint", useItemLabel = false },
    { id = "Stirrups_tint2",   label = "Stirrups Accent Tint",    useItemLabel = false },

    -- Horns
    { id = "Horn_style",   label = "Horn Style" },
    { id = "Horn_palette", label = "Horn Palette" },
    { id = "Horn_tint0",   label = "Horn Primary Tint",   useItemLabel = false },
    { id = "Horn_tint1",   label = "Horn Secondary Tint", useItemLabel = false },
    { id = "Horn_tint2",   label = "Horn Accent Tint",    useItemLabel = false },

    -- Harness
    { id = "Harness_style",   label = "Harness Style" },
    { id = "Harness_palette", label = "Harness Palette" },
    { id = "Harness_tint0",   label = "Harness Primary Tint",   useItemLabel = false },
    { id = "Harness_tint1",   label = "Harness Secondary Tint", useItemLabel = false },
    { id = "Harness_tint2",   label = "Harness Accent Tint",    useItemLabel = false },

    -- Holsters
    { id = "Holster_style",   label = "Holster Style" },
    { id = "Holster_palette", label = "Holster Palette" },
    { id = "Holster_tint0",   label = "Holster Primary Tint",   useItemLabel = false },
    { id = "Holster_tint1",   label = "Holster Secondary Tint", useItemLabel = false },
    { id = "Holster_tint2",   label = "Holster Accent Tint",    useItemLabel = false },

    -- Saddlebags
    { id = "Bag_style",   label = "Saddlebags Style" },
    { id = "Bag_palette", label = "Saddlebags Palette" },
    { id = "Bag_tint0",   label = "Bags Primary Tint",   useItemLabel = false },
    { id = "Bag_tint1",   label = "Bags Secondary Tint", useItemLabel = false },
    { id = "Bag_tint2",   label = "Bags Accent Tint",    useItemLabel = false },
}

-----------------------------------------------------------------------
-- Style and tint item builders
-----------------------------------------------------------------------
local function prettifyName(name, fallbackPrefix)
    if not name or name == "" then return fallbackPrefix or "Style" end
    local trimmed = name:gsub("^horse_equipment_", "")
    trimmed = trimmed:gsub("_new_", "_")
    trimmed = trimmed:gsub("_", " ")
    trimmed = trimmed:gsub("^%l", string.upper)
    return trimmed
end


local function buildStyleItemsFrom(list, slotLabel)
    local items = {}

    -- Universal "None" option for this slot
    local noneLabel = "No " .. (slotLabel or "Item")
    items[#items+1] = {
        id            = 0,
        label         = noneLabel,
        name          = nil,
        swatchTexture = nil,
        swatchPalette = nil,
        swatchTint0   = nil,
        swatchTint1   = nil,
        swatchTint2   = nil,
        assets        = {},
        sortIndex     = 0,
        none          = true,
    }

    for i, rec in ipairs(list) do
        local label = rec.label or prettifyName(rec.name, slotLabel or "Style")

        local assets = rec.assets
        if not assets and rec.drawable then
            -- blankets-style records (single asset inline)
            assets = {
                {
                    drawable = rec.drawable,
                    albedo   = rec.albedo,
                    normal   = rec.normal,
                    material = rec.material,
                    palette  = rec.palette,
                    tint0    = rec.tint0,
                    tint1    = rec.tint1,
                    tint2    = rec.tint2,
                },
            }
        end

        items[#items+1] = {
            id            = rec.name or (slotLabel .. "_" .. i),
            label         = label,
            name          = rec.name,
            swatchTexture = rec.swatchTexture,
            swatchPalette = rec.swatchPalette,
            swatchTint0   = rec.swatchTint0,
            swatchTint1   = rec.swatchTint1,
            swatchTint2   = rec.swatchTint2,
            assets        = assets or {},
            sortIndex     = i,
        }
    end
    return items
end


local STYLE_ITEMS = {
    Saddle   = buildStyleItemsFrom(SADDLES,    "Saddle"),
    Stirrups = buildStyleItemsFrom(STIRRUPS,   "Stirrups"),
    Horn     = buildStyleItemsFrom(HORNS,      "Horn"),
    Blanket  = buildStyleItemsFrom(BLANKETS,   "Blanket"),
    Bag      = buildStyleItemsFrom(SADDLEBAGS, "Bags"),
    Harness  = buildStyleItemsFrom(HARNESS,    "Harness"),
    Holster  = buildStyleItemsFrom(HOLSTERS,   "Holster"),
}

local PALETTE_ITEMS = BuildPaletteItems()
local TINT_ITEMS    = {}

local function getTintItems(catId)
    local cached = TINT_ITEMS[catId]
    if cached then return cached end

    local items = {}
    for i = 0, 254 do
        items[#items+1] = {
            id        = i,
            value     = i,
            label     = tostring(i),
            sortIndex = i,
        }
    end

    TINT_ITEMS[catId] = items
    return items
end

-----------------------------------------------------------------------
-- Public API
-----------------------------------------------------------------------
function CoalBuildATack.GetCategories()
    return BT.Categories
end

function CoalBuildATack.GetItemsForCategory(catId)
    if not catId then return {} end

    -- Styles
    if catId == "Saddle_style"   then return STYLE_ITEMS.Saddle   end
    if catId == "Stirrups_style" then return STYLE_ITEMS.Stirrups end
    if catId == "Horn_style"     then return STYLE_ITEMS.Horn     end
    if catId == "Blanket_style"  then return STYLE_ITEMS.Blanket  end
    if catId == "Bag_style"      then return STYLE_ITEMS.Bag      end
    if catId == "Harness_style"  then return STYLE_ITEMS.Harness  end
    if catId == "Holster_style"  then return STYLE_ITEMS.Holster  end

    -- Palettes
    if  catId == "Saddle_palette"
        or catId == "Stirrups_palette"
        or catId == "Horn_palette"
        or catId == "Blanket_palette"
        or catId == "Bag_palette"
        or catId == "Harness_palette"
        or catId == "Holster_palette" then
        return PALETTE_ITEMS
    end

    -- Tints
    if catId:match("_tint[012]$") then
        return getTintItems(catId)
    end

    return {}
end

CoalBuildATack._data = BT



-- Cleanup spawned/preview horses when resource stops/restarts
local function __coalDeleteEntitySafe(ent)
    if ent and ent ~= 0 and DoesEntityExist(ent) then
        SetEntityAsMissionEntity(ent, true, true)
        DeleteEntity(ent)
    end
end

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    __coalDeleteEntitySafe(currentHorse)
    __coalDeleteEntitySafe(previewHorse)
    __coalDeleteEntitySafe(PreviewHorse)
    __coalDeleteEntitySafe(currentPreviewHorse)
    __coalDeleteEntitySafe(CurrentPreviewHorse)
    __coalDeleteEntitySafe(stableHorse)
    __coalDeleteEntitySafe(StableHorse)

    -- Extra safety: delete nearby horses spawned by this script if they are mission entities we own.
    local playerPed = PlayerPedId()
    if playerPed and playerPed ~= 0 then
        local pcoords = GetEntityCoords(playerPed)
        local handle, ped = FindFirstPed()
        local success = true
        repeat
            if ped and ped ~= 0 and ped ~= playerPed and DoesEntityExist(ped) then
                if IsPedAPlayer(ped) == false and GetPedType(ped) == 28 then
                    local coords = GetEntityCoords(ped)
                    if #(pcoords - coords) < 60.0 then
                        SetEntityAsMissionEntity(ped, true, true)
                        DeleteEntity(ped)
                    end
                end
            end
            success, ped = FindNextPed(handle)
        until not success
        EndFindPed(handle)
    end
end)

