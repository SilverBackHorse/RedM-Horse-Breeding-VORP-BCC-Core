
local Core = exports.vorp_core:GetCore()
local FeatherMenu = exports['feather-menu'].initiate()


Config = Config or {}
Config.Stables = {
    {
        id = "valentine",
        name = "Valentine Custom Coats",
        coords = vector3(-374.33, 786.83, 116.17),
        heading = 90.0,
        showBlip = true,
        blipSprite = 1210165179,
        blipScale = 0.6,
    },
    {
        id = "strawberry",
        name = "Strawberry Custom Coats",
        coords = vector3(-1813.0, -569.0, 156.0),
        heading = 50.0,
        showBlip = true,
        blipSprite = 1210165179,
        blipScale = 0.6,
    },
    {
        id = "blackwater",
        name = "Blackwater Custom Coats",
        coords = vector3(-875.0, -1366.0, 43.5),
        heading = 180.0,
        showBlip = true,
        blipSprite = 1210165179,
        blipScale = 0.6,
    },

    -- #################################################
    -- bcc-horsebreeding / coal_stables_vorp custom coat locations start here
    -- Added By: ShAd0wSn1pER117
    -- #################################################
    {
        id = "tumbleweed_custom_coats",
        name = "Tumbleweed Custom Coats",
        coords = vector3(-5522.73, -3046.49, -2.39),
        heading = 0.0,
        showBlip = true,
        blipSprite = 1210165179,
        blipScale = 0.6,
    },
    {
        id = "gaptooth_custom_coats",
        name = "Gaptooth Custom Coats",
        coords = vector3(-3700.08, -2523.08, -13.79),
        heading = 0.0,
        showBlip = true,
        blipSprite = 1210165179,
        blipScale = 0.6,
    },
    {
        id = "lemoyne_custom_coats",
        name = "Lemoyne Custom Coats",
        coords = vector3(2502.04, -1439.80, 46.31),
        heading = 0.0,
        showBlip = true,
        blipSprite = 1210165179,
        blipScale = 0.6,
    }
    -- #################################################
    -- bcc-horsebreeding / coal_stables_vorp custom coat locations end here
    -- #################################################
}



local UI = { open = false, page = "main", index = 1, horses = {}, stable = nil, category = nil, categoryLabel = nil }
local CoalFeatherMenu, renderFeatherMenu
local CoalFeatherPageCounter = 0

local function setFeatherKeepInput(enabled)
    -- Keep player controls active while Feather's NUI is focused.
    -- This preserves Coal's walk-around preview behavior instead of turning the menu into a hard lock.
    pcall(function() SetNuiFocusKeepInput(enabled and true or false) end)
end
local State = {
    horseId = nil, horseName = nil, horseModel = nil, gender = nil,
    appearance = {}, tackColors = {},
    horseIndex = { coat = 1, palette = 1, tint0 = 1, tint1 = 1, tint2 = 1, normal = 1, material = 1, scale = 31 },
    tackIndex = {}
}
local previewHorse = 0
local lastAppliedRealHorse, lastAppliedRealHorseId = 0, 0
local SavedCache = {}

local keys = { up = 0x6319DB71, down = 0x05CA7C52, left = 0xA65EBAB4, right = 0xDEB34313, enter = 0xC7B5340A, back = 0x156F7119, g = 0x760A9C6F }
local Palettes = { "metaped_tint_horse", "metaped_tint_horse_001", "metaped_tint_animal", "metaped_tint_hair", "metaped_tint_eye", "metaped_tint_horse_leather", "metaped_tint_horse_leather_001", "metaped_tint_leather", "metaped_tint_generic", "metaped_tint_genericclean", "metaped_tint_generic_weathered" }
local CoatNums = {}
CreateThread(function()
    for num = 845, 999 do
        local blocked = (num == 874 or num == 880 or num == 892 or num == 893 or num == 990 or (num >= 900 and num <= 987))
        if not blocked then CoatNums[#CoatNums + 1] = num end
    end
end)

local Defaults = {
    hand = { drawable = "p_c_horse_01_hand_000", albedo = "p_c_horse_01_hand_000_C0_845_ab", normal = "p_c_horse_01_hand_000_C0_001_nm", material = "p_c_horse_01_hand_000_C0_001_m", palette = "metaped_tint_horse", tint0 = 138, tint1 = 138, tint2 = 138 },
    head = { drawable = "p_c_horse_01_head_000", albedo = "p_c_horse_01_head_000_C0_845_ab", normal = "p_c_horse_01_head_000_C0_001_nm", material = "p_c_horse_01_head_000_C0_001_m", palette = "metaped_tint_horse", tint0 = 138, tint1 = 138, tint2 = 138 },
    mis2 = { drawable = "p_c_horse_01_mis2_000", albedo = "p_c_horse_01_mis2_000_C0_845_ab", normal = "p_c_horse_01_mis2_000_C0_001_nm", material = "p_c_horse_01_mis2_000_C0_001_m", palette = "metaped_tint_horse", tint0 = 138, tint1 = 138, tint2 = 138 }
}

local function notify(msg) Core.NotifyRightTip(msg, 3500) end
local function joaatSafe(v) if type(v) == "number" then return v end return joaat(tostring(v)) end
local function decodeJson(s)
    if type(s) == "table" then return s end
    if not s or s == "" then return {} end
    local ok, data = pcall(json.decode, s)
    if ok and type(data) == "table" then return data end
    return {}
end
local function getStableCoords(stable) return stable.coords or stable.Coords or stable.NpcCoords or stable.npcCoords or stable.location end
local function updateVariation(ped) if ped and ped ~= 0 and DoesEntityExist(ped) then Citizen.InvokeNative(0xCC8CA3E88256E58F, ped, false, true, true, true, false) end end
local function setMetaTag(ped, drawable, albedo, normal, material, palette, tint0, tint1, tint2)
    if not ped or ped == 0 or not DoesEntityExist(ped) or not drawable or not albedo or not normal or not material then return false end
    local ok = pcall(function()
        Citizen.InvokeNative(0xBC6DF00D7A4A6819, ped, joaatSafe(drawable), joaatSafe(albedo), joaatSafe(normal), joaatSafe(material), palette and joaatSafe(palette) or 0, tonumber(tint0) or 0, tonumber(tint1) or 0, tonumber(tint2) or 0)
    end)
    return ok
end
local function ensureBody()
    State.appearance = State.appearance or {}
    State.appearance.body = State.appearance.body or {}
    for key, def in pairs(Defaults) do
        State.appearance.body[key] = State.appearance.body[key] or {}
        for k, v in pairs(def) do if State.appearance.body[key][k] == nil then State.appearance.body[key][k] = v end end
    end
end

local function applyAllToPed(ped, appearance, tackColors)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    local app, tack = appearance or State.appearance or {}, tackColors or State.tackColors or {}
    if app.body then
        for _, key in ipairs({ "hand", "head", "mis2" }) do
            local r = app.body[key]
            if r then setMetaTag(ped, r.drawable, r.albedo, r.normal, r.material, r.palette, r.tint0, r.tint1, r.tint2) end
        end
    end
    if app.scale then Citizen.InvokeNative(0x25ACFC650B65C538, ped, tonumber(app.scale) or 1.0) end

    if app.hair then
        for _, item in pairs(app.hair or {}) do
            if type(item) == "table" then
                if item.assets and type(item.assets) == "table" then
                    for _, a in ipairs(item.assets) do
                        if a.drawable and a.albedo and a.normal and a.material then
                            setMetaTag(ped, a.drawable, a.albedo, a.normal, a.material, a.palette or item.palette or "metaped_tint_horse", a.tint0 or item.tint0, a.tint1 or item.tint1, a.tint2 or item.tint2)
                        elseif a.shopItemHash then
                            Citizen.InvokeNative(0xD3A7B003ED343FD9, ped, tonumber(a.shopItemHash) or joaatSafe(a.shopItemHash), true, true, true)
                        end
                    end
                elseif item.drawable and item.albedo and item.normal and item.material then
                    setMetaTag(ped, item.drawable, item.albedo, item.normal, item.material, item.palette or "metaped_tint_horse", item.tint0, item.tint1, item.tint2)
                elseif item.shopItemHash then
                    Citizen.InvokeNative(0xD3A7B003ED343FD9, ped, tonumber(item.shopItemHash) or joaatSafe(item.shopItemHash), true, true, true)
                end
            end
        end
    end

    for _, item in pairs(tack or {}) do
        if type(item) == "table" then
            if item.assets and type(item.assets) == "table" then
                for _, a in ipairs(item.assets) do
                    if a.drawable and a.albedo and a.normal and a.material then
                        setMetaTag(ped, a.drawable, a.albedo, a.normal, a.material, a.palette or item.palette or "metaped_tint_horse_leather", a.tint0 or item.tint0, a.tint1 or item.tint1, a.tint2 or item.tint2)
                    elseif a.shopItemHash then
                        Citizen.InvokeNative(0xD3A7B003ED343FD9, ped, tonumber(a.shopItemHash) or joaatSafe(a.shopItemHash), true, true, true)
                    end
                end
            elseif item.drawable and item.albedo and item.normal and item.material then
                setMetaTag(ped, item.drawable, item.albedo, item.normal, item.material, item.palette or "metaped_tint_horse_leather", item.tint0, item.tint1, item.tint2)
            elseif item.shopItemHash then
                Citizen.InvokeNative(0xD3A7B003ED343FD9, ped, tonumber(item.shopItemHash) or joaatSafe(item.shopItemHash), true, true, true)
            end
        end
    end
    updateVariation(ped)
    return true
end

local function deletePreview() if previewHorse ~= 0 and DoesEntityExist(previewHorse) then DeleteEntity(previewHorse) end previewHorse = 0 end
local function spawnPreview(modelName)
    deletePreview()
    local c = UI.stable and getStableCoords(UI.stable)
    if not c then return end
    local model = joaat(modelName)
    RequestModel(model)
    local timeout = GetGameTimer() + 8000
    while not HasModelLoaded(model) and GetGameTimer() < timeout do Wait(10) end
    if not HasModelLoaded(model) then notify("Could not load BCC horse model.") return end
    previewHorse = CreatePed(model, c.x + 2.0, c.y, c.z - 1.0, UI.stable.heading or 0.0, false, false, false, false)
    if previewHorse == 0 then notify("Could not create Coal preview horse.") return end
    FreezeEntityPosition(previewHorse, true)
    SetEntityInvincible(previewHorse, true)
    SetBlockingOfNonTemporaryEvents(previewHorse, true)
    Citizen.InvokeNative(0x283978A15512B2FE, previewHorse, true)
    SetPedPromptName(previewHorse, State.horseName or "Coal Preview")
    applyAllToPed(previewHorse)
end

local function loadHorseForEdit(h)
    State.horseId, State.horseName, State.horseModel = tonumber(h.id), h.name or "Horse", h.model
    State.gender = h.gender or "male"
    local saved = Core.Callback.TriggerAwait("coal_bcc:GetAppearance", State.horseId) or {}
    State.gender = saved.gender or State.gender or "male"
    State.appearance, State.tackColors = decodeJson(saved.appearance), decodeJson(saved.tackColors)
    SavedCache[State.horseId] = { appearance = State.appearance, tackColors = State.tackColors }
    spawnPreview(State.horseModel)
end

local function ApplyToOwnedBccHorse(horseId)
    horseId = tonumber(horseId)
    if not horseId then return false end

    local saved = SavedCache[horseId]
    if not saved then
        local db = Core.Callback.TriggerAwait("coal_bcc:GetAppearance", horseId)
        if db then
            saved = { appearance = decodeJson(db.appearance), tackColors = decodeJson(db.tackColors) }
            SavedCache[horseId] = saved
        end
    end
    if not saved then return false end

    local handle, ped = FindFirstPed()
    local success = true
    local applied = false

    repeat
        if ped and ped ~= 0 and DoesEntityExist(ped) and not IsPedAPlayer(ped) then
            local stateId = Entity(ped).state.myHorseId
            if tonumber(stateId) == horseId then
                applyAllToPed(ped, saved.appearance, saved.tackColors)
                lastAppliedRealHorse = ped
                lastAppliedRealHorseId = horseId
                applied = true
            end
        end
        success, ped = FindNextPed(handle)
    until not success

    EndFindPed(handle)
    return applied
end


RegisterNetEvent("coal_bcc:ApplyToBccEntity", function(entity, horseId)
    horseId = tonumber(horseId)
    if not entity or entity == 0 or not DoesEntityExist(entity) or not horseId then return end

    local saved = SavedCache[horseId]
    if not saved then
        local db = Core.Callback.TriggerAwait("coal_bcc:GetAppearance", horseId)
        if db then
            saved = { appearance = decodeJson(db.appearance), tackColors = decodeJson(db.tackColors) }
            SavedCache[horseId] = saved
        end
    end

    if saved then
        applyAllToPed(entity, saved.appearance, saved.tackColors)
        print("[coal_bcc] Applied saved Coal visuals to BCC entity:", entity, "horseId:", horseId)
    end
end)

local function saveHorse()
    if not State.horseId then notify("No BCC horse selected.") return end
    SavedCache[State.horseId] = { appearance = State.appearance or {}, tackColors = State.tackColors or {} }
    print("[coal_bcc] Saving to player_horses id:", State.horseId, "name:", State.horseName or "unknown")
    TriggerServerEvent("coal_bcc:SaveAppearance", State.horseId, json.encode(State.appearance or {}), json.encode(State.tackColors or {}))
    local appliedNow = ApplyToOwnedBccHorse(State.horseId)
    print("[coal_bcc] Apply to matching BCC myHorseId entity:", appliedNow)
end

local function changeHorse(category, delta)
    if previewHorse == 0 or not DoesEntityExist(previewHorse) then notify("Select a BCC horse first.") return end
    ensureBody()
    if category == "reset" then State.appearance.body = nil notify("Coat reset. Save to keep reset.") applyAllToPed(previewHorse) return end
    local idx = (State.horseIndex[category] or 1) + delta
    local max = 1
    if category == "coat" then max = #CoatNums elseif category == "palette" then max = #Palettes elseif category == "tint0" or category == "tint1" or category == "tint2" then max = 253 elseif category == "normal" then max = 3 elseif category == "material" then max = 5 elseif category == "scale" then max = 81 end
    if idx < 1 then idx = max end
    if idx > max then idx = 1 end
    State.horseIndex[category] = idx
    if category == "coat" then
        local num = CoatNums[idx] or 845
        State.appearance.body.hand.albedo = ("p_c_horse_01_hand_000_C0_%03d_ab"):format(num)
        State.appearance.body.head.albedo = ("p_c_horse_01_head_000_C0_%03d_ab"):format(num)
        State.appearance.body.mis2.albedo = ("p_c_horse_01_mis2_000_C0_%03d_ab"):format(num)
        notify(("Coal Coat %03d"):format(num))
    elseif category == "palette" then
        local pal = Palettes[idx] or Palettes[1]
        for _, k in ipairs({ "hand", "head", "mis2" }) do State.appearance.body[k].palette = pal end
        notify("Coal Palette " .. tostring(idx))
    elseif category == "tint0" or category == "tint1" or category == "tint2" then
        local value = idx + 1
        for _, k in ipairs({ "hand", "head", "mis2" }) do State.appearance.body[k][category] = value end
        notify("Coal " .. category .. " " .. tostring(value))
    elseif category == "normal" then
        local nums = { 1, 2, 4 }
        local num = nums[idx] or 1
        State.appearance.body.hand.normal = ("p_c_horse_01_hand_000_C0_%03d_nm"):format(num)
        State.appearance.body.head.normal = ("p_c_horse_01_head_000_C0_%03d_nm"):format(num)
        State.appearance.body.mis2.normal = ("p_c_horse_01_mis2_000_C0_%03d_nm"):format(num)
        notify("Coal Physique " .. tostring(num))
    elseif category == "material" then
        State.appearance.body.hand.material = ("p_c_horse_01_hand_000_C0_%03d_m"):format(idx)
        State.appearance.body.head.material = ("p_c_horse_01_head_000_C0_%03d_m"):format(idx)
        State.appearance.body.mis2.material = ("p_c_horse_01_mis2_000_C0_%03d_m"):format(idx)
        notify("Coal Shine " .. tostring(idx))
    elseif category == "scale" then
        State.appearance.scale = 0.70 + ((idx - 1) * 0.01)
        notify(("Coal Scale %.2f"):format(State.appearance.scale))
    end
    applyAllToPed(previewHorse)
end


local function copyItem(item)
    if type(item) ~= "table" then return item end
    local ok, encoded = pcall(json.encode, item)
    if ok and encoded then
        local ok2, decoded = pcall(json.decode, encoded)
        if ok2 and decoded then return decoded end
    end
    return item
end

local function applyHairTint(slot, tintKey, value)
    State.appearance.hair = State.appearance.hair or {}

    local item = State.appearance.hair[slot]
    if not item then
        local list = CoalBuildAHorse and CoalBuildAHorse.GetItemsForCategory and CoalBuildAHorse.GetItemsForCategory(slot == "mane" and "manes" or "tails") or {}
        if list and #list > 0 then
            item = copyItem(list[1])
            State.appearance.hair[slot] = item
        end
    end

    if type(item) ~= "table" then return end

    item[tintKey] = value

    if item.assets and type(item.assets) == "table" then
        for _, a in ipairs(item.assets) do
            a[tintKey] = value
        end
    end
end

local function applyHairPalette(slot, palette)
    State.appearance.hair = State.appearance.hair or {}

    local item = State.appearance.hair[slot]
    if not item then
        local list = CoalBuildAHorse and CoalBuildAHorse.GetItemsForCategory and CoalBuildAHorse.GetItemsForCategory(slot == "mane" and "manes" or "tails") or {}
        if list and #list > 0 then
            item = copyItem(list[1])
            State.appearance.hair[slot] = item
        end
    end

    if type(item) ~= "table" then return end

    item.palette = palette

    if item.assets and type(item.assets) == "table" then
        for _, a in ipairs(item.assets) do
            a.palette = palette
        end
    end
end

local function changeHair(category, delta)
    if previewHorse == 0 or not DoesEntityExist(previewHorse) then
        notify("Select a BCC horse first.")
        return
    end

    if not CoalBuildAHorse or not CoalBuildAHorse.GetItemsForCategory then
        notify("Coal horse hair data not loaded.")
        return
    end

    State.appearance.hair = State.appearance.hair or {}

    if category == "manes" or category == "tails" then
        local list = CoalBuildAHorse.GetItemsForCategory(category) or {}
        if #list == 0 then
            notify("No Coal items for " .. tostring(category))
            return
        end

        local idxKey = category
        local idx = (State.horseIndex[idxKey] or 1) + delta
        if idx < 1 then idx = #list end
        if idx > #list then idx = 1 end
        State.horseIndex[idxKey] = idx

        local slot = (category == "manes") and "mane" or "tail"
        State.appearance.hair[slot] = copyItem(list[idx])

        notify((list[idx].label or list[idx].name or category) .. " [" .. idx .. "/" .. #list .. "]")
        applyAllToPed(previewHorse)
        return
    end

    local slot = category:find("^tail") and "tail" or "mane"

    if category == "mane_palette" or category == "tail_palette" then
        local idxKey = category
        local idx = (State.horseIndex[idxKey] or 1) + delta
        if idx < 1 then idx = #Palettes end
        if idx > #Palettes then idx = 1 end
        State.horseIndex[idxKey] = idx
        applyHairPalette(slot, Palettes[idx])
        notify((slot == "mane" and "Mane" or "Tail") .. " Palette " .. tostring(idx))
        applyAllToPed(previewHorse)
        return
    end

    local tintKey = category:match("tint%d")
    if tintKey then
        local idxKey = category
        local idx = (State.horseIndex[idxKey] or 1) + delta
        if idx < 1 then idx = 253 end
        if idx > 253 then idx = 1 end
        State.horseIndex[idxKey] = idx
        local value = idx + 1
        applyHairTint(slot, tintKey, value)
        notify((slot == "mane" and "Mane" or "Tail") .. " " .. tintKey .. " " .. tostring(value))
        applyAllToPed(previewHorse)
        return
    end
end

local function changeTack(category, delta)
    if previewHorse == 0 or not DoesEntityExist(previewHorse) then notify("Select a BCC horse first.") return end
    if not CoalTack or not CoalTack.GetItemsForCategory then notify("Coal tack data not loaded.") return end
    local list = CoalTack.GetItemsForCategory(category) or {}
    if #list == 0 then notify("No Coal items for " .. tostring(category)) return end
    local idx = (State.tackIndex[category] or 1) + delta
    if idx < 1 then idx = #list end
    if idx > #list then idx = 1 end
    State.tackIndex[category] = idx
    local item = list[idx]
    if item.shopItemHash == false or item.none then
        State.tackColors[category] = nil
        print(("[CoalDebug] Cleared tack category=%s index=%s/%s"):format(tostring(category), tostring(idx), tostring(#list)))
    else
        State.tackColors[category] = item
        local assetCount = (type(item.assets) == "table" and #item.assets) or 0
        print(("[CoalDebug] Selected tack category=%s label=%s index=%s/%s assets=%s drawable=%s shopHash=%s"):format(
            tostring(category),
            tostring(item.label or item.name or item.rawName or "unknown"),
            tostring(idx),
            tostring(#list),
            tostring(assetCount),
            tostring(item.drawable),
            tostring(item.shopItemHash)
        ))
    end
    notify((item.label or category) .. " [" .. idx .. "/" .. #list .. "]")
    applyAllToPed(previewHorse)
end

local function setPage(page)
    UI.page = page
    UI.index = 1
    if renderFeatherMenu and UI.open then renderFeatherMenu() end
end

local function closeMenu()
    UI.open = false
    UI.page = "main"
    UI.index = 1
    UI.category = nil
    UI.categoryLabel = nil
    setFeatherKeepInput(false)
    if CoalFeatherMenu then CoalFeatherMenu:Close({}) end
    deletePreview()
end

local function cleanLabel(v)
    v = tostring(v or "")
    v = v:gsub("^[Hh][Oo][Rr][Ss][Ee]_[Ee][Qq][Uu][Ii][Pp][Mm][Ee][Nn][Tt]_", "")
    v = v:gsub("_", " ")
    return v
end

local function itemName(item, fallback)
    if type(item) == "table" then return cleanLabel(item.label or item.name or item.id or fallback) end
    return cleanLabel(fallback or item)
end

local function horseCategories()
    return {
        { label = "Coat", action = "horse", category = "coat" },
        { label = "Palette", action = "horse", category = "palette" },
        { label = "Tint 0", action = "horse", category = "tint0" },
        { label = "Tint 1", action = "horse", category = "tint1" },
        { label = "Tint 2", action = "horse", category = "tint2" },
        { label = "Physique", action = "horse", category = "normal" },
        { label = "Shine", action = "horse", category = "material" },
        { label = "Scale", action = "horse", category = "scale" },
        { label = "Mane Style", action = "hair", category = "manes" },
        { label = "Tail Style", action = "hair", category = "tails" },
        { label = "Mane Palette", action = "hair", category = "mane_palette" },
        { label = "Tail Palette", action = "hair", category = "tail_palette" },
        { label = "Mane Tint 0", action = "hair", category = "mane_tint0" },
        { label = "Mane Tint 1", action = "hair", category = "mane_tint1" },
        { label = "Mane Tint 2", action = "hair", category = "mane_tint2" },
        { label = "Tail Tint 0", action = "hair", category = "tail_tint0" },
        { label = "Tail Tint 1", action = "hair", category = "tail_tint1" },
        { label = "Tail Tint 2", action = "hair", category = "tail_tint2" },
    }
end

local function tackCategories()
    return {
        { label = "Harness", action = "tack", category = "harness" },
        { label = "Halters / Bridles", action = "tack", category = "bridles" },
        { label = "Blankets", action = "tack", category = "blankets" },
        { label = "Saddles", action = "tack", category = "saddles" },
        { label = "Saddle Bags", action = "tack", category = "saddlebags" },
        { label = "Stirrups", action = "tack", category = "stirrups" },
        { label = "Bedrolls", action = "tack", category = "bedrolls" },
        { label = "Holsters", action = "tack", category = "holsters" },
        { label = "Horns", action = "tack", category = "horns" },
        { label = "Blanket Tint 0", action = "tack", category = "blanket_tint0" },
        { label = "Blanket Tint 1", action = "tack", category = "blanket_tint1" },
        { label = "Blanket Tint 2", action = "tack", category = "blanket_tint2" },
        { label = "Saddle Tint 0", action = "tack", category = "saddle_tint0" },
        { label = "Saddle Tint 1", action = "tack", category = "saddle_tint1" },
        { label = "Saddle Tint 2", action = "tack", category = "saddle_tint2" },
    }
end

local function currentHorseLabel(cat)
    local c = cat.category
    if c == "coat" then local n = CoatNums[State.horseIndex.coat or 1] or CoatNums[1] or 845 return ("Coal Coat %03d"):format(n) end
    if c == "palette" or c == "mane_palette" or c == "tail_palette" then return "Palette " .. tostring(State.horseIndex[c] or 1) end
    if c == "normal" then local nums = {1,2,4}; return "Physique " .. tostring(nums[State.horseIndex.normal or 1] or 1) end
    if c == "material" then return "Shine " .. tostring(State.horseIndex.material or 1) end
    if c == "scale" then return ("Scale %.2f"):format(State.appearance.scale or 1.0) end
    if c:find("tint") then return tostring((State.horseIndex[c] or 1) + 1) end
    if c == "manes" or c == "tails" then
        local list = CoalBuildAHorse and CoalBuildAHorse.GetItemsForCategory and CoalBuildAHorse.GetItemsForCategory(c) or {}
        return itemName(list[State.horseIndex[c] or 1], "Default")
    end
    return "Open"
end

local function currentTackLabel(cat)
    local list = CoalTack and CoalTack.GetItemsForCategory and CoalTack.GetItemsForCategory(cat.category) or {}
    local idx = State.tackIndex[cat.category] or 1
    return itemName(list[idx], "None")
end

local function openCategory(cat)
    UI.category = cat.category
    UI.categoryLabel = cat.label
    UI.page = cat.action == "tack" and "tack_items" or "horse_items"
    UI.index = (cat.action == "tack" and (State.tackIndex[cat.category] or 1)) or (State.horseIndex[cat.category] or 1)
end

local function horseChoiceItems(category)
    local items = {}
    if category == "coat" then
        for i, num in ipairs(CoatNums) do items[#items+1] = { label = ("Coal Coat %03d"):format(num), action = "horseExact", category = category, index = i } end
    elseif category == "palette" or category == "mane_palette" or category == "tail_palette" then
        for i, pal in ipairs(Palettes) do items[#items+1] = { label = "Palette " .. tostring(i) .. " - " .. cleanLabel(pal), action = ((category:find("mane") or category:find("tail")) and "hairExact" or "horseExact"), category = category, index = i } end
    elseif category == "normal" then
        local nums = {1, 2, 4}
        for i, num in ipairs(nums) do items[#items+1] = { label = "Physique " .. tostring(num), action = "horseExact", category = category, index = i } end
    elseif category == "material" then
        for i=1,5 do items[#items+1] = { label = "Shine " .. tostring(i), action = "horseExact", category = category, index = i } end
    elseif category == "scale" then
        for i=1,81 do items[#items+1] = { label = ("Scale %.2f"):format(0.70 + ((i - 1) * 0.01)), action = "horseExact", category = category, index = i } end
    elseif category == "manes" or category == "tails" then
        local list = CoalBuildAHorse and CoalBuildAHorse.GetItemsForCategory and CoalBuildAHorse.GetItemsForCategory(category) or {}
        for i, it in ipairs(list) do items[#items+1] = { label = itemName(it, category), action = "hairExact", category = category, index = i } end
    elseif category and category:find("tint") then
        local act = (category:find("mane") or category:find("tail")) and "hairExact" or "horseExact"
        for i=1,253 do items[#items+1] = { label = "Tint " .. tostring(i + 1), action = act, category = category, index = i } end
    end
    items[#items+1] = { label = "Back", action = "page", page = "horse" }
    return items
end

local function tackChoiceItems(category)
    local items = {}
    local list = CoalTack and CoalTack.GetItemsForCategory and CoalTack.GetItemsForCategory(category) or {}
    for i, it in ipairs(list) do
        local label = itemName(it, category)
        items[#items+1] = { label = label, action = "tackExact", category = category, index = i, item = it }
    end
    items[#items+1] = { label = "Back", action = "page", page = "tack" }
    return items
end

local function pageTitle()
    if UI.page == "horses" then return "Select Horse" end
    if UI.page == "horse" then return "Horse Coat & Colors" end
    if UI.page == "gender" then return "Horse Gender" end
    if UI.page == "horse_items" then return UI.categoryLabel or "Horse Options" end
    if UI.page == "tack" then return "Horse Tack" end
    if UI.page == "tack_items" then return UI.categoryLabel or "Tack Options" end
    return "Coal Stables"
end

local function pageItems()
    if UI.page == "horses" then
        local items = {}
        for _, h in ipairs(UI.horses or {}) do
            local label = (h.name or "Horse") .. " | " .. (h.model or "")
            if tonumber(h.selected or 0) == 1 then label = label .. " | MAIN" end
            items[#items + 1] = { label = label, action = "selectHorse", horse = h }
        end
        items[#items + 1] = { label = "Back", action = "page", page = "main" }
        return items
    elseif UI.page == "main" then
        return {
            { label = "Select Horse", action = "page", page = "horses", desc = "Choose the horse to preview/edit." },
            { label = "Horse Coat & Colors", action = "page", page = "horse", desc = "Coat, mane, tail, tints, and size." },
            { label = "Horse Gender", action = "page", page = "gender", desc = "Set this horse as a mare or stallion for breeding." },
            { label = "Horse Tack", action = "page", page = "tack", desc = "Saddles, blankets, bedrolls, bags, and accessories." },
            { label = "Save Coal Tack & Colors", action = "save", desc = "Save current Coal tack and color changes." },
            { label = "Close Menu", action = "close", desc = "Exit Coal Stables." },
        }
    elseif UI.page == "gender" then
        local current = tostring(State.gender or "male"):lower()
        local currentLabel = (current == "female" or current == "mare") and "Mare" or "Stallion"
        return {
            { label = "Current: " .. currentLabel, action = "noop" },
            { label = "Set As Mare", action = "setGender", gender = "female" },
            { label = "Set As Stallion", action = "setGender", gender = "male" },
            { label = "Back", action = "page", page = "main" },
        }
    elseif UI.page == "horse" then
        local items = {}
        for _, cat in ipairs(horseCategories()) do
            items[#items+1] = { label = cat.label .. "  >  " .. currentHorseLabel(cat), action = "openCategory", category = cat.category, categoryLabel = cat.label, categoryAction = cat.action }
        end
        items[#items+1] = { label = "Reset Coat Preview", action = "horse", category = "reset" }
        items[#items+1] = { label = "Save Coal Tack & Colors", action = "save" }
        items[#items+1] = { label = "Back", action = "page", page = "main" }
        return items
    elseif UI.page == "horse_items" then
        return horseChoiceItems(UI.category)
    elseif UI.page == "tack" then
        local items = {}
        for _, cat in ipairs(tackCategories()) do
            items[#items+1] = { label = cat.label .. "  >  " .. currentTackLabel(cat), action = "openCategory", category = cat.category, categoryLabel = cat.label, categoryAction = "tack" }
        end
        items[#items+1] = { label = "Save Coal Tack & Colors", action = "save" }
        items[#items+1] = { label = "Back", action = "page", page = "main" }
        return items
    elseif UI.page == "tack_items" then
        return tackChoiceItems(UI.category)
    end
    return {}
end

local function activate(item, dir)
    if not item then return end
    if item.action == "page" then
        if item.page == "horses" then UI.horses = Core.Callback.TriggerAwait("coal_bcc:GetHorses") or {} end
        setPage(item.page)
    elseif item.action == "openCategory" then
        openCategory({ category = item.category, label = item.categoryLabel, action = item.categoryAction })
    elseif item.action == "selectHorse" then
        loadHorseForEdit(item.horse)
        setPage("main")
    elseif item.action == "horseExact" then
        local cur = State.horseIndex[item.category] or 1
        changeHorse(item.category, (tonumber(item.index) or cur) - cur)
        UI.index = tonumber(item.index) or UI.index
    elseif item.action == "hairExact" then
        local cur = State.horseIndex[item.category] or 1
        changeHair(item.category, (tonumber(item.index) or cur) - cur)
        UI.index = tonumber(item.index) or UI.index
    elseif item.action == "tackExact" then
        local idx = tonumber(item.index) or 1
        State.tackIndex[item.category] = idx - 1
        changeTack(item.category, 1)
        UI.index = idx
    elseif item.action == "horse" then
        if item.category == "reset" then changeHorse("reset", 0) else changeHorse(item.category, dir or 1) end
    elseif item.action == "tack" then
        changeTack(item.category, dir or 1)
    elseif item.action == "hair" then
        changeHair(item.category, dir or 1)
    elseif item.action == "setGender" then
        if not State.horseId then
            notify("Select a horse first.")
            return
        end
        State.gender = item.gender == "female" and "female" or "male"
        TriggerServerEvent("coal_bcc:SetHorseGender", State.horseId, State.gender)
        local label = State.gender == "female" and "Mare" or "Stallion"
        notify("Horse gender set to " .. label .. ".")
        setPage("main")
    elseif item.action == "noop" then
        return
    elseif item.action == "save" then
        saveHorse()
    elseif item.action == "close" then
        closeMenu()
    end
end


local function ensureCoalFeatherMenu()
    if CoalFeatherMenu then return end

    -- Same plain Feather Menu setup style used by mms-oilpumps.
    -- No custom ugly drawn rectangles here; let Feather's default theme handle the look.
    CoalFeatherMenu = FeatherMenu:RegisterMenu('CoalStablesFeather', {
        top = '40%',
        left = '20%',
        ['720width'] = '500px',
        ['1080width'] = '600px',
        ['2kwidth'] = '700px',
        ['4kwidth'] = '900px',
        style = {},
        contentslot = {
            style = {
                ['height'] = '350px',
                ['min-height'] = '250px'
            }
        },
        draggable = true,
    }, {
        closed = function()
            setFeatherKeepInput(false)
            if UI.open then
                UI.open = false
                UI.page = 'main'
                UI.index = 1
                UI.category = nil
                UI.categoryLabel = nil
                deletePreview()
            end
        end
    })
end

local function registerCoalButton(page, item, displayLabel)
    page:RegisterElement('button', {
        label = cleanLabel(displayLabel or item.label),
        style = {},
    }, function()
        local action = item and item.action or nil
        activate(item, 1)

        -- Do not rebuild the item page for preview-only clicks. Rebuilding Feather pages
        -- resets the scroll position to the top, which was especially painful on long tint lists.
        local previewOnly = (action == 'horseExact' or action == 'hairExact' or action == 'tackExact')
        local noRefresh = (action == 'save' or action == 'close')
        if UI.open and not previewOnly and not noRefresh then
            renderFeatherMenu()
        end
    end)
end

renderFeatherMenu = function()
    if not UI.open then return end
    ensureCoalFeatherMenu()

    local items = pageItems()
    CoalFeatherPageCounter = CoalFeatherPageCounter + 1
    local page = CoalFeatherMenu:RegisterPage('coal_stables_page_' .. tostring(CoalFeatherPageCounter))

    page:RegisterElement('header', {
        value = pageTitle(),
        slot = 'header',
        style = {}
    })
    page:RegisterElement('line', {
        slot = 'header',
        style = {}
    })

    if UI.page == 'main' then
        page:RegisterElement('textdisplay', {
            value = State.horseName and ('Editing: ' .. tostring(State.horseName) .. ' | Gender: ' .. ((tostring(State.gender or 'male'):lower() == 'female') and 'Mare' or 'Stallion')) or 'Select a BCC horse first, then edit coat, tack, or gender.',
            style = {}
        })
    elseif UI.page == 'horse_items' or UI.page == 'tack_items' then
        page:RegisterElement('textdisplay', {
            value = 'Click an item to preview it. Use Back to return to categories.',
            style = {}
        })
    elseif UI.page == 'horse' or UI.page == 'tack' then
        page:RegisterElement('textdisplay', {
            value = 'Pick a category, then pick the exact item/variant inside it.',
            style = {}
        })
    end

    -- Add simple Feather-style arrow controls on item pages so it still feels like Coal browsing.
    if UI.page == 'horse_items' or UI.page == 'tack_items' then
        page:RegisterElement('button', { label = '← Previous', style = {} }, function()
            local list = pageItems()
            if #list > 1 then
                UI.index = UI.index - 1
                if UI.index < 1 then UI.index = #list - 1 end
                activate(list[UI.index], -1)
            end
            renderFeatherMenu()
        end)
        page:RegisterElement('button', { label = 'Next →', style = {} }, function()
            local list = pageItems()
            if #list > 1 then
                UI.index = UI.index + 1
                if UI.index >= #list then UI.index = 1 end
                activate(list[UI.index], 1)
            end
            renderFeatherMenu()
        end)
        page:RegisterElement('line', { style = {} })
    end

    for i, item in ipairs(items) do
        local label = item.label
        if i == UI.index and (UI.page == 'horse_items' or UI.page == 'tack_items') then
            label = '» ' .. tostring(label)
        end
        registerCoalButton(page, item, label)
    end

    page:RegisterElement('line', {
        slot = 'footer',
        style = {}
    })
    page:RegisterElement('subheader', {
        value = 'Coal Stables',
        slot = 'footer',
        style = {}
    })

    CoalFeatherMenu:Open({ startupPage = page })
    setFeatherKeepInput(true)
end

local function drawText(text, x, y, scale, r, g, b, a)
    SetTextScale(scale, scale)
    SetTextColor(r, g, b, a)
    SetTextCentre(false)
    DisplayText(CreateVarString(10, "LITERAL_STRING", text), x, y)
end

local function drawMenu()
    local items = pageItems()
    if #items == 0 then return end
    if UI.index < 1 then UI.index = #items end
    if UI.index > #items then UI.index = 1 end

    local baseX, baseY, width, lineH = 0.045, 0.105, 0.335, 0.034
    local visible = 14
    local top = 1
    if #items > visible then
        top = UI.index - math.floor(visible / 2)
        if top < 1 then top = 1 end
        if top > (#items - visible + 1) then top = #items - visible + 1 end
    end
    local bottom = math.min(#items, top + visible - 1)
    local rows = bottom - top + 1
    local panelH = rows * lineH + 0.115
    local cx = baseX + width / 2

    -- bcc-inspired western panel: dark leather body, warm brass border, oxblood selection.
    DrawRect(cx, baseY + panelH / 2 - 0.012, width + 0.018, panelH + 0.018, 86, 44, 25, 205)
    DrawRect(cx, baseY + panelH / 2 - 0.012, width + 0.012, panelH + 0.012, 18, 13, 10, 232)
    DrawRect(cx, baseY + 0.018, width + 0.012, 0.052, 56, 28, 18, 238)
    DrawRect(cx, baseY + 0.048, width + 0.012, 0.006, 174, 122, 58, 190)

    drawText(pageTitle(), baseX + 0.014, baseY - 0.002, 0.43, 238, 203, 132, 255)
    drawText("Coal Stables", baseX + 0.014, baseY + 0.028, 0.27, 206, 181, 135, 235)

    local listY = baseY + 0.072
    for i = top, bottom do
        local item = items[i]
        local row = i - top
        local y = listY + row * lineH
        local selected = (i == UI.index)
        if selected then
            DrawRect(cx, y + 0.014, width - 0.018, lineH - 0.004, 105, 24, 22, 220)
            DrawRect(cx, y + 0.014, width - 0.011, lineH + 0.002, 188, 127, 58, 105)
        else
            DrawRect(cx, y + 0.014, width - 0.024, lineH - 0.008, 8, 7, 6, 145)
        end
        local prefix = selected and "» " or "  "
        drawText(prefix .. cleanLabel(item.label), baseX + 0.018, y + 0.001, 0.315, selected and 255 or 222, selected and 228 or 207, selected and 176 or 170, 255)
    end

    if #items > visible then
        local trackX = baseX + width + 0.003
        local trackH = visible * lineH
        local thumbH = math.max(0.025, trackH * (visible / #items))
        local t = (top - 1) / math.max(1, (#items - visible))
        DrawRect(trackX, listY + trackH / 2, 0.006, trackH, 42, 31, 23, 210)
        DrawRect(trackX, listY + thumbH / 2 + (trackH - thumbH) * t, 0.006, thumbH, 189, 135, 67, 235)
    end

    local hint = "↑/↓ Browse  |  Enter Open/Preview  |  Back Return"
    if UI.page == "horse_items" or UI.page == "tack_items" then hint = "↑/↓ Browse Items  |  Enter Preview  |  Back Categories" end
    drawText(hint, baseX + 0.014, baseY + panelH - 0.032, 0.255, 225, 211, 180, 230)
end

local function drawText3D(x, y, z, text)
    local onScreen, sx, sy = GetScreenCoordFromWorldCoord(x, y, z)
    if not onScreen then return end
    SetTextScale(0.35, 0.35)
    SetTextColor(255, 255, 255, 230)
    SetTextCentre(true)
    DisplayText(CreateVarString(10, "LITERAL_STRING", text), sx, sy)
end

local function openMenu(stable)
    UI.stable = stable
    UI.open = true
    UI.page = "main"
    UI.index = 1
    UI.horses = Core.Callback.TriggerAwait("coal_bcc:GetHorses") or {}
    if #UI.horses == 0 then
        notify("No BCC horses found. Buy a horse in BCC Stables first.")
        renderFeatherMenu()
    else
        UI.page = "horses"
        renderFeatherMenu()
    end
end

CreateThread(function()
    while true do
        Wait(2500)

        -- Safe auto apply:
        -- scan peds, but ONLY apply when BCC put Entity(ped).state.myHorseId on it.
        -- NPC horses/birds do not have this BCC horse id, so they are ignored.
        local handle, ped = FindFirstPed()
        local success = true

        repeat
            if ped and ped ~= 0 and DoesEntityExist(ped) and not IsPedAPlayer(ped) then
                local horseId = tonumber(Entity(ped).state.myHorseId)
                if horseId then
                    local saved = SavedCache[horseId]
                    if not saved then
                        local db = Core.Callback.TriggerAwait("coal_bcc:GetAppearance", horseId)
                        if db then
                            saved = { appearance = decodeJson(db.appearance), tackColors = decodeJson(db.tackColors) }
                            SavedCache[horseId] = saved
                        end
                    end

                    if saved and (ped ~= lastAppliedRealHorse or horseId ~= lastAppliedRealHorseId) then
                        applyAllToPed(ped, saved.appearance, saved.tackColors)
                        lastAppliedRealHorse = ped
                        lastAppliedRealHorseId = horseId
                    end
                end
            end

            success, ped = FindNextPed(handle)
        until not success

        EndFindPed(handle)
    end
end)

CreateThread(function()
    Wait(2000)
    for _, stable in ipairs(Config.Stables or {}) do
        local c = getStableCoords(stable)
        if c and stable.showBlip ~= false then
            local blip = Citizen.InvokeNative(0x554D9D53F696D002, 1664425300, c.x, c.y, c.z)
            if blip and blip ~= 0 then
                SetBlipSprite(blip, stable.blipSprite or 1210165179, true)
                SetBlipScale(blip, stable.blipScale or 0.6)
                Citizen.InvokeNative(0x9CB1A1623062F402, blip, CreateVarString(10, "LITERAL_STRING", stable.name or "Coal Horse Editor"))
            end
        end
    end
    print("[coal_bcc] Loaded " .. tostring(#(Config.Stables or {})) .. " Coal BCC editor locations.")
    while true do
        local sleep = 700
        local pcoords = GetEntityCoords(PlayerPedId())
        if UI.open then
            -- Feather Menu stays visible, but player movement/look controls remain available for Coal's walk-around preview.
            setFeatherKeepInput(true)
            sleep = 250
        else
            for _, stable in ipairs(Config.Stables or {}) do
                local c = getStableCoords(stable)
                if c then
                    local dist = #(pcoords - c)
                    if dist < 5.0 then
                        sleep = 0
                        drawText3D(c.x, c.y, c.z + 1.0, "[G] Coal BCC Horse Editor")
                        if dist < 2.5 and IsControlJustPressed(0, keys.g) then openMenu(stable) Wait(500) end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

AddEventHandler("onResourceStop", function(res)
    if res ~= GetCurrentResourceName() then return end
    closeMenu()
end)
