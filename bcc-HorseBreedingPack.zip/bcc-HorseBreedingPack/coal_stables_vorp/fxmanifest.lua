fx_version 'cerulean'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'
game 'rdr3'

author 'Edited By: ShAd0wSn1pER117'
description 'Coal Stables standalone BCC horse editor. BCC compatibility. Edited By: ShAd0wSn1pER117'
version '3.1.0-feather-menu'

shared_scripts {
    'coal_stables.lua',
    'coal_tackroom.lua',
}

client_scripts {
    'BuildAHorse.lua',
    'BuildATack.lua',
    'client.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

files {
    'data/bedrolls.json',
    'data/blankets.json',
    'data/cantles.json',
    'data/genitals.json',
    'data/harness.json',
    'data/holsters.json',
    'data/horns.json',
    'data/manes.json',
    'data/saddlebags.json',
    'data/saddles.json',
    'data/stirrups.json',
    'data/tails.json'
}

dependencies {
    'vorp_core',
    'oxmysql',
    'feather-menu'
}
