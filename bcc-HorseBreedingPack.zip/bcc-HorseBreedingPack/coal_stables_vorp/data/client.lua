local MenuData <const> = exports.vorp_menu:GetMenuData()
local __CoalUseVorpMenus = true
local __coalMenuLastInput = 0
local __coalMenuInputDelay = 180

local ClearPreviewHorse

RegisterNetEvent("coal_stables:receiveHorses", function(horses, ownedData)
    horses = horses or {}
    if __CoalUseVorpMenus and __CoalVorpMenuOnReceiveHorses then
        return __CoalVorpMenuOnReceiveHorses(horses, ownedData)
    end


    -- Normalize owned horses into a list for multi-horse support
    local ownedList = {}

    if type(ownedData) == "table" then
        -- Single horse: has id/name directly
        if ownedData.id and ownedData.name then
            table.insert(ownedList, ownedData)
        else
            -- Assume array
            for _, h in ipairs(ownedData) do
                if type(h) == "table" and h.id then
                    table.insert(ownedList, h)
                end
            end
        end
    end

    -- STORE MODE: show all buyable horses (no Select at the top)
    if stableMenuMode == "store" or stableMenuMode == nil then
        if #horses == 0 then
            print("[coal_stables] No horses available for sale.")
            return
        end

        stableMenuHorses = {}

        for _, h in ipairs(horses) do
            local entry = h
            entry.modelIndex = 1  -- start at first coat
            table.insert(stableMenuHorses, entry)
        end

        stableMenuSelected   = 1
        stableMenuOpen       = true
        stableMainMenuOpen   = false

        QueuePreviewHorse(stableMenuHorses[stableMenuSelected])
        print("[coal_stables] STORE menu opened with " .. #stableMenuHorses .. " entries.")
        return
    end

    -- STABLES MODE: show owned horses we can select (up to MAX_OWNED_HORSES)
    if stableMenuMode == "stables" then
        if #ownedList == 0 then
            TriggerEvent("vorp:TipBottom", "You don't own a horse yet.", 4000)
            stableMenuOpen     = false
            stableMainMenuOpen = false
            ClearPreviewHorse()
            return
        end

        stableMenuHorses = {}

        -- Pick main horse index, default to the first
        local mainIndex = 1
        for idx, h in ipairs(ownedList) do
            local isMain = (h.isMain == true)

            if isMain then
                mainIndex = idx
            end

            local entryName = h.name or ("Horse #" .. tostring(idx))
            if isMain then
                entryName = "★ " .. entryName
            else
                entryName = "  " .. entryName
            end

            table.insert(stableMenuHorses, {
                id        = "__owned_" .. tostring(h._slot or idx),
                name      = entryName,
                price     = 0,
                tierLabel = h.tierLabel or "Owned Mount",
                speed     = h.speed   or 1.0,
                health    = h.health  or 1.0,
                stamina   = h.stamina or 1.0,
                _ownedRaw = h,
                _slot     = h._slot or idx,
                _isMain   = isMain,
            })
        end

        local mainHorse = ownedList[mainIndex] or ownedList[1]

        -- Remember this so Tack & Services / Build-A-* can spawn a preview later
        currentOwnedHorseData = mainHorse

        -- Normalise the local _slot so appearance saves use this index
        if currentOwnedHorseData then
            currentOwnedHorseData._slot = mainIndex
        end

        -- Sync equipped tack from server data (for preview & spawn)
        equippedTack = {}
        if mainHorse and mainHorse.tack and type(mainHorse.tack) == "table" then
            for k, v in pairs(mainHorse.tack) do
                equippedTack[k] = v
            end
        end

        -- legacy one-channel -> three-channel migration for saddlebags
        if equippedTack["saddlebags_tint"]
           and not (equippedTack["saddlebags_tint0"]
                or  equippedTack["saddlebags_tint1"]
                or  equippedTack["saddlebags_tint2"]) then

            local legacy = equippedTack["saddlebags_tint"]
            equippedTack["saddlebags_tint0"] = legacy
            equippedTack["saddlebags_tint1"] = legacy
            equippedTack["saddlebags_tint2"] = legacy
        end

        -- Open the list, start on the main horse
        stableMenuSelected   = mainIndex
        stableMenuOpen       = true
        stableMainMenuOpen   = false

        QueuePreviewHorse(stableMenuHorses[stableMenuSelected])
        print("[coal_stables] STABLES menu opened with " .. tostring(#stableMenuHorses) .. " owned horses.")
        return
    end
end)


--=====================================================
local lastStableId = nil

--=====================================================================
--  Build-A-Horse: inject Stables Store horse list (keeps BuildAHorse.lua independent)
--=====================================================================
CreateThread(function()
    -- Wait until both config + Build-A-Horse module are present
    local waited = 0
    while (not CoalBuildAHorse or not CoalBuildAHorse.SetHorseModelItems or not CoalStables or not CoalStables.Config or not CoalStables.Config.Horses) do
        Wait(50)
        waited = waited + 50
        if waited > 10000 then break end
    end

    if CoalBuildAHorse and CoalBuildAHorse.SetHorseModelItems and CoalStables and CoalStables.Config and CoalStables.Config.Horses then
        local items = {}

        for _, h in ipairs(CoalStables.Config.Horses) do
            local models = h.models
            if not models then
                if type(h.model) == "table" then
                    models = h.model
                elseif type(h.model) == "string" then
                    models = { h.model }
                end
            end

            if (h.id ~= "Gang" and (h.name or "") ~= "Gang" and (h.tier or "") ~= "Gang_Tier") and type(models) == "table" and #models > 0 then
                items[#items+1] = {
                    id     = h.id,
                    label  = h.name or h.id or "Horse",
                    models = models,
                }
            end
        end

        CoalBuildAHorse.SetHorseModelItems(items)
    end
end)

stableMenuOpen = false
stableMenuHorses = {}
stableMenuSelected = 1 

-- New: top-level livery menu (Stables Store / Stables)
stableMainMenuOpen = false
stableMainMenuSelected = 1   -- 1 = Stables, 2 = Store
stableMenuMode = nil         -- "store" or "stables"
-- Coal Bruteforce lab state
local bruteforceMenuOpen = false
local bruteforceItems    = {}
local bruteforceIndex    = 1

-- Remember law/outlaw flags from when we opened the livery
local lastIsLaw = false
local lastIsOutlaw = false

-- Tack store state
local tackCategoryMenuOpen = false

local tackCategories       = CoalTack.GetCategories()
local tackCategoryIndex    = 1
----------------
    local saddleItems = CoalTack.GetItemsForCategory("saddles")
    print(("[CoalDebug] tack menu: %d saddle items available"):format(#saddleItems))
-----------------------
local saddlebags = CoalTack.GetItemsForCategory("saddlebags")
print(("[CoalDebug] tack menu: %d saddle bag items available"):format(#saddlebags))
-----------------------
local bedrolls = CoalTack.GetItemsForCategory("bedrolls")
print(("[CoalDebug] tack menu: %d bedrolls items available"):format(#bedrolls))


-- Single-screen tack UI:
-- remember which item index is selected for each category (saddles, blankets, etc.)
local tackItemIndexByCategory = {}
-- All bridle style categories share the same underlying slot,
-- so only one should be active at a time (like mane families).
local bridleStyleCategories = {
    bridle_style_001 = true,
    bridle_style_002 = true,
    bridle_style_003 = true,
    bridle_style_004 = true,
}

-- Build-A-Horse lab state
local buildAHorseMenuOpen        = false
local buildAHorseCategories      = {}  -- populated when Build-A-Horse menu opens
local buildAHorseCategoryIndex   = 1
local buildAHorseItemIndexByCat  = {}

-- we'll store the current lab selection here (doesn't touch saved data)
local buildAHorseSelection = {}
--
-- Build-A-Tack workshop state (mirrors Build-A-Horse structure)
local buildATackMenuOpen        = false
local buildATackCategories      = {}
local buildATackCategoryIndex   = 1
local buildATackItemIndexByCat  = {}

-- This is the blob we persist into beauty.buildATack so servers can reapply it later.
local buildATackState = {
    saddle   = {},
    stirrups = {},
    horn     = {},
    harness  = {},
    blanket  = {},
    bag      = {},
    holster  = {},
}

-- Map UI category ids to logical tack slots + which field they control
local buildATackCategorySlots = {
    Saddle_style     = { slot = "saddle",   field = "item" },
    Saddle_palette   = { slot = "saddle",   field = "palette" },
    Saddle_tint0     = { slot = "saddle",   field = "tint0" },
    Saddle_tint1     = { slot = "saddle",   field = "tint1" },
    Saddle_tint2     = { slot = "saddle",   field = "tint2" },

    Stirrups_style   = { slot = "stirrups", field = "item" },
    Stirrups_palette = { slot = "stirrups", field = "palette" },
    Stirrups_tint0   = { slot = "stirrups", field = "tint0" },
    Stirrups_tint1   = { slot = "stirrups", field = "tint1" },
    Stirrups_tint2   = { slot = "stirrups", field = "tint2" },

    Horn_style       = { slot = "horn",     field = "item" },
    Horn_palette     = { slot = "horn",     field = "palette" },
    Horn_tint0       = { slot = "horn",     field = "tint0" },
    Horn_tint1       = { slot = "horn",     field = "tint1" },
    Horn_tint2       = { slot = "horn",     field = "tint2" },

    Harness_style    = { slot = "harness",  field = "item" },
    Harness_palette  = { slot = "harness",  field = "palette" },
    Harness_tint0    = { slot = "harness",  field = "tint0" },
    Harness_tint1    = { slot = "harness",  field = "tint1" },
    Harness_tint2    = { slot = "harness",  field = "tint2" },

    Holster_style    = { slot = "holster",  field = "item" },
    Holster_palette  = { slot = "holster",  field = "palette" },
    Holster_tint0    = { slot = "holster",  field = "tint0" },
    Holster_tint1    = { slot = "holster",  field = "tint1" },
    Holster_tint2    = { slot = "holster",  field = "tint2" },

    Blanket_style    = { slot = "blanket",  field = "item" },
    Blanket_palette  = { slot = "blanket",  field = "palette" },
    Blanket_tint0    = { slot = "blanket",  field = "tint0" },
    Blanket_tint1    = { slot = "blanket",  field = "tint1" },
    Blanket_tint2    = { slot = "blanket",  field = "tint2" },

    Bag_style        = { slot = "bag",      field = "item" },
    Bag_palette      = { slot = "bag",      field = "palette" },
    Bag_tint0        = { slot = "bag",      field = "tint0" },
    Bag_tint1        = { slot = "bag",      field = "tint1" },
    Bag_tint2        = { slot = "bag",      field = "tint2" },
}

-- currently equipped tack per slot (purely client-side for now)
local equippedTack = {
   -- base tack slots
    saddles        = nil,
    blankets       = nil,
    stirrups       = nil,
    bedrolls       = nil,
    bridles        = nil,
    harness        = nil,
    saddlebags     = nil,
    holsters       = nil,
    horns          = nil,  -- NEW: horn mesh

    -- legacy single-slot tints (kept for old JSON; not really used anymore)
    saddle_tint    = nil,
    bridle_tint    = nil,
    stirrup_tint   = nil,
    horn_tint      = nil,

    -- per-channel saddlebag tints
    saddlebags_tint0 = nil,
    saddlebags_tint1 = nil,
    saddlebags_tint2 = nil,

    -- per-channel bedroll tints
    bedroll_tint0    = nil,
    bedroll_tint1    = nil,
    bedroll_tint2    = nil,

    -- per-channel holsters tints
    holsters_tint0   = nil,
    holsters_tint1   = nil,
    holsters_tint2   = nil,

    -- per-channel horn tints (NEW)
    horns_tint0      = nil,
    horns_tint1      = nil,
    horns_tint2      = nil,
}


-------------------
-- =========================================================
--  Offline saddle asset data (from data/saddles.json)
-- =========================================================

local SaddleAssetsByName = {}

local function LoadSaddleAssets()
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/saddles.json")
    if not raw or raw == "" then
        print("[coal_stables] data/saddles.json not found; saddle_tints will be disabled.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[coal_stables] ERROR decoding saddles.json for saddle_tints:", decoded)
        return
    end

    for _, rec in ipairs(decoded) do
        if rec.name and rec.assets and type(rec.assets) == "table" then
            SaddleAssetsByName[rec.name] = rec.assets
        end
    end

    print(("[coal_stables] Loaded %d saddle asset records for saddle_tints.")
        :format(#decoded))
end

LoadSaddleAssets()
-------------------
-- Offline saddlebag asset data (from data/saddlebags.json)
-------------------
local SaddlebagAssetsByName = {}

local function LoadSaddlebagAssets()
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/saddlebags.json")
    if not raw or raw == "" then
        print("[coal_stables] data/saddlebags.json not found; saddlebag tints disabled.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[coal_stables] ERROR decoding saddlebags.json:", decoded)
        return
    end

    for _, rec in ipairs(decoded) do
        if rec.name and rec.assets and type(rec.assets) == "table" then
            SaddlebagAssetsByName[rec.name] = rec.assets
        end
    end

    print(("[coal_stables] Loaded %d saddlebag asset records."):format(#decoded))
end

LoadSaddlebagAssets()
-------------------
-------------------
-- Offline bedroll asset data (from data/bedrolls.json)
-------------------
local BedrollAssetsByName = {}

local function LoadBedrollAssets()
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/bedrolls.json")
    if not raw or raw == "" then
        print("[coal_stables] data/bedrolls.json not found; bedroll tints disabled.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[coal_stables] ERROR decoding bedrolls.json:", decoded)
        return
    end

    for _, rec in ipairs(decoded) do
        if rec.name and rec.assets and type(rec.assets) == "table" then
            BedrollAssetsByName[rec.name] = rec.assets
        end
    end

    print(("[coal_stables] Loaded %d bedroll asset records."):format(#decoded))
end

LoadBedrollAssets()
------------------------
-------------------
-- Offline holsters asset data (from data/holsters.json)
-------------------
local holstersAssetsByName = {}

local function LoadholstersAssets()
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/holsters.json")
    if not raw or raw == "" then
        print("[coal_stables] data/holsters.json not found; holsters tints disabled.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[coal_stables] ERROR decoding holsters.json:", decoded)
        return
    end

    for _, rec in ipairs(decoded) do
        if rec.name and rec.assets and type(rec.assets) == "table" then
            holstersAssetsByName[rec.name] = rec.assets
        end
    end

    print(("[coal_stables] Loaded %d holsters asset records."):format(#decoded))
end

LoadholstersAssets()

------------------------
-------------------
-- Offline stirrup asset data (from data/stirrups.json)
-------------------
local StirrupsAssetsByName = {}

local function LoadStirrupsAssets()
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/stirrups.json")
    if not raw or raw == "" then
        print("[coal_stables] data/stirrups.json not found; stirrup tints disabled.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[coal_stables] ERROR decoding stirrups.json:", decoded)
        return
    end

    for _, rec in ipairs(decoded) do
        if rec.name and rec.assets and type(rec.assets) == "table" then
            StirrupsAssetsByName[rec.name] = rec.assets
        end
    end

    print(("[coal_stables] Loaded %d stirrup asset records."):format(#decoded))
end

LoadStirrupsAssets()
-------------------
-------------------
-- Offline horns asset data (from data/horns.json)
-------------------
local HornAssetsByName = {}

local function LoadHornAssets()
    local raw = LoadResourceFile(GetCurrentResourceName(), "data/horns.json")
    if not raw or raw == "" then
        print("[coal_stables] data/horns.json not found; horn tints disabled.")
        return
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print("[coal_stables] ERROR decoding horns.json:", decoded)
        return
    end

    for _, rec in ipairs(decoded) do
        if rec.name and rec.assets and type(rec.assets) == "table" then
            HornAssetsByName[rec.name] = rec.assets
        end
    end

    print(("[coal_stables] Loaded %d horn asset records."):format(#decoded))
end

LoadHornAssets()

-------------------
-- pending tack  (what we're editing in Tack & Services right now)
local pendingTack  = {}
-- snapshot of tack when we opened Tack & Services (for cancel)
local originalTack = {}

-- =========================
-- Beauty (manes / tails)
-- CoalBeauty is defined globally in Beauty_Menu.lua (loaded via fxmanifest)

-- Fallback stub so we can run without Beauty module.
if CoalBeauty == nil then
    CoalBeauty = {
        GetCategories = function()
            return {}
        end,
        GetItemsForCategory = function()
            return {}
        end,
    }
end

-- =========================

-- Beauty / grooming store state (manes & tails)
local beautyCategoryMenuOpen = false

-- Allow running without Beauty_Menu.lua: gracefully disable beauty if CoalBeauty is missing.
local hasBeautyModule = (type(CoalBeauty) == "table")
local beautyCategories    = {}
local beautyCategoryIndex = 1

if hasBeautyModule and CoalBeauty.GetCategories and CoalBeauty.GetItemsForCategory then
    beautyCategories = CoalBeauty.GetCategories() or {}
else
    hasBeautyModule = false
    beautyCategories = {}
    print("[coal_stables] Beauty module not detected; Beauty menu & manes/tails tints disabled.")
end

-- remember which style index is selected per beauty category
local beautyItemIndexByCategory = {}

-- currently equipped beauty per slot (purely client-side for now)
local equippedBeauty = {
    manes        = nil,
    tails        = nil,
    hoof_feather = nil,

    -- per-style mane tint slots
    mane_colors_natural    = nil,
    mane_colors_short      = nil,
    mane_colors_mohawk     = nil,
    mane_colors_medium     = nil,
    mane_colors_long       = nil,
    mane_colors_braid      = nil,
    mane_colors_dreadlocks = nil,

    -- per-style tail tint slots
    tail_colors_regular    = nil,
    tail_colors_short      = nil,
    tail_colors_long       = nil,
    tail_colors_braid      = nil,

    HorseBody    = nil,
    HorseHead    = nil,

}

--
-- Fixed order for applying beauty:
-- 1) Colors first (mane/tail tints and test variants)
-- 2) Styles last (mane/tail meshes)
local beautyApplyOrder = {
    -- colors first (manes)
    "mane_colors_natural",
    "mane_colors_short",
    "mane_colors_mohawk",
    "mane_colors_medium",
    "mane_colors_long",
    "mane_colors_braid",
    "mane_colors_dreadlocks",

    -- colors (tails)
    "tail_colors_regular",
    "tail_colors_short",
    "tail_colors_long", 
    "tail_colors_braid",

    "HorseBody",     -- coat (body + head together)
    "hoof_feather",  -- hoof feathering tint

    -- styles last
    "manes",
    "tails",
}

--
-- All mane-color categories share the same underlying slot, so only one
-- should ever be active at a time.
local maneColorCategories = {
    "mane_colors_natural",
    "mane_colors_short",
    "mane_colors_mohawk",
    "mane_colors_medium",
    "mane_colors_long",
    "mane_colors_braid",
    "mane_colors_dreadlocks",
}

-- All tail-color categories share the same underlying slot, so only one
-- should ever be active at a time.
local tailColorCategories = {
    "tail_colors_regular",
    "tail_colors_short",
    "tail_colors_long",  
    "tail_colors_braid",
}

--
-- pending beauty (what we're editing in Beauty Menu right now)
local pendingBeauty  = {}
-- snapshot of beauty when we opened Beauty Menu (for cancel)
local originalBeauty = {}

-- Stable preview anchor (set once per livery session)
local previewAnchorPos     = nil  -- vector3
local previewAnchorHeading = nil  -- number

local previewHorse = nil
local currentOwnedHorse = nil
local currentOwnedHorseData = nil
local RefreshPreviewHorseAppearance
local SpawnPreviewHorse
local ApplyHorseOutfit
local ApplyPendingTackToPreview

-- NEW: forward-declared so Beauty/Tack menus can call them
local ApplyAllEquippedTack
local ApplyAllEquippedBeauty
local ApplyPendingBeautyToPreview

local previewHorseSpawnedOnce = false
-- Mouse wheel rotation: we piggyback on sniper zoom controls
-- which are bound to Mouse Wheel Up / Down by default.
-- INPUT_SNIPER_ZOOM_IN_ONLY  = 0xA5BDCD3C (wheel up)
-- INPUT_SNIPER_ZOOM_OUT_ONLY = 0x430593AA (wheel down)
local rotateLeftKey  = 0xA5BDCD3C   -- wheel up
local rotateRightKey = 0x430593AA   -- wheel down

-- Rotation offset in degrees applied on top of the preview anchor heading
local previewRotationOffset = 0.0

-- NEW: track preview spawn requests so older ones can't overwrite newer ones
local previewSpawnToken = 0

-- NEW: async wrapper so heavy spawn work doesn't block the menu thread
function QueuePreviewHorse(entry)
    if not entry then return end

    -- remember last requested preview (useful for Build-A-Horse refresh / respawn)
    lastPreviewEntry = entry

    previewSpawnToken = previewSpawnToken + 1
    local myToken = previewSpawnToken
    local horseData = entry

    CreateThread(function()
        SpawnPreviewHorse(horseData, myToken)
    end)
end

-- Set/refresh the preview anchor in front of the player (once per livery session)
local function SetPreviewAnchorAtPlayer()
    local ped = PlayerPedId()
    local basePos = GetOffsetFromEntityInWorldCoords(ped, 0.75, 3.0, 0.0)

    local baseZ  = basePos.z
    local spawnZ = baseZ

    -- Reuse the same ground logic you already use for preview horses
    local foundGround, groundZ = GetGroundZAndNormalFor_3dCoord(basePos.x, basePos.y, baseZ + 2.0)
    if foundGround then
        if groundZ > baseZ - 0.3 then
            spawnZ = groundZ + 0.05
        else
            spawnZ = baseZ + 0.01
        end
    else
        spawnZ = baseZ + 0.01
    end

    previewAnchorPos = vector3(basePos.x, basePos.y, spawnZ)

    local heading = GetEntityHeading(ped) + 90.0
    if heading >= 360.0 then
        heading = heading - 360.0
    end
    previewAnchorHeading = heading
end
--
-- Hash for the built-in "Flee" / dismiss horse control (usually F when locked on)
local horseFleeControl = GetHashKey("INPUT_HORSE_COMMAND_FLEE")
-- Hash for the built-in whistle key
local whistleControl   = GetHashKey("INPUT_WHISTLE")
--
--
-- Coal Bruteforce: draw helper
local function DrawCoalBruteforceMenu()
    if not bruteforceItems or #bruteforceItems == 0 then
        SetTextScale(0.45, 0.45)
        SetTextFontForCurrentCommand(1)
        SetTextColor(255, 200, 200, 255)
        SetTextCentre(true)
        DisplayText(
            CreateVarString(10, "LITERAL_STRING", "No bruteforce items configured."),
            0.5,
            0.5
        )
        return
    end

    local item = bruteforceItems[bruteforceIndex]
    if not item then return end

    -- Control hint
    SetTextScale(0.30, 0.30)
    SetTextFontForCurrentCommand(1)
    SetTextColor(200, 200, 200, 200)
    SetTextCentre(true)
    DisplayText(
        CreateVarString(10, "LITERAL_STRING", "← / → change item  |  BACKSPACE return"),
        0.5,
        0.93
    )
end

-- Coal Bruteforce: open logic
function OpenCoalBruteforceMenu()
    -- Leave other livery menus
    stableMainMenuOpen     = false
    stableMenuOpen         = false
    tackCategoryMenuOpen   = false
    beautyCategoryMenuOpen = false

    -- Ensure we have a preview horse
    if not previewHorse or not DoesEntityExist(previewHorse) then
        if currentOwnedHorseData then
            local entry = {
                id        = "__owned__",
                name      = currentOwnedHorseData.name or "Your Horse",
                price     = 0,
                tierLabel = currentOwnedHorseData.tierLabel or "Owned Mount",
                speed     = currentOwnedHorseData.speed  or 1.0,
                health    = currentOwnedHorseData.health or 1.0,
                stamina   = currentOwnedHorseData.stamina or 1.0,
                _ownedRaw = currentOwnedHorseData,
            }
            QueuePreviewHorse(entry)
        else
            TriggerEvent("vorp:TipBottom", "You need a horse to preview gear.", 4000)
            return
        end
    end

    -- Pull items from coal_bruteforce.lua
    if not CoalBruteforce or not CoalBruteforce.GetItems then
        print("[coal_bruteforce] Missing CoalBruteforce.GetItems()")
        TriggerEvent("vorp:TipBottom", "Bruteforce config missing.", 4000)
        return
    end

    bruteforceItems = CoalBruteforce.GetItems() or {}
    if #bruteforceItems == 0 then
        TriggerEvent("vorp:TipBottom", "No bruteforce items configured.", 4000)
        return
    end

    bruteforceIndex    = 1
    bruteforceMenuOpen = true

    -- Apply the first item immediately
    local item = bruteforceItems[bruteforceIndex]
    if item and previewHorse and DoesEntityExist(previewHorse) then
        if item.itemHash then
            -- DB-driven items (numeric hash)
            ApplyTackItem(previewHorse, item.itemHash)
        elseif item.shopItemHash then
            -- Static items (string name)
            ApplyTackItem(previewHorse, item.shopItemHash)
        end
    end
end


-- Open the Tack & Services main (category) menu
local function OpenTackCategoryMenu()


    -- We’re leaving the Livery main menu and going into Tack UI
    stableMainMenuOpen = false
    stableMenuOpen     = false

    -- If we don't have a preview right now, try to spawn your owned horse preview.
    if not previewHorse or not DoesEntityExist(previewHorse) then
        if currentOwnedHorseData then
            local entry = {
                id        = "__owned__",
                name      = currentOwnedHorseData.name or "Your Horse",
                price     = 0,
                tierLabel = currentOwnedHorseData.tierLabel or "Owned Mount",
                speed     = currentOwnedHorseData.speed or 1.0,
                health    = currentOwnedHorseData.health or 1.0,
                stamina   = currentOwnedHorseData.stamina or 1.0,
                _ownedRaw = currentOwnedHorseData,
            }
            QueuePreviewHorse(entry)
        else
            TriggerEvent("vorp:TipBottom", "You need a horse to preview tack.", 4000)
            return
        end
    end

    tackCategories       = CoalTack.GetCategories()
    tackCategoryIndex    = 1

    -- Build pending + original snapshots from current equippedTack
    pendingTack  = {}
    originalTack = {}

    for _, cat in ipairs(tackCategories) do
        local catId = cat.id
        local items = CoalTack.GetItemsForCategory(catId)

        local equippedId  = equippedTack[catId]
        local chosenIndex = 1

        if equippedId then
            for i, item in ipairs(items) do
                if item.id == equippedId then
                    chosenIndex = i
                    break
                end
            end
        end

        if chosenIndex < 1 then chosenIndex = 1 end
        if chosenIndex > #items and #items > 0 then
            chosenIndex = 1
        end

        tackItemIndexByCategory[catId] = chosenIndex

        if #items > 0 then
            local chosenItem = items[chosenIndex]
            pendingTack[catId]  = chosenItem.id
            originalTack[catId] = chosenItem.id
        end
    end

    -- Apply the pending config to the preview horse
    if previewHorse and DoesEntityExist(previewHorse) then
        -- defined below
        ApplyPendingTackToPreview()
    end

    tackCategoryMenuOpen = true
end

-------------------------
-------------------------
-- Build-A-Horse Workshop
-------------------------
local function OpenBuildAHorseMenu()
    -- Leave other livery menus
    stableMainMenuOpen     = false
    stableMenuOpen         = false
    tackCategoryMenuOpen   = false
    beautyCategoryMenuOpen = false
    bruteforceMenuOpen     = false

    -- Ensure preview horse exists
    if not previewHorse or not DoesEntityExist(previewHorse) then
        if currentOwnedHorseData then
            local entry = {
                id        = "__owned__",
                name      = currentOwnedHorseData.name or "Your Horse",
                price     = 0,
                tierLabel = currentOwnedHorseData.tierLabel or "Owned Mount",
                speed     = currentOwnedHorseData.speed or 1.0,
                health    = currentOwnedHorseData.health or 1.0,
                stamina   = currentOwnedHorseData.stamina or 1.0,
                _ownedRaw = currentOwnedHorseData,
            }
            QueuePreviewHorse(entry)
        else
            TriggerEvent("vorp:TipBottom", "You need a horse to preview parts.", 4000)
            return
        end
    end

    -- Pull categories fresh from Build-A-Horse
    buildAHorseCategories     = CoalBuildAHorse.GetCategories()
    buildAHorseCategoryIndex  = 1
    buildAHorseItemIndexByCat = {}

    -- Seed indices to 0 ("None") so nothing is changed until the player flips an option
    for _, cat in ipairs(buildAHorseCategories) do
        buildAHorseItemIndexByCat[cat.id] = 0
    end

    -- If this horse already has a Build-A-Horse save, load it into our state + preview
    -- Prefer the new appearance.buildAHorse structure, but fall back to legacy beauty.buildAHorse.
    local existing = nil
    if currentOwnedHorseData then
        if currentOwnedHorseData.appearance and currentOwnedHorseData.appearance.buildAHorse then
            existing = currentOwnedHorseData.appearance.buildAHorse
        elseif currentOwnedHorseData.beauty and currentOwnedHorseData.beauty.buildAHorse then
            existing = currentOwnedHorseData.beauty.buildAHorse
        end
    end

    if existing then
        -- body
        if existing.body and type(existing.body) == "table" then
            for key, region in pairs(existing.body) do
                local target = buildAHorseBodyDebug[key]
                if target and type(region) == "table" then
                    target.drawable = region.drawable or target.drawable
                    target.albedo   = region.albedo   or target.albedo
                    target.normal   = region.normal   or target.normal
                    target.material = region.material or target.material
                    target.palette  = region.palette  or target.palette
                    target.tint0    = region.tint0    or target.tint0
                    target.tint1    = region.tint1    or target.tint1
                    target.tint2    = region.tint2    or target.tint2
                end
            end

            ApplyBodyRegionDebug("hand")
            ApplyBodyRegionDebug("head")
            ApplyBodyRegionDebug("mis2")
        end

        -- hair
        if existing.hair and type(existing.hair) == "table" then
            for _, kind in ipairs({ "mane", "tail" }) do
                local saved = existing.hair[kind]
                local state = buildAHorseHairState[kind]
                if saved and state then
                    state.item    = saved.item    or state.item
                    state.palette = saved.palette or state.palette
                    state.tint0   = saved.tint0   or state.tint0
                    state.tint1   = saved.tint1   or state.tint1
                    state.tint2   = saved.tint2   or state.tint2
                end
            end

            ApplyBuildAHorseHair("mane")
            ApplyBuildAHorseHair("tail")
        end

        -- scale
        if existing.scale then
            local scale = tonumber(existing.scale) or 1.0
            if scale < 0.70 then scale = 0.70 end
            if scale > 1.50 then scale = 1.50 end

            buildAHorseScale = scale
            Citizen.InvokeNative(0x25ACFC650B65C538, previewHorse, scale)
        end
    end

    buildAHorseMenuOpen = true
end
--
-------------------------
-- Build-A-Tack Workshop
-------------------------
function OpenBuildATackMenu()
    -- Leave other livery menus
    stableMainMenuOpen     = false
    stableMenuOpen         = false
    tackCategoryMenuOpen   = false
    beautyCategoryMenuOpen = false
    bruteforceMenuOpen     = false

    -- Ensure preview horse exists
    if not previewHorse or not DoesEntityExist(previewHorse) then
        if currentOwnedHorseData then
            local entry = {
                id        = "__owned__",
                name      = currentOwnedHorseData.name or "Your Horse",
                price     = 0,
                tierLabel = currentOwnedHorseData.tierLabel or "Owned Mount",
                speed     = currentOwnedHorseData.speed or 1.0,
                health    = currentOwnedHorseData.health or 1.0,
                stamina   = currentOwnedHorseData.stamina or 1.0,
                model     = currentOwnedHorseData.model,
                tack      = currentOwnedHorseData.tack,
                beauty    = currentOwnedHorseData.beauty,
            }
            QueuePreviewHorse(entry)
        else
            TriggerEvent("vorp:TipBottom", "You need a horse to preview tack.", 4000)
            return
        end
    end

    -- Pull categories fresh from Build-A-Tack
    buildATackCategories = (CoalBuildATack and CoalBuildATack.GetCategories())
        or buildATackCategories
        or {}

    -- Seed per-category indices
    buildATackItemIndexByCat = buildATackItemIndexByCat or {}
    if CoalBuildATack and CoalBuildATack.GetItemsForCategory then
        for _, cat in ipairs(buildATackCategories) do
            local items = CoalBuildATack.GetItemsForCategory(cat.id) or {}
            if (buildATackItemIndexByCat[cat.id] or 0) < 1 then
                buildATackItemIndexByCat[cat.id] = (#items > 0) and 1 or 0
            end
        end
    end

        -- Reset Build-A-Tack state for this horse, so old horses don't leak
    buildATackState = {
        saddle   = {},
        stirrups = {},
        horn     = {},
        harness  = {},
        blanket  = {},
        bag      = {},
        holster  = {},
    }

-- If this horse already has a Build-A-Tack save, load it into our state
    -- Prefer the new appearance.buildATack structure, but fall back to legacy beauty.buildATack.
    local existing = nil
    if currentOwnedHorseData then
        if currentOwnedHorseData.appearance and currentOwnedHorseData.appearance.buildATack then
            existing = currentOwnedHorseData.appearance.buildATack
        elseif currentOwnedHorseData.beauty and currentOwnedHorseData.beauty.buildATack then
            existing = currentOwnedHorseData.beauty.buildATack
        end
    end

    if existing and type(existing) == "table" then
        for key, slot in pairs(existing) do
            if buildATackState[key] and type(slot) == "table" then
                buildATackState[key] = slot
            end
        end
    end

    -- Apply current Build-A-Tack state to preview
    ApplyBuildATackAllSlots()

    buildATackMenuOpen      = true
    buildATackCategoryIndex = 1
end

--Beauty
-- Open the Beauty & Grooming (manes/tails) main (category) menu
local function OpenBeautyMenu()
    -- If Beauty_Menu.lua is not loaded, just inform the player and bail cleanly.
    if not hasBeautyModule or not CoalBeauty or not CoalBeauty.GetCategories or not CoalBeauty.GetItemsForCategory then
        TriggerEvent("vorp:TipBottom", "Beauty & Grooming is not available on this server.", 4000)
        return
    end

    -- Leave the Livery main menu and horse list
    stableMainMenuOpen = false
    stableMenuOpen     = false

    -- Ensure we have a preview horse
    if not previewHorse or not DoesEntityExist(previewHorse) then
        if currentOwnedHorseData then
            local entry = {
                id        = "__owned__",
                name      = currentOwnedHorseData.name or "Your Horse",
                price     = 0,
                tierLabel = currentOwnedHorseData.tierLabel or "Owned Mount",
                speed     = currentOwnedHorseData.speed or 1.0,
                health    = currentOwnedHorseData.health or 1.0,
                stamina   = currentOwnedHorseData.stamina or 1.0,
                _ownedRaw = currentOwnedHorseData,
            }
            QueuePreviewHorse(entry)
        else
            TriggerEvent("vorp:TipBottom", "You need a horse to preview beauty.", 4000)
            return
        end
    end

    beautyCategories    = CoalBeauty.GetCategories()
    beautyCategoryIndex = 1

    pendingBeauty  = {}
    originalBeauty = {}

    for _, cat in ipairs(beautyCategories) do
        local catId = cat.id
        local items = CoalBeauty.GetItemsForCategory(catId)

        local equippedId  = equippedBeauty[catId]
        local chosenIndex = 1
        local hasEquipped = false

        if equippedId then
            for i, item in ipairs(items) do
                if item.id == equippedId then
                    chosenIndex = i
                    hasEquipped = true
                    break
                end
            end
        end

        if chosenIndex < 1 then chosenIndex = 1 end
        if chosenIndex > #items and #items > 0 then
            chosenIndex = 1
        end

        -- Cursor can still default to 1 for navigation
        beautyItemIndexByCategory[catId] = chosenIndex

        -- Only seed pending/original if there was an equipped value
        if hasEquipped and #items > 0 then
            local chosenItem = items[chosenIndex]
            pendingBeauty[catId]  = chosenItem.id
            originalBeauty[catId] = chosenItem.id
        end
    end

    -- Ensure preview reflects current saved appearance (not pending changes)
    if previewHorse and DoesEntityExist(previewHorse) then
        RefreshPreviewHorseAppearance()  -- uses equipped tack + equipped beauty
    end

    beautyCategoryMenuOpen = true
end

-- Tack category list (Saddles / Blankets / Stirrups / ...) – single-screen UI
-- LEFT: categories
-- TOP-CENTER: current item for that category
local function DrawTackCategoryMenu()
    local listX     = 0.003
    local listY     = 0.003
    local lineStep  = 0.035
    local boxWidth  = 0.23
    local boxHeight = 0.026

    ---------------------------------------------------
    -- LEFT: CATEGORY LIST (show current item label)
    ---------------------------------------------------
    for i, cat in ipairs(tackCategories) do
        local isSelected = (i == tackCategoryIndex)
        local rowY       = listY + (i - 1) * lineStep
        local boxCenterX = listX + (boxWidth / 2.0)
        local boxCenterY = rowY + (boxHeight / 2.0)

        -- Determine which item is currently chosen for this category
        local items = CoalTack.GetItemsForCategory(cat.id)
        local idx   = tackItemIndexByCategory[cat.id] or 1
        if idx < 1 then idx = 1 end
        if idx > #items and #items > 0 then idx = #items end

        local rowLabel     = cat.label
        local useItemLabel = (cat.useItemLabel ~= false) -- default true

        if #items > 0 then
            local item = items[idx]
            if item and item.label then
                if useItemLabel then
                    rowLabel = item.label
                else
                    rowLabel = string.format("%s %s", cat.label, item.label)
                end
            end
        end

        if isSelected then
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 40, 40, 40, 200)
            DrawRect(boxCenterX, boxCenterY, boxWidth + 0.002, boxHeight + 0.002, 180, 30, 30, 90)
        else
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 0, 0, 0, 160)
        end

        SetTextScale(0.40, 0.40)
        SetTextFontForCurrentCommand(1)
        SetTextColor(isSelected and 255 or 220, isSelected and 255 or 220, 200, 255)
        SetTextCentre(false)
        rowLabel = tostring(rowLabel):gsub("^[Hh][Oo][Rr][Ss][Ee]_[Ee][Qq][Uu][Ii][Pp][Mm][Ee][Nn][Tt]_", "")
        DisplayText(
            CreateVarString(10, "LITERAL_STRING", rowLabel),
            listX + 0.01,
            rowY + 0.003
        )
    end
    local cat = tackCategories[tackCategoryIndex]
    if cat then
        local items = CoalTack.GetItemsForCategory(cat.id)
        if #items > 0 then
            local idx = tackItemIndexByCategory[cat.id] or 1
            if idx < 1 then idx = 1 end
            if idx > #items then idx = #items end
            tackItemIndexByCategory[cat.id] = idx

            local item = items[idx]

            local infoY = 0.05
            local titleLine = tostring(item.label or "Tack")

            SetTextScale(0.50, 0.50)
            SetTextFontForCurrentCommand(1)
            SetTextColor(255, 255, 200, 255)
            SetTextCentre(true)
            DisplayText(
                CreateVarString(10, "LITERAL_STRING", titleLine), 0.55, infoY
            )

            SetTextScale(0.35, 0.35)
            SetTextFontForCurrentCommand(1)
            SetTextColor(220, 220, 220, 255)
            SetTextCentre(true)
            DisplayText(
                CreateVarString(10, "LITERAL_STRING", item.desc or ""), 0.55, infoY + 0.03
            )
        end
    end

    ---------------------------------------------------
    -- FOOTER
    ---------------------------------------------------
    SetTextScale(0.34, 0.34)
    SetTextFontForCurrentCommand(1)
    SetTextColor(255, 255, 255, 255)
    SetTextCentre(true)
        DisplayText(
        CreateVarString(
            10,
            "LITERAL_STRING",
            "↑/↓ CATEGORY  |  ←/→ CHANGE ITEM  |  ENTER CONFIRM  |  BACKSPACE CANCEL"
        ),
        0.5,
        0.94
    )
end
--Drop this near DrawTackCategoryMenu() / DrawBeautyCategoryMenu():
local function DrawBuildAHorseMenu()
    local listX     = 0.003
    local listY     = 0.003
    local lineStep  = 0.035
    local boxWidth  = 0.23
    local boxHeight = 0.026

    -- LEFT: categories (show current item label)
    for i, cat in ipairs(buildAHorseCategories) do
        local isSelected = (i == buildAHorseCategoryIndex)
        local rowY       = listY + (i - 1) * lineStep
        local boxCenterX = listX + (boxWidth / 2.0)
        local boxCenterY = rowY + (boxHeight / 2.0)

        local items = CoalBuildAHorse.GetItemsForCategory(cat.id)
        local idx   = buildAHorseItemIndexByCat[cat.id] or 1
        if idx < 1 then idx = 1 end
        if idx > #items and #items > 0 then idx = #items end
        buildAHorseItemIndexByCat[cat.id] = idx

        local rowLabel     = cat.label
        local useItemLabel = (cat.useItemLabel ~= false) -- default true

        -- Special-case: Hair Palette should show as "Hair Palette P#", not "Coat Palette P#"
        if cat.id == "hair_palette" and #items > 0 and items[idx] then
            local paletteId = tostring(items[idx].id or items[idx].label or "")
            rowLabel = string.format("%s %s", cat.label, paletteId)
        elseif #items > 0 and items[idx] and items[idx].label then
            if useItemLabel then
                rowLabel = items[idx].label
            else
                rowLabel = string.format("%s %s", cat.label, items[idx].label)
            end
        end

        if isSelected then
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 40, 40, 40, 200)
            DrawRect(boxCenterX, boxCenterY, boxWidth + 0.002, boxHeight + 0.002, 180, 30, 30, 90)
        else
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 0, 0, 0, 160)
        end

        SetTextScale(0.40, 0.40)
        SetTextFontForCurrentCommand(1)
        SetTextColor(isSelected and 255 or 220, isSelected and 255 or 220, 200, 255)
        SetTextCentre(false)
        DisplayText(CreateVarString(10, "LITERAL_STRING", rowLabel), listX + 0.01, rowY + 0.003)
    end

    -- footer
    SetTextScale(0.34, 0.34)
    SetTextFontForCurrentCommand(1)
    SetTextColor(255, 255, 255, 255)
    SetTextCentre(true)
    DisplayText(
        CreateVarString(
            10,
            "LITERAL_STRING",
            "↑/↓ CATEGORY  |  ←/→ CHANGE  |  ENTER SAVE & RETURN  |  BACKSPACE RETURN"
        ),
        0.5,
        0.94
    )
end


local function DrawBuildATackMenu()
    local listX     = 0.003
    local listY     = 0.003
    local lineStep  = 0.035
    local boxWidth  = 0.23
    local boxHeight = 0.026

    if not buildATackCategories or #buildATackCategories == 0 then
        return
    end

    local total        = #buildATackCategories
    local visibleCount = 16

    -- Figure out which slice of categories should be visible so that the
    -- selected row stays inside a scrolling window.
    local topIndex, bottomIndex
    if total <= visibleCount then
        topIndex   = 1
        bottomIndex = total
    else
        local half = math.floor(visibleCount / 2)
        topIndex   = buildATackCategoryIndex - half
        if topIndex < 1 then
            topIndex = 1
        end
        bottomIndex = topIndex + visibleCount - 1
        if bottomIndex > total then
            bottomIndex = total
            topIndex    = total - visibleCount + 1
        end
    end

    -- Fancy backdrop panel for the visible window
    local visibleRows  = (bottomIndex - topIndex + 1)
    local panelHeight  = visibleRows * lineStep + 0.01
    local panelCenterX = listX + (boxWidth / 2.0)
    local panelCenterY = listY + (panelHeight / 2.0) - (lineStep / 2.0)

    -- Outer soft border
    DrawRect(panelCenterX, panelCenterY, boxWidth + 0.018, panelHeight + 0.016, 180, 30, 30, 90)
    -- Inner dark glass
    DrawRect(panelCenterX, panelCenterY, boxWidth + 0.016, panelHeight + 0.012, 0, 0, 0, 180)

    -- LEFT: categories (show current item label)
    for i = topIndex, bottomIndex do
        local cat = buildATackCategories[i]
        if cat then
            local isSelected = (i == buildATackCategoryIndex)
            local rowIndex   = (i - topIndex)
            local rowY       = listY + rowIndex * lineStep

            -- background
            local boxCenterX = listX + (boxWidth / 2.0)
            local boxCenterY = rowY + (boxHeight / 2.0)

            if isSelected then
                -- subtle double-layer highlight
                DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 40, 40, 40, 210)
                DrawRect(boxCenterX, boxCenterY, boxWidth + 0.004, boxHeight + 0.004, 220, 160, 80, 120)
            else
                DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 0, 0, 0, 160)
            end

            -- Determine row label based on selected item
            local label = cat.label or cat.id or "Category"
            local items = {}
            if CoalBuildATack and CoalBuildATack.GetItemsForCategory then
                items = CoalBuildATack.GetItemsForCategory(cat.id) or {}
            end

            local idx = buildATackItemIndexByCat[cat.id] or 1
            if idx < 1 then idx = 1 end
            if idx > #items and #items > 0 then idx = #items end
            buildATackItemIndexByCat[cat.id] = idx

            local rowLabel     = label
            local useItemLabel = (cat.useItemLabel ~= false)

            if #items > 0 and items[idx] and items[idx].label then
                if useItemLabel then
                    rowLabel = items[idx].label
                else
                    rowLabel = string.format("%s %s", label, items[idx].label)
                end
            end

            SetTextScale(0.40, 0.40)
            SetTextFontForCurrentCommand(1)
            if isSelected then
                SetTextColor(255, 255, 200, 255)
            else
                SetTextColor(220, 220, 220, 255)
            end
            SetTextCentre(false)
            DisplayText(
                CreateVarString(10, "LITERAL_STRING", rowLabel),
                listX + 0.01,
                rowY + 0.003
            )
        end
    end

    -- Scroll bar on the right if there are more rows than we can show
    if total > visibleCount then
        local trackWidth  = 0.006
        local trackX      = listX + boxWidth + 0.012
        local trackY      = listY
        local trackHeight = visibleCount * lineStep

        local trackCenterX = trackX + (trackWidth / 2.0)
        local trackCenterY = trackY + (trackHeight / 2.0)

        -- Track background + border
        DrawRect(trackCenterX, trackCenterY, trackWidth + 0.004, trackHeight + 0.004, 0, 0, 0, 190)
        DrawRect(trackCenterX, trackCenterY, trackWidth, trackHeight, 180, 30, 30, 110)

        local thumbHeight = math.max(0.02, trackHeight * (visibleCount / total))
        local maxOffset   = total - visibleCount
        local t           = 0.0
        if maxOffset > 0 then
            t = (topIndex - 1) / maxOffset
        end

        local thumbTravel  = trackHeight - thumbHeight
        local thumbCenterY = trackY + (thumbHeight / 2.0) + (thumbTravel * t)

        -- Thumb: bright core with softer edge
        DrawRect(trackCenterX, thumbCenterY, trackWidth, thumbHeight, 230, 230, 230, 230)
        DrawRect(trackCenterX, thumbCenterY, trackWidth - 0.002, thumbHeight - 0.004, 255, 200, 120, 255)
    end

    -- footer
    SetTextScale(0.34, 0.34)
    SetTextFontForCurrentCommand(1)
    SetTextColor(255, 255, 255, 255)
    SetTextCentre(true)
    DisplayText(
        CreateVarString(
            10,
            "LITERAL_STRING",
            "↑/↓ CATEGORY  |  ←/→ CHANGE  |  ENTER SAVE & RETURN  |  BACKSPACE RETURN"
        ),
        0.5,
        0.94
    )
end


--Beauty
-- Beauty category list (Manes / Tails) – single-screen UI
-- LEFT: categories
-- TOP-CENTER: current style for that category
local function DrawBeautyCategoryMenu()
    local listX     = 0.003
    local listY     = 0.003
    local lineStep  = 0.035
    local boxWidth  = 0.23
    local boxHeight = 0.026

    -- LEFT: CATEGORY LIST (show current item label)
    for i, cat in ipairs(beautyCategories) do
        local isSelected = (i == beautyCategoryIndex)
        local rowY       = listY + (i - 1) * lineStep
        local boxCenterX = listX + (boxWidth / 2.0)
        local boxCenterY = rowY + (boxHeight / 2.0)

        local items = CoalBeauty.GetItemsForCategory(cat.id)
        local idx   = beautyItemIndexByCategory[cat.id] or 1
        if idx < 1 then idx = 1 end
        if idx > #items and #items > 0 then idx = #items end

    -- Show the *category* label in the left list, not the current tint label
        local rowLabel     = cat.label
        local useItemLabel = (cat.useItemLabel ~= false) -- default true if not set

        if #items > 0 then
            local item = items[idx]
            if item and item.label then
                if useItemLabel then
                    -- Old behavior: row shows just the item label
                    rowLabel = item.label
                else
                    -- New behavior: show category + current tint
                    -- e.g. "(Regular) Tint 46 (P1 - Natural)"
                    rowLabel = string.format("%s %s", cat.label, item.label)
                end
            end
        end

        if isSelected then
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 40, 40, 40, 200)
            DrawRect(boxCenterX, boxCenterY, boxWidth + 0.002, boxHeight + 0.002, 180, 30, 30, 90)
        else
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 0, 0, 0, 160)
        end

        SetTextScale(0.40, 0.40)
        SetTextFontForCurrentCommand(1)
        SetTextColor(isSelected and 255 or 220, isSelected and 255 or 220, 200, 255)
        SetTextCentre(false)
        DisplayText(
            CreateVarString(10, "LITERAL_STRING", rowLabel),
            listX + 0.01,
            rowY + 0.003
        )
    end

    -- FOOTER
    SetTextScale(0.34, 0.34)
    SetTextFontForCurrentCommand(1)
    SetTextColor(255, 255, 255, 255)
    SetTextCentre(true)
    DisplayText(
        CreateVarString(
            10,
            "LITERAL_STRING",
            "↑/↓ CATEGORY  |  ←/→ CHANGE STYLE  |  ENTER CONFIRM  |  BACKSPACE CANCEL"
        ),
        0.5,
        0.94
    )
end
--
-- Apply a single tack shop item to a horse (saddle / blanket / etc.)
function ApplyTackItem(ped, shopItem)
    if not ped or ped == 0 or not shopItem then return end

    local itemHash = shopItem

    if type(shopItem) == "string" then
        if shopItem:sub(1, 2) == "0x" or shopItem:sub(1, 2) == "0X" then
            itemHash = tonumber(shopItem)
        else
            itemHash = GetHashKey(shopItem)
        end
    end

    if not itemHash then return end

    Citizen.InvokeNative(0xD3A7B003ED343FD9, ped, itemHash, false, false, false)
    Citizen.InvokeNative(0xCC8CA3E88256E58F, ped, 0, 1, 1, 1, false)
end

-- MetaPed tint helpers (used for mane/tail color)
local function SetMetaPedTag(ped, drawable, albedo, normal, material, palette, tint0, tint1, tint2)
    if not ped or ped == 0 then return end
    if not drawable or not albedo or not normal or not material or not palette then return end

    local drawableHash = type(drawable) == "string" and GetHashKey(drawable) or drawable
    local albedoHash   = type(albedo)   == "string" and GetHashKey(albedo)   or albedo
    local normalHash   = type(normal)   == "string" and GetHashKey(normal)   or normal
    local materialHash = type(material) == "string" and GetHashKey(material) or material
    local paletteHash  = type(palette)  == "string" and GetHashKey(palette)  or palette

    Citizen.InvokeNative(
        0xBC6DF00D7A4A6819,   -- _SET_META_PED_TAG
        ped,
        drawableHash,
        albedoHash,
        normalHash,
        materialHash,
        paletteHash,
        tint0 or 0,
        tint1 or 0,
        tint2 or 0
    )
end

local function UpdatePedVariationTint(ped)
    if not ped or ped == 0 then return end
    Citizen.InvokeNative(0xAAB86462966168CE, ped, true)           -- _UPDATE_PED_VARIATION
    Citizen.InvokeNative(0xCC8CA3E88256E58F, ped, false, true, true, true, false)

-- =========================================================
-- Build-A-Bruteforce → hook into preview horse + MetaPed tags
-- =========================================================
if CoalBuildABruteforce then
    -- Override the placeholder ApplyToPreviewHorse from BuildABruteforce.lua
    -- so it uses the same MetaPed pipeline as the rest of the stables system.
    function CoalBuildABruteforce.ApplyToPreviewHorse(drawableName, albedoName, normalName, materialName)
        -- We only ever want to operate on the current preview horse inside Stables.
        if not previewHorse or not DoesEntityExist(previewHorse) then
            return
        end

        -- For saddlebag brute forcing, these all share the leather palette.
        -- If you discover a more accurate palette from your offline JSON,
        -- swap "metaped_tint_leather" out for that.
        local palette = "metaped_tint_leather"

        -- Use a neutral tint vector so we only see the raw texture differences.
        local t0, t1, t2 = 138, 138, 138

        SetMetaPedTag(
            previewHorse,
            drawableName,
            albedoName,
            normalName,
            materialName,
            palette,
            t0, t1, t2
        )
        UpdatePedVariationTint(previewHorse)
    end
end

end

--
-- =========================================================
-- Build-A-Horse: apply saved state (from beauty.buildAHorse) to a horse ped
-- =========================================================
CoalBuildAHorse = CoalBuildAHorse or {}

function CoalBuildAHorse.ApplySavedToPed(ped, saved)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return end
    if not saved or type(saved) ~= "table" then return end

    ------------------------------------------------
    -- Body (hand / head / barrel)
    ------------------------------------------------
    local body = saved.body
    if body and type(body) == "table" then
        local function applyRegion(key, region)
            if not region then return end

            local baseName = key
            local drawable = region.drawable or string.format("p_c_horse_01_%s_000", baseName)
            local albedo   = region.albedo   or string.format("p_c_horse_01_%s_000_c0_845_ab", baseName)
            local normal   = region.normal   or string.format("p_c_horse_01_%s_000_c0_001_nm", baseName)
            local material = region.material or string.format("p_c_horse_01_%s_000_c0_001_m" , baseName)
            local palette  = region.palette  or "metaped_tint_horse"

            SetMetaPedTag(
                ped,
                drawable,
                albedo,
                normal,
                material,
                palette,
                region.tint0 or 138,
                region.tint1 or 138,
                region.tint2 or 138
            )
        end

        applyRegion("hand", body.hand)
        applyRegion("head", body.head)
        applyRegion("mis2",  body.mis2)
    end

    ------------------------------------------------
    -- Manes / tails (styles + tints)
    ------------------------------------------------
    local hair = saved.hair
    if hair and type(hair) == "table" then
        local function applyHair(kind)
            local state = hair[kind]
            if not state or type(state) ~= "table" or not state.item then return end

            local a = state.item.assets and state.item.assets[1]
            if not a or not a.drawable or not a.albedo or not a.normal or not a.material then
                return
            end

            local palette = state.palette or a.palette or "metaped_tint_horse"

            SetMetaPedTag(
                ped,
                a.drawable,
                a.albedo,
                a.normal,
                a.material,
                palette,
                state.tint0 or a.tint0 or 0,
                state.tint1 or a.tint1 or 0,
                state.tint2 or a.tint2 or 0
            )
        end

        applyHair("mane")
        applyHair("tail")
    end
    ------------------------------------------------
    -- Hoof feathers (tint-based accessory, optional)
    ------------------------------------------------
    do
        local hf = saved.hoof_feather
        if hf and type(hf) == "table" and hf.id ~= nil then
            local items = CoalBuildAHorse.GetItemsForCategory and CoalBuildAHorse.GetItemsForCategory("hoof_feather") or {}
            for _, it in ipairs(items) do
                if it.id == hf.id then
                    local v = tonumber(it.value or it.id or it.tint0) or 0
                    if v ~= 0 then
                        if v < 2 then v = 2 end
                        if v > 255 then v = 255 end -- dev clamp
                    end
                    local palette = (buildAHorseBodyDebug and buildAHorseBodyDebug.hand and buildAHorseBodyDebug.hand.palette)
                        or "metaped_tint_horse"
                    if it.drawable and it.albedo and it.normal and it.material then
                        SetMetaPedTag(
                            ped,
                            it.drawable,
                            it.albedo,
                            it.normal,
                            it.material,
                            palette,
                            v, v, v
                        )
                    end
                    break
                end
            end
        end
    end


    ------------------------------------------------
    -- Scale (optional – only if you decide to store it)
    ------------------------------------------------
    if saved.scale and type(saved.scale) == "number" then
        -- _SET_PED_SCALE
        Citizen.InvokeNative(0x25ACFC650B65C538, ped, saved.scale)
    end

    UpdatePedVariationTint(ped)
end

--
-- =========================================================
-- Build-A-Horse body state (hand / head / mis2 share palette & tints)
-- =========================================================

buildAHorseBodyDebug = {
    hand = {
        drawable = "p_c_horse_01_hand_000",
        albedo   = nil,
        normal   = nil,
        material = nil,
        palette  = "metaped_tint_horse",
        tint0    = 138,
        tint1    = 138,
        tint2    = 138,
    },
    head = {
        drawable = "p_c_horse_01_head_000",
        albedo   = nil,
        normal   = nil,
        material = nil,
        palette  = "metaped_tint_horse",
        tint0    = 138,
        tint1    = 138,
        tint2    = 138,
    },
    mis2 = {
        drawable = "p_c_horse_01_mis2_000",
        albedo   = nil,
        normal   = nil,
        material = nil,
        palette  = "metaped_tint_horse",
        tint0    = 138,
        tint1    = 138,
        tint2    = 138,
    },
}

--
-- =========================================================
-- Build-A-Horse hair state (manes / tails have their own tints)
-- =========================================================
buildAHorseHairState = {
    mane = {
        item    = nil,                 -- last selected mane style item
        palette = "metaped_tint_horse",-- default hair palette
        tint0   = 138,
        tint1   = 138,
        tint2   = 138,
    },
    tail = {
        item    = nil,                 -- last selected tail style item
        palette = "metaped_tint_horse",-- default hair palette
        tint0   = 138,
        tint1   = 138,
        tint2   = 138,
    },
}

function ApplyBuildAHorseHair(kind) -- kind = "mane" | "tail"
    if not previewHorse or not DoesEntityExist(previewHorse) then return end

    local state = buildAHorseHairState[kind]
    if not state or not state.item then return end

    local a = state.item.assets and state.item.assets[1]
    if not a or not a.drawable or not a.albedo or not a.normal or not a.material or not a.palette then
        return
    end

    -- Palette: state override -> asset palette -> horse default
    local palette = state.palette or a.palette or "metaped_tint_horse"

    SetMetaPedTag(
        previewHorse,
        a.drawable,
        a.albedo,
        a.normal,
        a.material,
        palette,
        state.tint0 or a.tint0 or 0,
        state.tint1 or a.tint1 or 0,
        state.tint2 or a.tint2 or 0
    )

    UpdatePedVariationTint(previewHorse)
end

--

function ApplyBodyRegionDebug(regionKey)
    local region = buildAHorseBodyDebug[regionKey]
    if not region then return end
    if not previewHorse or not DoesEntityExist(previewHorse) then return end

    local baseName = regionKey  -- "hand" / "head" / "mis2"

    local drawable = region.drawable or string.format("p_c_horse_01_%s_000", baseName)
    local albedo   = region.albedo   or string.format("p_c_horse_01_%s_000_c0_845_ab", baseName)
    local normal   = region.normal   or string.format("p_c_horse_01_%s_000_c0_001_nm", baseName)
    local material = region.material or string.format("p_c_horse_01_%s_000_c0_001_m" , baseName)
    local palette  = region.palette  or "metaped_tint_horse"

    SetMetaPedTag(
        previewHorse,
        drawable,
        albedo,
        normal,
        material,
        palette,
        region.tint0 or 138,
        region.tint1 or 138,
        region.tint2 or 138
    )
    UpdatePedVariationTint(previewHorse)
end

-- Helper: apply same body texture number to all 3 regions
local function ApplySharedBodyChannel(kind, num)
    -- kind = "ab" | "nm" | "m"
    num = tonumber(num) or 1
    local suffix = (kind == "nm" and "nm") or (kind == "m" and "m") or "ab"

    local function setRegion(regionKey)
        local prefix  = "p_c_horse_01_" .. regionKey
        local texName = string.format("%s_000_C0_%03d_%s", prefix, num, suffix)
        local region  = buildAHorseBodyDebug[regionKey]
        if not region then return end

        if kind == "ab" then
            region.albedo = texName
        elseif kind == "nm" then
            region.normal = texName
        else
            region.material = texName
        end
    end

    setRegion("hand")
    setRegion("head")
    setRegion("mis2")

    ApplyBodyRegionDebug("hand")
    ApplyBodyRegionDebug("head")
    ApplyBodyRegionDebug("mis2")
end


-- Helper: apply same tint channel to all 3 regions
local function ApplySharedTint(channelIndex, value)
    local v = tonumber(value) or 138
    if v < 2   then v = 2   end
    if v > 255 then v = 255 end  -- dev clamp

    for _, regionKey in ipairs({ "hand", "head", "mis2" }) do
        local region = buildAHorseBodyDebug[regionKey]
        if channelIndex == 0 then
            region.tint0 = v
        elseif channelIndex == 1 then
            region.tint1 = v
        else
            region.tint2 = v
        end
    end

    ApplyBodyRegionDebug("hand")
    ApplyBodyRegionDebug("head")
    ApplyBodyRegionDebug("mis2")
end
    ------------------------------------------------

-- Helper: when you pick a body tint in any row, keep all 3 rows in sync
local function SyncBodyTintMenuIndices(channelIndex, chosenItem)
    if not chosenItem then return end

    local tintCats
    if channelIndex == 0 then
        tintCats = { "body_hand_tint0", "body_head_tint0", "body_mis2_tint0" }
    elseif channelIndex == 1 then
        tintCats = { "body_hand_tint1", "body_head_tint1", "body_mis2_tint1" }
    else
        tintCats = { "body_hand_tint2", "body_head_tint2", "body_mis2_tint2" }
    end

    -- All three categories share the same 2–254 tint list,
    -- so we can find the index once and copy it to all of them.
    local baseCat = tintCats[1]
    local items   = CoalBuildAHorse.GetItemsForCategory(baseCat)
    local idx     = 1

    for i, it in ipairs(items) do
        if it.id == chosenItem.id or it.value == chosenItem.value then
            idx = i
            break
        end
    end

    for _, catId in ipairs(tintCats) do
        buildAHorseItemIndexByCat[catId] = idx
    end
end

-- =========================================================
-- Build-A-Horse: apply one JSON/menu item to the preview horse
-- =========================================================
-- Re-apply the current Build-A-Horse workshop state onto the current preview horse.
-- Useful after respawning the preview (e.g. to "remove" hoof feathers cleanly).
local function ReapplyBuildAHorseWorkshopStateToPreview()
    if not previewHorse or not DoesEntityExist(previewHorse) then return end

    -- body regions
    if buildAHorseBodyDebug then
        ApplyBodyRegionDebug("hand")
        ApplyBodyRegionDebug("head")
        ApplyBodyRegionDebug("mis2")
    end

    -- hair (mane + tail)
    if buildAHorseHairState then
        ApplyBuildAHorseHair("mane")
        ApplyBuildAHorseHair("tail")
    end

    -- scale
    if buildAHorseScale then
        Citizen.InvokeNative(0x25ACFC650B65C538, previewHorse, buildAHorseScale)
    end

    -- hoof feather tint (only if not "none")
    local hfId = buildAHorseSelection and buildAHorseSelection["hoof_feather"] or nil
    if hfId and tonumber(hfId) and tonumber(hfId) > 0 then
        local items = CoalBuildAHorse.GetItemsForCategory("hoof_feather")
        for _, it in ipairs(items) do
            if it.id == hfId then
                local v = tonumber(it.value or it.id or it.tint0) or 0
                if v < 2 then v = 2 end
                if v > 255 then v = 255 end -- dev clamp

                local palette = (buildAHorseBodyDebug and buildAHorseBodyDebug.hand and buildAHorseBodyDebug.hand.palette)
                    or "metaped_tint_horse"

                if it.drawable and it.albedo and it.normal and it.material then
                    SetMetaPedTag(previewHorse, it.drawable, it.albedo, it.normal, it.material, palette, v, v, v)
                    UpdatePedVariationTint(previewHorse)
                end
                break
            end
        end
    end
end
--

-- Map UI category ids to logical tack slots + which field they control
local buildATackCategorySlots = {
    Saddle_style     = { slot = "saddle",   field = "item" },
    Saddle_palette   = { slot = "saddle",   field = "palette" },
    Saddle_tint0     = { slot = "saddle",   field = "tint0" },
    Saddle_tint1     = { slot = "saddle",   field = "tint1" },
    Saddle_tint2     = { slot = "saddle",   field = "tint2" },

    Stirrups_style   = { slot = "stirrups", field = "item" },
    Stirrups_palette = { slot = "stirrups", field = "palette" },
    Stirrups_tint0   = { slot = "stirrups", field = "tint0" },
    Stirrups_tint1   = { slot = "stirrups", field = "tint1" },
    Stirrups_tint2   = { slot = "stirrups", field = "tint2" },

    Horn_style       = { slot = "horn",     field = "item" },
    Horn_palette     = { slot = "horn",     field = "palette" },
    Horn_tint0       = { slot = "horn",     field = "tint0" },
    Horn_tint1       = { slot = "horn",     field = "tint1" },
    Horn_tint2       = { slot = "horn",     field = "tint2" },

    Harness_style    = { slot = "harness",  field = "item" },
    Harness_palette  = { slot = "harness",  field = "palette" },
    Harness_tint0    = { slot = "harness",  field = "tint0" },
    Harness_tint1    = { slot = "harness",  field = "tint1" },
    Harness_tint2    = { slot = "harness",  field = "tint2" },

    Holster_style    = { slot = "holster",  field = "item" },
    Holster_palette  = { slot = "holster",  field = "palette" },
    Holster_tint0    = { slot = "holster",  field = "tint0" },
    Holster_tint1    = { slot = "holster",  field = "tint1" },
    Holster_tint2    = { slot = "holster",  field = "tint2" },

    Blanket_style    = { slot = "blanket",  field = "item" },
    Blanket_palette  = { slot = "blanket",  field = "palette" },
    Blanket_tint0    = { slot = "blanket",  field = "tint0" },
    Blanket_tint1    = { slot = "blanket",  field = "tint1" },
    Blanket_tint2    = { slot = "blanket",  field = "tint2" },

    Bag_style        = { slot = "bag",      field = "item" },
    Bag_palette      = { slot = "bag",      field = "palette" },
    Bag_tint0        = { slot = "bag",      field = "tint0" },
    Bag_tint1        = { slot = "bag",      field = "tint1" },
    Bag_tint2        = { slot = "bag",      field = "tint2" },
}

--
local function RespawnPreviewHorseAndReapplyBuildAHorse()
    if not lastPreviewEntry then return end
    QueuePreviewHorse(lastPreviewEntry)

    CreateThread(function()
        local token = previewSpawnToken
        local tries = 0
        while tries < 200 do
            Wait(25)
            tries = tries + 1
            if previewSpawnToken ~= token then return end -- newer spawn request took over
            if previewHorse and DoesEntityExist(previewHorse) then
                ReapplyBuildAHorseWorkshopStateToPreview()
                return
            end
        end
    end)
end

function ApplyBuildAHorseItemToPreview(catId, item)
    if not previewHorse or not DoesEntityExist(previewHorse) then return end
    if not catId or not item then return end

    -- keep live selection snapshot
    buildAHorseSelection[catId] = item.id

------------------------------------------------
-- 0) Horse selector (preview only)
------------------------------------------------
if catId == "horse_model" then
    if item.models and type(item.models) == "table" and #item.models > 0 then
        -- Swap the preview horse base model to a *clean* store horse.
        -- We intentionally do NOT re-apply any Build-A-Horse overlays here
        -- so you can see the vanilla store coats/tints.
        local entry = {
            id         = "__build_store__",
            name       = item.label or "Horse",
            price      = 0,
            tierLabel  = "Preview",
            speed      = 1.0,
            health     = 1.0,
            stamina    = 1.0,
            models     = item.models,
            modelIndex = 1,
        }
        QueuePreviewHorse(entry)
    end
    -- Build-A-Horse body / hair / scale will only be applied when you
    -- change the other Build-A-Horse rows (coat, palette, hair, etc.),
    -- keeping this Store selector as a true "vanilla" preview.
    return
end


    ------------------------------------------------
    ------------------------------------------------
    -- 1) Shared body tint palette (new)
    ------------------------------------------------
    if catId == "body_palette" then
        local palette = item.palette or "metaped_tint_horse"

        for _, regionKey in ipairs({ "hand", "head", "mis2" }) do
            local region = buildAHorseBodyDebug[regionKey]
            region.palette = palette
        end

        ApplyBodyRegionDebug("hand")
        ApplyBodyRegionDebug("head")
        ApplyBodyRegionDebug("mis2")
        return
    end

    ------------------------------------------------
    -- 1b) Shared HAIR tint palette (manes + tails)
    ------------------------------------------------
    if catId == "hair_palette" then
        local palette = item.palette or "metaped_tint_horse"

        -- Update both hair states
        if buildAHorseHairState.mane then
            buildAHorseHairState.mane.palette = palette
            ApplyBuildAHorseHair("mane")
        end
        if buildAHorseHairState.tail then
            buildAHorseHairState.tail.palette = palette
            ApplyBuildAHorseHair("tail")
        end

        return
    end

    ------------------------------------------------
    -- 1c) Horse scale (0.90–1.25)
    ------------------------------------------------
    if catId == "horse_scale" then
        local scale = tonumber(item.scale or item.value or 1.0) or 1.0

        -- safety clamp
        if scale < 0.70 then scale = 0.70 end
        if scale > 1.50 then scale = 1.50 end

        -- RDR2 native: _SET_PED_SCALE
        buildAHorseScale = scale

        Citizen.InvokeNative(0x25ACFC650B65C538, previewHorse, scale)

        return
    end

    ------------------------------------------------
    -- 1c) Hoof feathers – tint-based accessory
    ------------------------------------------------
    if catId == "hoof_feather" then

-- 0 = none (clear hoof feathers). We respawn the preview to guarantee the tag is removed.
if item.none or tonumber(item.value or item.id) == 0 then
    buildAHorseSelection[catId] = 0
    RespawnPreviewHorseAndReapplyBuildAHorse()
    return
end

        -- Hoof feather tint uses the SAME palette as the body/coat tint palette
        -- and a single numeric tint value (2–254) for all 3 channels.
        local v = tonumber(item.value or item.id or item.tint0) or 0
        if v ~= 0 then
            if v < 2 then v = 2 end
            if v > 255 then v = 255 end -- dev clamp
        end

        local palette = (buildAHorseBodyDebug and buildAHorseBodyDebug.hand and buildAHorseBodyDebug.hand.palette)
            or "metaped_tint_horse"

        if item.drawable and item.albedo and item.normal and item.material then
            SetMetaPedTag(
                previewHorse,
                item.drawable,
                item.albedo,
                item.normal,
                item.material,
                palette,
                v, v, v
            )
            UpdatePedVariationTint(previewHorse)
        end
        return
    end

    --
    ------------------------------------------------
    -- 2) Body mesh (drawable) selectors
    ------------------------------------------------
    if catId == "body_hand_drawable"
    or catId == "body_head_drawable"
    or catId == "body_mis2_drawable" then

        local regionKey
        if catId == "body_hand_drawable" then
            regionKey = "hand"
        elseif catId == "body_head_drawable" then
            regionKey = "head"
        else
            regionKey = "mis2"
        end

        local region = buildAHorseBodyDebug[regionKey]
        if not region then return end

        if item.drawableIdx ~= nil then
            local baseName = regionKey
            region.drawable = string.format("p_c_horse_01_%s_%03d", baseName, item.drawableIdx)
        else
            region.drawable = item.drawableName or item.textureName or item.id
        end

        ApplyBodyRegionDebug(regionKey)
        return
    end

    ------------------------------------------------
    -- 3) Body albedo / normal / material (all regions synced)
    ------------------------------------------------
    if catId == "body_hand_ab" or catId == "body_head_ab" or catId == "body_mis2_ab" then
        ApplySharedBodyChannel("ab", item.num or item.cVar or 845)
        return
    end

    if catId == "body_hand_nm" or catId == "body_head_nm" or catId == "body_mis2_nm" then
        ApplySharedBodyChannel("nm", item.num or item.cVar or 1)
        return
    end

    if catId == "body_hand_m" or catId == "body_head_m" or catId == "body_mis2_m" then
        ApplySharedBodyChannel("m", item.num or item.cVar or 1)
        return
    end

    ------------------------------------------------
    -- 4) Body tints (tint0/1/2 – synced across regions)
    ------------------------------------------------
    if catId == "body_hand_tint0" or catId == "body_head_tint0" or catId == "body_mis2_tint0" then
        ApplySharedTint(0, item.value or item.id)
        SyncBodyTintMenuIndices(0, item)
        return
    end

    if catId == "body_hand_tint1" or catId == "body_head_tint1" or catId == "body_mis2_tint1" then
        ApplySharedTint(1, item.value or item.id)
        SyncBodyTintMenuIndices(1, item)
        return
    end

    if catId == "body_hand_tint2" or catId == "body_head_tint2" or catId == "body_mis2_tint2" then
        ApplySharedTint(2, item.value or item.id)
        SyncBodyTintMenuIndices(2, item)
        return
    end

    ------------------------------------------------
    -- 5) Coat families (body presets)
    ------------------------------------------------
    if catId == "horse_body_presets" then
        if item.assets and type(item.assets) == "table" then
            for _, a in ipairs(item.assets) do
                if a.drawable and a.albedo and a.normal and a.material and a.palette then
                    SetMetaPedTag(
                        previewHorse,
                        a.drawable,
                        a.albedo,
                        a.normal,
                        a.material,
                        a.palette,
                        a.tint0 or 0,
                        a.tint1 or 0,
                        a.tint2 or 0
                    )
                end
            end
            UpdatePedVariationTint(previewHorse)
        end
        return
    end

    ------------------------------------------------
    -- 6) Head presets (future-ready)
    ------------------------------------------------
    if catId == "horse_head_presets" then
        if item.assets and type(item.assets) == "table" then
            for _, a in ipairs(item.assets) do
                if a.drawable and a.albedo and a.normal and a.material and a.palette then
                    SetMetaPedTag(
                        previewHorse,
                        a.drawable,
                        a.albedo,
                        a.normal,
                        a.material,
                        a.palette,
                        a.tint0 or 0,
                        a.tint1 or 0,
                        a.tint2 or 0
                    )
                end
            end
            UpdatePedVariationTint(previewHorse)
        end
        return
    end

    ------------------------------------------------
    ------------------------------------------------
    -- 7) Manes / tails (styles) – remember item, use tint state
    ------------------------------------------------
    if catId == "manes" or catId == "tails" then
        local key = (catId == "manes") and "mane" or "tail"
        if buildAHorseHairState[key] then
            buildAHorseHairState[key].item = item
        end
        ApplyBuildAHorseHair(key)
        return
    end


    ------------------------------------------------
    -- 8) Mane / tail tint vectors (2–254)
    ------------------------------------------------
    if catId == "mane_tint0" then
        buildAHorseHairState.mane.tint0 = item.value or item.id
        ApplyBuildAHorseHair("mane")
        return
    end

    if catId == "mane_tint1" then
        buildAHorseHairState.mane.tint1 = item.value or item.id
        ApplyBuildAHorseHair("mane")
        return
    end

    if catId == "mane_tint2" then
        buildAHorseHairState.mane.tint2 = item.value or item.id
        ApplyBuildAHorseHair("mane")
        return
    end

    if catId == "tail_tint0" then
        buildAHorseHairState.tail.tint0 = item.value or item.id
        ApplyBuildAHorseHair("tail")
        return
    end

    if catId == "tail_tint1" then
        buildAHorseHairState.tail.tint1 = item.value or item.id
        ApplyBuildAHorseHair("tail")
        return
    end

    if catId == "tail_tint2" then
        buildAHorseHairState.tail.tint2 = item.value or item.id
        ApplyBuildAHorseHair("tail")
        return
    end
end
--
-- Just after the existing ApplyBuildAHorseItemToPreview function, add:
--
-- Apply the current Build-A-Tack state to the preview horse
function ApplyBuildATackAllSlots()
    if not previewHorse or not DoesEntityExist(previewHorse) then return end

    local ped = previewHorse

    -- Start from the canonical appearance for this horse:
    -- base outfit, equipped tack, equipped beauty, and any
    -- *saved* Build-A-Horse appearance. We intentionally do
    -- NOT use the live Build-A-Horse debug preview state here.
    if ApplyHorseOutfit then
        ApplyHorseOutfit(ped)
    end

    if ApplyAllEquippedTack then
        ApplyAllEquippedTack(ped)
    end

    if ApplyAllEquippedBeauty then
        ApplyAllEquippedBeauty(ped)
    end

    -- Re-apply any saved Build-A-Horse appearance (body/hair/scale),
    -- if present on the owned horse data.
    if currentOwnedHorseData and CoalBuildAHorse and CoalBuildAHorse.ApplySavedToPed then
        local savedBAH = nil

        if currentOwnedHorseData.appearance and currentOwnedHorseData.appearance.buildAHorse then
            savedBAH = currentOwnedHorseData.appearance.buildAHorse
        elseif currentOwnedHorseData.beauty and currentOwnedHorseData.beauty.buildAHorse then
            savedBAH = currentOwnedHorseData.beauty.buildAHorse
        end

        if savedBAH then
            CoalBuildAHorse.ApplySavedToPed(ped, savedBAH)
        end
    end

    local function applySlot(slotKey)
        local slot = buildATackState[slotKey]
        if not slot or not slot.item or not slot.item.assets then return end
        if slot.item.none then return end

        local item   = slot.item
        local assets = item.assets or {}
        if #assets == 0 then return end

        local palette
        if slot.palette and slot.palette.palette then
            palette = slot.palette.palette
        elseif item.swatchPalette then
            palette = item.swatchPalette
        elseif assets[1].palette then
            palette = assets[1].palette
        else
            palette = "metaped_tint_leather"
        end

        for _, a in ipairs(assets) do
            if a.drawable and a.albedo and a.normal and a.material then
                local t0 = slot.tint0 ~= nil and slot.tint0 or a.tint0 or 0
                local t1 = slot.tint1 ~= nil and slot.tint1 or a.tint1 or 0
                local t2 = slot.tint2 ~= nil and slot.tint2 or a.tint2 or 0

                SetMetaPedTag(
                    ped,
                    a.drawable,
                    a.albedo,
                    a.normal,
                    a.material,
                    palette,
                    t0, t1, t2
                )
            end
        end
    end

    applySlot("saddle")
    applySlot("blanket")
    applySlot("bag")
    applySlot("stirrups")
    applySlot("horn")
    applySlot("harness")
    applySlot("holster")

    UpdatePedVariationTint(ped)
end




CoalBuildATack = CoalBuildATack or {}

function CoalBuildATack.ApplySavedToPed(ped, saved)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return end
    if not saved or type(saved) ~= "table" then return end

    local function applySlot(slotKey)
        local slot = saved[slotKey]
        if not slot or not slot.item or not slot.item.assets then return end

        local item   = slot.item
        local assets = item.assets or {}
        if #assets == 0 then return end

        local palette

        if slot.palette and slot.palette.palette then
            palette = slot.palette.palette
        elseif item.swatchPalette then
            palette = item.swatchPalette
        elseif assets[1].palette then
            palette = assets[1].palette
        else
            palette = "metaped_tint_leather"
        end

        for _, a in ipairs(assets) do
            if a.drawable and a.albedo and a.normal and a.material then
                local t0 = slot.tint0 ~= nil and slot.tint0 or a.tint0 or 0
                local t1 = slot.tint1 ~= nil and slot.tint1 or a.tint1 or 0
                local t2 = slot.tint2 ~= nil and slot.tint2 or a.tint2 or 0

                SetMetaPedTag(
                    ped,
                    a.drawable,
                    a.albedo,
                    a.normal,
                    a.material,
                    palette,
                    t0, t1, t2
                )
            end
        end
    end

    applySlot("saddle")
    applySlot("blanket")
    applySlot("bag")
    applySlot("stirrups")
    applySlot("horn")
    applySlot("harness")
    applySlot("holster")

    UpdatePedVariationTint(ped)
end

-- Handle a single Build-A-Tack category selection and refresh preview
function ApplyBuildATackItemToPreview(catId, item)
    if not previewHorse or not DoesEntityExist(previewHorse) then return end
    if not catId or not item then return end

    local map = buildATackCategorySlots[catId]
    if not map then return end

    local slotKey = map.slot
    local field   = map.field

    buildATackState[slotKey] = buildATackState[slotKey] or {}
    local slot = buildATackState[slotKey]

    if field == "item" then
        if item.none then
            -- Selecting "None" clears any Build-A-Tack override for this slot
            slot.item    = nil
            slot.palette = nil
            slot.tint0   = nil
            slot.tint1   = nil
            slot.tint2   = nil
        else
            slot.item = item
        end
    elseif field == "palette" then
        slot.palette = item
    elseif field == "tint0" then
        slot.tint0 = tonumber(item.value or item.id or item.tint0 or 0) or 0
    elseif field == "tint1" then
        slot.tint1 = tonumber(item.value or item.id or item.tint1 or 0) or 0
    elseif field == "tint2" then
        slot.tint2 = tonumber(item.value or item.id or item.tint2 or 0) or 0
    end

    ApplyBuildATackAllSlots()
end

-- Apply a tint-based beauty item (mane/tail colors)
function ApplyBeautyTint(ped, item)
    if not ped or ped == 0 or not item then return end
    if not item.palette or not item.tint0 then return end

        -- Disable tint 255: never apply it
   -- if (item.tint0 and item.tint0 >= 255)
  --  or (item.tint1 and item.tint1 >= 255)
  --  or (item.tint2 and item.tint2 >= 255) then
  --      return
  -- end

    local drawable = item.drawable
    local albedo   = item.albedo
    local normal   = item.normal
    local material = item.material
    local palette  = item.palette

    -- If you ever want separate logic per category, you can branch on catId or item.target here.
    if not drawable or not albedo or not normal or not material then
        -- No asset info -> nothing to do (safe fallback)
        return
    end

    SetMetaPedTag(
        ped,
        drawable,
        albedo,
        normal,
        material,
        palette,
        item.tint0 or 0,
        item.tint1 or 0,
        item.tint2 or 0
    )
    UpdatePedVariationTint(ped)
end
--
-- Resolve a tack item into a numeric hash, with simple caching
local function ResolveTackHash(item)
    if item.shopItemHash and item.shopItemHash ~= 0 then
        return item.shopItemHash
    end

    if item.shopItemName then
        if not item._cachedHash then
            item._cachedHash = GetHashKey(item.shopItemName)
        end
        return item._cachedHash
    end

    if item.rawName then          -- fallback hook if you ever store plain names
        if not item._cachedHash then
            item._cachedHash = GetHashKey(item.rawName)
        end
        return item._cachedHash
    end

    return nil
end
---------------------------------
-- Overlay tint onto the currently equipped saddle bags
-- Overlay tints onto the currently equipped saddle bags
local function ApplySaddlebagTints(ped)
    if not ped or ped == 0 then return end

    -- Need an equipped saddlebag to tint
    local bagId = equippedTack["saddlebags"]
    if not bagId then
        return
    end

    local bagItems = CoalTack.GetItemsForCategory("saddlebags")
    local baseBag  = nil
    for _, b in ipairs(bagItems) do
        if b.id == bagId then
            baseBag = b
            break
        end
    end

    if not baseBag or not baseBag.rawName then
        return
    end

    local assets = SaddlebagAssetsByName[baseBag.rawName]
    if not assets or #assets == 0 then
        print("[coal_stables] No asset data found for saddlebag:", baseBag.rawName)
        return
    end

    local function findTintItem(catId)
        local tid = equippedTack[catId]
        if not tid then return nil end

        local items = CoalTack.GetItemsForCategory(catId)
        for _, it in ipairs(items) do
            if it.id == tid then
                return it
            end
        end
        return nil
    end

    local tintItem0 = findTintItem("saddlebags_tint0")
    local tintItem1 = findTintItem("saddlebags_tint1")
    local tintItem2 = findTintItem("saddlebags_tint2")

    -- If none of the channels are set, nothing to do
    if not (tintItem0 or tintItem1 or tintItem2) then
        return
    end

    -- Palette: last non-nil palette from tint items wins if asset has no palette
    local selectedPalette = nil
    if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
    if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
    if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

    for _, a in ipairs(assets) do
        if a.drawable and a.albedo and a.normal and a.material then
            local palette = a.palette or selectedPalette

            local t0 = a.tint0 or 0
            local t1 = a.tint1 or 0
            local t2 = a.tint2 or 0

            if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
            if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
            if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

            SetMetaPedTag(
                ped,
                a.drawable,
                a.albedo,
                a.normal,
                a.material,
                palette or a.palette,
                t0, t1, t2
            )
        end
    end

    UpdatePedVariationTint(ped)
end

-------------------------------------
-- Overlay tints onto the currently equipped holsters (scabbard)
local function ApplyholstersTints(ped)
    if not ped or ped == 0 then return end

    -- Need an equipped holsters to tint
    local holstersId = equippedTack["holsters"]
    if not holstersId then
        return
    end

    local holstersItems = CoalTack.GetItemsForCategory("holsters")
    local baseholsters  = nil
    for _, h in ipairs(holstersItems) do
        if h.id == holstersId then
            baseholsters = h
            break
        end
    end

    if not baseholsters or not baseholsters.rawName then
        return
    end

    local assets = holstersAssetsByName[baseholsters.rawName]
    if not assets or #assets == 0 then
        print("[coal_stables] No asset data found for holsters:", baseholsters.rawName)
        return
    end

    local function findTintItem(catId)
        local tid = equippedTack[catId]
        if not tid then return nil end

        local items = CoalTack.GetItemsForCategory(catId)
        for _, it in ipairs(items) do
            if it.id == tid then
                return it
            end
        end
        return nil
    end

    local tintItem0 = findTintItem("holsters_tint0")
    local tintItem1 = findTintItem("holsters_tint1")
    local tintItem2 = findTintItem("holsters_tint2")

    -- If none of the channels are set, nothing to do
    if not (tintItem0 or tintItem1 or tintItem2) then
        return
    end

    -- Palette: last non-nil palette from tint items wins if asset has no palette
    local selectedPalette = nil
    if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
    if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
    if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

    for _, a in ipairs(assets) do
        if a.drawable and a.albedo and a.normal and a.material then
            local palette = a.palette or selectedPalette

            local t0 = a.tint0 or 0
            local t1 = a.tint1 or 0
            local t2 = a.tint2 or 0

            if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
            if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
            if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

            SetMetaPedTag(
                ped,
                a.drawable,
                a.albedo,
                a.normal,
                a.material,
                palette or a.palette,
                t0, t1, t2
            )
        end
    end

    UpdatePedVariationTint(ped)
end
-------------------------------------
-------------------------------------
-- Overlay tints onto the currently equipped horns
-------------------------------------
local function ApplyHornsTints(ped)
    if not ped or ped == 0 then return end

    -- Need an equipped horn to tint
    local hornsId = equippedTack["horns"]
    if not hornsId then
        return
    end

    local hornItems = CoalTack.GetItemsForCategory("horns")
    local baseHorns = nil
    for _, h in ipairs(hornItems) do
        if h.id == hornsId then
            baseHorns = h
            break
        end
    end

    if not baseHorns or not baseHorns.rawName then
        return
    end

    local assets = HornAssetsByName[baseHorns.rawName]
    if not assets or #assets == 0 then
        print("[coal_stables] No asset data found for horns:", baseHorns.rawName)
        return
    end

    local function findTintItem(catId)
        local tid = equippedTack[catId]
        if not tid then return nil end

        local items = CoalTack.GetItemsForCategory(catId)
        for _, it in ipairs(items) do
            if it.id == tid then
                return it
            end
        end
        return nil
    end

    local tintItem0 = findTintItem("horns_tint0")
    local tintItem1 = findTintItem("horns_tint1")
    local tintItem2 = findTintItem("horns_tint2")

    if not (tintItem0 or tintItem1 or tintItem2) then
        return
    end

    -- Palette: last non-nil palette from tint items wins if asset has no palette
    local selectedPalette = nil
    if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
    if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
    if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

    for _, a in ipairs(assets) do
        if a.drawable and a.albedo and a.normal and a.material then
            local palette = a.palette or selectedPalette

            local t0 = a.tint0 or 0
            local t1 = a.tint1 or 0
            local t2 = a.tint2 or 0

            if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
            if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
            if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

            SetMetaPedTag(
                ped,
                a.drawable,
                a.albedo,
                a.normal,
                a.material,
                palette or a.palette,
                t0, t1, t2
            )
        end
    end

    UpdatePedVariationTint(ped)
end

-------------------------------------

-- Apply all equipped tack
function ApplyAllEquippedTack(ped)
    if not ped or ped == 0 then return end



    ----------------------------------------------------------------
    -- PASS 1: normal tack (saddles / blankets / bags / bedrolls / etc.)
    --         SKIP all tint-only categories
    ----------------------------------------------------------------
    for catId, itemId in pairs(equippedTack) do
        if itemId
        and catId ~= "blanket_tint0"
        and catId ~= "blanket_tint1"
        and catId ~= "blanket_tint2"
        and catId ~= "saddle_tint0"
        and catId ~= "saddle_tint1"
        and catId ~= "saddle_tint2"
        and catId ~= "saddlebags_tint0"
        and catId ~= "saddlebags_tint1"
        and catId ~= "saddlebags_tint2"
        and catId ~= "bedroll_tint0"
        and catId ~= "bedroll_tint1"
        and catId ~= "bedroll_tint2"
    and catId ~= "holsters_tint0"
    and catId ~= "holsters_tint1"
    and catId ~= "holsters_tint2"
    and catId ~= "stirrups_tint0"   -- NEW
    and catId ~= "stirrups_tint1"   -- NEW
    and catId ~= "stirrups_tint2"   -- NEW
    and catId ~= "horns"
    and catId ~= "horns_tint0"
    and catId ~= "horns_tint1"
    and catId ~= "horns_tint2"
    then

            local items = CoalTack.GetItemsForCategory(catId)
            for _, item in ipairs(items) do
                if item.id == itemId then
                    -- 1) Normal shop-driven tack (saddles / blankets / bedrolls / bags / etc.)
                    local hash = ResolveTackHash(item)
                    if hash then
                        ApplyTackItem(ped, hash)

                    -- 2) Pure MetaPed-tag tack (bridles, harness, etc.)
                    elseif item.palette
                        and item.drawable and item.albedo
                        and item.normal   and item.material then

                        SetMetaPedTag(
                            ped,
                            item.drawable,
                            item.albedo,
                            item.normal,
                            item.material,
                            item.palette,
                            item.tint0 or 0,
                            item.tint1 or 0,
                            item.tint2 or 0
                        )
                        UpdatePedVariationTint(ped)
                    end
                    break
                end
            end
        end
    end

    ----------------------------------------------------------------
    -- PASS 2: combine blanket_tint0/1/2 onto the current blanket
    ----------------------------------------------------------------
    do
        local blanketId = equippedTack["blankets"]
        if blanketId then
            -- Find the base blanket entry
            local blankets = CoalTack.GetItemsForCategory("blankets")
            local baseBlanket = nil
            for _, b in ipairs(blankets) do
                if b.id == blanketId then
                    baseBlanket = b
                    break
                end
            end

            if baseBlanket
                and baseBlanket.drawable
                and baseBlanket.albedo
                and baseBlanket.normal
                and baseBlanket.material then

                -- Start from blanket's own palette + tints
                local palette = baseBlanket.palette
                local t0 = baseBlanket.tint0 or 0
                local t1 = baseBlanket.tint1 or 0
                local t2 = baseBlanket.tint2 or 0

                -- Merge each tint channel if a tint item is equipped
                local function mergeTintFromCategory(catId)
                    local tid = equippedTack[catId]
                    if not tid then return end

                    local items = CoalTack.GetItemsForCategory(catId)
                    for _, it in ipairs(items) do
                        if it.id == tid then
                            if it.palette then
                                palette = it.palette or palette
                            end
                            if it.tint0 then t0 = it.tint0 end
                            if it.tint1 then t1 = it.tint1 end
                            if it.tint2 then t2 = it.tint2 end
                            break
                        end
                    end
                end

                mergeTintFromCategory("blanket_tint0")
                mergeTintFromCategory("blanket_tint1")
                mergeTintFromCategory("blanket_tint2")

                -- Apply combined blanket tint
                SetMetaPedTag(
                    ped,
                    baseBlanket.drawable,
                    baseBlanket.albedo,
                    baseBlanket.normal,
                    baseBlanket.material,
                    palette or baseBlanket.palette,
                    t0, t1, t2
                )
                UpdatePedVariationTint(ped)
            end
        end
    end

      ----------------------------------------------------------------
    -- PASS 3: combine saddle_tint0/1/2 onto the current saddle
    --         using offline asset data from saddles.json
    ----------------------------------------------------------------
    do
        local hasAnySaddleTint =
            equippedTack["saddle_tint0"] or
            equippedTack["saddle_tint1"] or
            equippedTack["saddle_tint2"]

        if hasAnySaddleTint then
            -- Use the currently equipped saddle
            local saddleId = equippedTack["saddles"]
            if saddleId then
                local saddleItems = CoalTack.GetItemsForCategory("saddles")
                local baseSaddle  = nil

                for _, s in ipairs(saddleItems) do
                    if s.id == saddleId then
                        baseSaddle = s
                        break
                    end
                end

                if baseSaddle and baseSaddle.rawName then
                    local assets = SaddleAssetsByName[baseSaddle.rawName]
                    if assets and #assets > 0 then
                        local function findTintItem(catId)
                            local tid = equippedTack[catId]
                            if not tid then return nil end

                            local items = CoalTack.GetItemsForCategory(catId)
                            for _, it in ipairs(items) do
                                if it.id == tid then
                                    return it
                                end
                            end
                            return nil
                        end

                        local tintItem0 = findTintItem("saddle_tint0")
                        local tintItem1 = findTintItem("saddle_tint1")
                        local tintItem2 = findTintItem("saddle_tint2")

                        -- Palette: last non-nil palette from tint items wins
                        local selectedPalette = nil
                        if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
                        if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
                        if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

                        for _, a in ipairs(assets) do
                            if a.drawable and a.albedo and a.normal and a.material then
                                local palette = a.palette or selectedPalette

                                -- Start from asset’s own default tints
                                local t0 = a.tint0 or 0
                                local t1 = a.tint1 or 0
                                local t2 = a.tint2 or 0

                                -- Override per-channel if we have tint items
                                if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
                                if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
                                if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

                                SetMetaPedTag(
                                    ped,
                                    a.drawable,
                                    a.albedo,
                                    a.normal,
                                    a.material,
                                    palette or a.palette,
                                    t0, t1, t2
                                )
                            end
                        end

                        UpdatePedVariationTint(ped)
                    end
                end
            end
        end
    end

    ----------------------------------------------------------------
    -- PASS 4: combine bedroll_tint0/1/2 onto the current bedroll
    --         using offline asset data from bedrolls.json
    ----------------------------------------------------------------
    do
        local hasAnyBedrollTint =
            equippedTack["bedroll_tint0"] or
            equippedTack["bedroll_tint1"] or
            equippedTack["bedroll_tint2"]

        if hasAnyBedrollTint then
            local bedrollId = equippedTack["bedrolls"]
            if bedrollId then
                local bedrollItems = CoalTack.GetItemsForCategory("bedrolls")
                local baseBedroll  = nil
                for _, b in ipairs(bedrollItems) do
                    if b.id == bedrollId then
                        baseBedroll = b
                        break
                    end
                end

                if baseBedroll and baseBedroll.rawName then
                    local assets = BedrollAssetsByName[baseBedroll.rawName]
                    if assets and #assets > 0 then
                        local function findTintItem(catId)
                            local tid = equippedTack[catId]
                            if not tid then return nil end

                            local items = CoalTack.GetItemsForCategory(catId)
                            for _, it in ipairs(items) do
                                if it.id == tid then
                                    return it
                                end
                            end
                            return nil
                        end

                        local tintItem0 = findTintItem("bedroll_tint0")
                        local tintItem1 = findTintItem("bedroll_tint1")
                        local tintItem2 = findTintItem("bedroll_tint2")

                        local selectedPalette = nil
                        if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
                        if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
                        if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

                        for _, a in ipairs(assets) do
                            if a.drawable and a.albedo and a.normal and a.material then
                                local palette = a.palette or selectedPalette

                                local t0 = a.tint0 or 0
                                local t1 = a.tint1 or 0
                                local t2 = a.tint2 or 0

                                if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
                                if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
                                if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

                                SetMetaPedTag(
                                    ped,
                                    a.drawable,
                                    a.albedo,
                                    a.normal,
                                    a.material,
                                    palette or a.palette,
                                    t0, t1, t2
                                )
                            end
                        end

                        UpdatePedVariationTint(ped)
                    else
                        print("[coal_stables] No asset data found for bedroll:", baseBedroll.rawName)
                    end
                end
            end
        end
    end
    ----------------------------------------------------------------
    -- PASS X: combine stirrups_tint0/1/2 onto the current stirrups
    --         using offline asset data from stirrups.json
    ----------------------------------------------------------------
    do
        local hasAnyStirrupTint =
            equippedTack["stirrups_tint0"] or
            equippedTack["stirrups_tint1"] or
            equippedTack["stirrups_tint2"]

        if hasAnyStirrupTint then
            local stirrupId = equippedTack["stirrups"]
            if stirrupId then
                local stirrupItems = CoalTack.GetItemsForCategory("stirrups")
                local baseStirrups = nil
                for _, s in ipairs(stirrupItems) do
                    if s.id == stirrupId then
                        baseStirrups = s
                        break
                    end
                end

                if baseStirrups and baseStirrups.rawName then
                    local assets = StirrupsAssetsByName[baseStirrups.rawName]
                    if assets and #assets > 0 then
                        local function findTintItem(catId)
                            local tid = equippedTack[catId]
                            if not tid then return nil end

                            local items = CoalTack.GetItemsForCategory(catId)
                            for _, it in ipairs(items) do
                                if it.id == tid then
                                    return it
                                end
                            end
                            return nil
                        end

                        local tintItem0 = findTintItem("stirrups_tint0")
                        local tintItem1 = findTintItem("stirrups_tint1")
                        local tintItem2 = findTintItem("stirrups_tint2")

                        local selectedPalette = nil
                        if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
                        if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
                        if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

                        for _, a in ipairs(assets) do
                            if a.drawable and a.albedo and a.normal and a.material then
                                local palette = a.palette or selectedPalette

                                local t0 = a.tint0 or 0
                                local t1 = a.tint1 or 0
                                local t2 = a.tint2 or 0

                                if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
                                if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
                                if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

                                SetMetaPedTag(
                                    ped,
                                    a.drawable,
                                    a.albedo,
                                    a.normal,
                                    a.material,
                                    palette or a.palette,
                                    t0, t1, t2
                                )
                            end
                        end

                        UpdatePedVariationTint(ped)
                    end
                end
            end
        end
    end

        ----------------------------------------------------------------
    -- PASS 4: OVERLAY SADDLEBAG TINT LAST
    --         so it never nukes blankets / saddles / bedroll
    ----------------------------------------------------------------
    ApplyHornsTints(ped)         -- NEW: horns overlay
    ----------------------------------------------------------------
    -- PASS 5: overlay holsters tints onto the current holsters
    ----------------------------------------------------------------
    ApplyholstersTints(ped)
    ---------------------------------------------------------------
    -- PASS 6: OVERLAY SADDLEBAG TINT LAST
    --         so it never nukes blankets / saddles / bedroll / holsters
    ----------------------------------------------------------------
    ApplySaddlebagTints(ped)
end


-----------------------
-----------------------
  
-----------------------

-- Apply all equipped beauty (manes/tails)
function ApplyAllEquippedBeauty(ped)
    if not ped or ped == 0 then return end
    if not hasBeautyModule or not CoalBeauty or not CoalBeauty.GetItemsForCategory then return end

    local function applyCategory(catId)
        local itemId = equippedBeauty[catId]
        if not itemId then return end

        local items = CoalBeauty.GetItemsForCategory(catId)
        for _, item in ipairs(items) do
            if item.id == itemId then
                if item.shopItemHash then
                    -- Mane / tail style (shop item)
                    ApplyTackItem(ped, item.shopItemHash)

                elseif item.palette then
                    -- Tint-based items
                    if catId == "HorseBody" then
                        -- 1) Apply body coat tint
                        ApplyBeautyTint(ped, item)

                        -- 2) Find matching HEAD coat tint by numeric suffix
                        local idx = tostring(item.id):match("_(%d+)$")
                        if idx then
                            local headItems = CoalBeauty.GetItemsForCategory("HorseHead")
                            for _, hItem in ipairs(headItems) do
                                if tostring(hItem.id):match("_(%d+)$") == idx then
                                    ApplyBeautyTint(ped, hItem)
                                    break
                                end
                            end
                        end
                    else
                        -- Normal tint (mane/tail colors)
                        ApplyBeautyTint(ped, item)
                    end
                end

                break
            end
        end
    end

    for _, catId in ipairs(beautyApplyOrder) do
        applyCategory(catId)
    end
end

-- Apply pending beauty config to the preview horse
function ApplyPendingBeautyToPreview()
    if not previewHorse or not DoesEntityExist(previewHorse) then return end
    if not hasBeautyModule or not CoalBeauty or not CoalBeauty.GetItemsForCategory then return end

    local function applyCategory(catId)
        local itemId = pendingBeauty[catId]
        if not itemId then return end

        local items = CoalBeauty.GetItemsForCategory(catId)
        for _, item in ipairs(items) do
            if item.id == itemId then
                if item.shopItemHash then
                    -- Mane / tail style
                    ApplyTackItem(previewHorse, item.shopItemHash)

                elseif item.palette then
                    if catId == "HorseBody" then
                        -- Body coat on preview
                        ApplyBeautyTint(previewHorse, item)

                        -- Matching head tint
                        local idx = tostring(item.id):match("_(%d+)$")
                        if idx then
                            local headItems = CoalBeauty.GetItemsForCategory("HorseHead")
                            for _, hItem in ipairs(headItems) do
                                if tostring(hItem.id):match("_(%d+)$") == idx then
                                    ApplyBeautyTint(previewHorse, hItem)
                                    break
                                end
                            end
                        end
                    else
                        -- Normal tint (mane/tail colors)
                        ApplyBeautyTint(previewHorse, item)
                    end
                end

                break
            end
        end
    end

    -- Same order as equipped beauty:
    -- colors first, then styles so styles don't get overwritten
    for _, catId in ipairs(beautyApplyOrder) do
        applyCategory(catId)
    end
end

--
-- Overlay pending saddlebag tint on the preview horse
-- Overlay pending saddlebag tints on the preview horse
local function ApplyPendingSaddlebagTintToPreview()
    if not previewHorse or not DoesEntityExist(previewHorse) then return end

    local function findPendingTintItem(catId)
        local tid = pendingTack[catId] or equippedTack[catId]
        if not tid then return nil end

        local items = CoalTack.GetItemsForCategory(catId)
        for _, it in ipairs(items) do
            if it.id == tid then
                return it
            end
        end
        return nil
    end

    local tintItem0 = findPendingTintItem("saddlebags_tint0")
    local tintItem1 = findPendingTintItem("saddlebags_tint1")
    local tintItem2 = findPendingTintItem("saddlebags_tint2")

    if not (tintItem0 or tintItem1 or tintItem2) then
        return
    end

    local bagId = pendingTack["saddlebags"] or equippedTack["saddlebags"]
    if not bagId then
        return
    end

    local bagItems = CoalTack.GetItemsForCategory("saddlebags")
    local baseBag  = nil
    for _, b in ipairs(bagItems) do
        if b.id == bagId then
            baseBag = b
            break
        end
    end

    if not baseBag or not baseBag.rawName then
        return
    end

    local assets = SaddlebagAssetsByName[baseBag.rawName]
    if not assets or #assets == 0 then
        return
    end

    local selectedPalette = nil
    if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
    if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
    if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

    for _, a in ipairs(assets) do
        if a.drawable and a.albedo and a.normal and a.material then
            local palette = a.palette or selectedPalette

            local t0 = a.tint0 or 0
            local t1 = a.tint1 or 0
            local t2 = a.tint2 or 0

            if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
            if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
            if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

            SetMetaPedTag(
                previewHorse,
                a.drawable,
                a.albedo,
                a.normal,
                a.material,
                palette or a.palette,
                t0, t1, t2
            )
        end
    end

    UpdatePedVariationTint(previewHorse)
end
-------------------------------------
-- Overlay pending holsters tints on the preview horse
local function ApplyPendingholstersTintToPreview()
    if not previewHorse or not DoesEntityExist(previewHorse) then return end

    local function findPendingTintItem(catId)
        local tid = pendingTack[catId] or equippedTack[catId]
        if not tid then return nil end

        local items = CoalTack.GetItemsForCategory(catId)
        for _, it in ipairs(items) do
            if it.id == tid then
                return it
            end
        end
        return nil
    end

    local tintItem0 = findPendingTintItem("holsters_tint0")
    local tintItem1 = findPendingTintItem("holsters_tint1")
    local tintItem2 = findPendingTintItem("holsters_tint2")

    if not (tintItem0 or tintItem1 or tintItem2) then
        return
    end

    local holstersId = pendingTack["holsters"] or equippedTack["holsters"]
    if not holstersId then
        return
    end

    local holstersItems = CoalTack.GetItemsForCategory("holsters")
    local baseholsters  = nil
    for _, h in ipairs(holstersItems) do
        if h.id == holstersId then
            baseholsters = h
            break
        end
    end

    if not baseholsters or not baseholsters.rawName then
        return
    end

    local assets = holstersAssetsByName[baseholsters.rawName]
    if not assets or #assets == 0 then
        return
    end

    local selectedPalette = nil
    if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
    if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
    if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

    for _, a in ipairs(assets) do
        if a.drawable and a.albedo and a.normal and a.material then
            local palette = a.palette or selectedPalette

            local t0 = a.tint0 or 0
            local t1 = a.tint1 or 0
            local t2 = a.tint2 or 0

            if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
            if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
            if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

            SetMetaPedTag(
                previewHorse,
                a.drawable,
                a.albedo,
                a.normal,
                a.material,
                palette or a.palette,
                t0, t1, t2
            )
        end
    end

    UpdatePedVariationTint(previewHorse)
end
-------------------------------------
-------------------------------------
-- Overlay pending horns tints on the preview horse
-------------------------------------
local function ApplyPendingHornsTintToPreview()
    if not previewHorse or not DoesEntityExist(previewHorse) then return end

    local function findPendingTintItem(catId)
        local tid = pendingTack[catId] or equippedTack[catId]
        if not tid then return nil end

        local items = CoalTack.GetItemsForCategory(catId)
        for _, it in ipairs(items) do
            if it.id == tid then
                return it
            end
        end
        return nil
    end

    local tintItem0 = findPendingTintItem("horns_tint0")
    local tintItem1 = findPendingTintItem("horns_tint1")
    local tintItem2 = findPendingTintItem("horns_tint2")

    if not (tintItem0 or tintItem1 or tintItem2) then
        return
    end

    local hornsId = pendingTack["horns"] or equippedTack["horns"]
    if not hornsId then
        return
    end

    local hornItems = CoalTack.GetItemsForCategory("horns")
    local baseHorns = nil
    for _, h in ipairs(hornItems) do
        if h.id == hornsId then
            baseHorns = h
            break
        end
    end

    if not baseHorns or not baseHorns.rawName then
        return
    end

    local assets = HornAssetsByName[baseHorns.rawName]
    if not assets or #assets == 0 then
        return
    end

    local selectedPalette = nil
    if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
    if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
    if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

    for _, a in ipairs(assets) do
        if a.drawable and a.albedo and a.normal and a.material then
            local palette = a.palette or selectedPalette

            local t0 = a.tint0 or 0
            local t1 = a.tint1 or 0
            local t2 = a.tint2 or 0

            if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
            if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
            if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

            SetMetaPedTag(
                previewHorse,
                a.drawable,
                a.albedo,
                a.normal,
                a.material,
                palette or a.palette,
                t0, t1, t2
            )
        end
    end

    UpdatePedVariationTint(previewHorse)
end

-------------------------------------
--
function ApplyPendingTackToPreview()
    if not previewHorse or not DoesEntityExist(previewHorse) then return end

    -- Reset to base outfit
    ApplyHorseOutfit(previewHorse)

    -- Reapply currently equipped beauty so manes/tails stay
    ApplyAllEquippedBeauty(previewHorse)


    -- Reapply Build-A-Horse saved parts (body/head/barrel/hair/scale) so Tack preview matches other menus
    do
        local savedBuild = nil
        if currentOwnedHorseData and currentOwnedHorseData.beauty and currentOwnedHorseData.beauty.buildAHorse then
            savedBuild = currentOwnedHorseData.beauty.buildAHorse
        end
        if savedBuild and CoalBuildAHorse and CoalBuildAHorse.ApplySavedToPed then
            CoalBuildAHorse.ApplySavedToPed(previewHorse, savedBuild)
        end
    end

    ----------------------------------------------------------------
    -- PASS 1: all non-tint-only categories (saddles / blankets / bags / bedrolls / holsters / etc.)
    --         Iterate over tackCategories so we also handle categories that exist only in pendingTack.
    ----------------------------------------------------------------
    for _, cat in ipairs(tackCategories) do
        local catId = cat.id

        -- Skip all tint-only categories
        if catId ~= "blanket_tint0"
           and catId ~= "blanket_tint1"
           and catId ~= "blanket_tint2"
           and catId ~= "saddle_tint0"
           and catId ~= "saddle_tint1"
           and catId ~= "saddle_tint2"
           and catId ~= "saddlebags_tint0"
           and catId ~= "saddlebags_tint1"
           and catId ~= "saddlebags_tint2"
           and catId ~= "bedroll_tint0"
           and catId ~= "bedroll_tint1"
           and catId ~= "bedroll_tint2"
           and catId ~= "holsters_tint0"
           and catId ~= "holsters_tint1"
           and catId ~= "holsters_tint2"
           and catId ~= "stirrups_tint0"   -- NEW
           and catId ~= "stirrups_tint1"   -- NEW
           and catId ~= "stirrups_tint2"   -- NEW
           and catId ~= "horns"
           and catId ~= "horns_tint0"
           and catId ~= "horns_tint1"
           and catId ~= "horns_tint2"
        then
            local itemId = pendingTack[catId] or equippedTack[catId]
            if itemId then
                local items = CoalTack.GetItemsForCategory(catId)
                for _, item in ipairs(items) do
                    if item.id == itemId then
                        if item.shopItemHash then
                            -- Normal DB/shop tack (saddle/blanket/bedroll/bag/holsters/etc.)
                            ApplyTackItem(previewHorse, item.shopItemHash)

                        elseif item.palette
                            and item.drawable and item.albedo
                            and item.normal   and item.material then

                            -- Pure MetaPed-tag tack (bridles, harness, etc.)
                            SetMetaPedTag(
                                previewHorse,
                                item.drawable,
                                item.albedo,
                                item.normal,
                                item.material,
                                item.palette,
                                item.tint0 or 0,
                                item.tint1 or 0,
                                item.tint2 or 0
                            )
                            UpdatePedVariationTint(previewHorse)
                        end
                        break
                    end
                end
            end
        end
    end


    ----------------------------------------------------------------
    -- PASS 2: combine blanket_tint0/1/2 onto the pending blanket
    ----------------------------------------------------------------
    do
        -- Prefer pending blanket; fall back to equipped
        local blanketId = pendingTack["blankets"] or equippedTack["blankets"]
        if blanketId then
            local blankets    = CoalTack.GetItemsForCategory("blankets")
            local baseBlanket = nil
            for _, b in ipairs(blankets) do
                if b.id == blanketId then
                    baseBlanket = b
                    break
                end
            end

            if baseBlanket
               and baseBlanket.drawable
               and baseBlanket.albedo
               and baseBlanket.normal
               and baseBlanket.material then

                local palette = baseBlanket.palette
                local t0 = baseBlanket.tint0 or 0
                local t1 = baseBlanket.tint1 or 0
                local t2 = baseBlanket.tint2 or 0

                local function mergePendingTint(catId)
                    local itemId = pendingTack[catId]
                    if not itemId then return end

                    local items = CoalTack.GetItemsForCategory(catId)
                    for _, it in ipairs(items) do
                        if it.id == itemId then
                            if it.palette then
                                palette = it.palette or palette
                            end
                            if it.tint0 then t0 = it.tint0 end
                            if it.tint1 then t1 = it.tint1 end
                            if it.tint2 then t2 = it.tint2 end
                            break
                        end
                    end
                end

                mergePendingTint("blanket_tint0")
                mergePendingTint("blanket_tint1")
                mergePendingTint("blanket_tint2")

                SetMetaPedTag(
                    previewHorse,
                    baseBlanket.drawable,
                    baseBlanket.albedo,
                    baseBlanket.normal,
                    baseBlanket.material,
                    palette or baseBlanket.palette,
                    t0, t1, t2
                )
                UpdatePedVariationTint(previewHorse)
            end
        end
    end

    ----------------------------------------------------------------
    -- PASS 3: combine saddle_tint0/1/2 onto the pending saddle (preview)
    ----------------------------------------------------------------
    do
        local hasAnyPendingSaddleTint =
            pendingTack["saddle_tint0"] or
            pendingTack["saddle_tint1"] or
            pendingTack["saddle_tint2"]

        if hasAnyPendingSaddleTint then
            -- Prefer pending saddle; fall back to equipped
            local saddleId = pendingTack["saddles"] or equippedTack["saddles"]
            if saddleId then
                local saddleItems = CoalTack.GetItemsForCategory("saddles")
                local baseSaddle  = nil
                for _, s in ipairs(saddleItems) do
                    if s.id == saddleId then
                        baseSaddle = s
                        break
                    end
                end

                if baseSaddle and baseSaddle.rawName then
                    local assets = SaddleAssetsByName[baseSaddle.rawName]
                    if assets and #assets > 0 then
                        local function findPendingTintItem(catId)
                            local tid = pendingTack[catId]
                            if not tid then return nil end

                            local items = CoalTack.GetItemsForCategory(catId)
                            for _, it in ipairs(items) do
                                if it.id == tid then
                                    return it
                                end
                            end
                            return nil
                        end

                        local tintItem0 = findPendingTintItem("saddle_tint0")
                        local tintItem1 = findPendingTintItem("saddle_tint1")
                        local tintItem2 = findPendingTintItem("saddle_tint2")

                        local selectedPalette = nil
                        if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
                        if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
                        if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

                        for _, a in ipairs(assets) do
                            if a.drawable and a.albedo and a.normal and a.material then
                                local palette = a.palette or selectedPalette

                                local t0 = a.tint0 or 0
                                local t1 = a.tint1 or 0
                                local t2 = a.tint2 or 0

                                if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
                                if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
                                if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

                                SetMetaPedTag(
                                    previewHorse,
                                    a.drawable,
                                    a.albedo,
                                    a.normal,
                                    a.material,
                                    palette or a.palette,
                                    t0, t1, t2
                                )
                            end
                        end

                        UpdatePedVariationTint(previewHorse)
                    end
                end
            end
        end
    end
-----------------------------------
------------------------------------
    ----------------------------------------------------------------
    -- PASS 4: combine bedroll_tint0/1/2 onto the pending bedroll
    ----------------------------------------------------------------
    do
        local hasAnyPendingBedrollTint =
            pendingTack["bedroll_tint0"] or
            pendingTack["bedroll_tint1"] or
            pendingTack["bedroll_tint2"]

        if hasAnyPendingBedrollTint then
            local bedrollId = pendingTack["bedrolls"] or equippedTack["bedrolls"]
            if bedrollId then
                local bedrollItems = CoalTack.GetItemsForCategory("bedrolls")
                local baseBedroll  = nil
                for _, b in ipairs(bedrollItems) do
                    if b.id == bedrollId then
                        baseBedroll = b
                        break
                    end
                end

                if baseBedroll and baseBedroll.rawName then
                    local assets = BedrollAssetsByName[baseBedroll.rawName]
                    if assets and #assets > 0 then
                        local function findPendingTintItem(catId)
                            local tid = pendingTack[catId] or equippedTack[catId]
                            if not tid then return nil end

                            local items = CoalTack.GetItemsForCategory(catId)
                            for _, it in ipairs(items) do
                                if it.id == tid then
                                    return it
                                end
                            end
                            return nil
                        end

                        local tintItem0 = findPendingTintItem("bedroll_tint0")
                        local tintItem1 = findPendingTintItem("bedroll_tint1")
                        local tintItem2 = findPendingTintItem("bedroll_tint2")

                        local selectedPalette = nil
                        if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
                        if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
                        if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

                        for _, a in ipairs(assets) do
                            if a.drawable and a.albedo and a.normal and a.material then
                                local palette = a.palette or selectedPalette

                                local t0 = a.tint0 or 0
                                local t1 = a.tint1 or 0
                                local t2 = a.tint2 or 0

                                if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
                                if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
                                if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

                                SetMetaPedTag(
                                    previewHorse,
                                    a.drawable,
                                    a.albedo,
                                    a.normal,
                                    a.material,
                                    palette or a.palette,
                                    t0, t1, t2
                                )
                            end
                        end

                        UpdatePedVariationTint(previewHorse)
                    end
                end
            end
        end
    end
-----------------------------------
    ----------------------------------------------------------------
    -- PASS Y: combine stirrups_tint0/1/2 onto the pending stirrups
    --         on the preview horse
    ----------------------------------------------------------------
    do
        local hasAnyPendingStirrupTint =
            pendingTack["stirrups_tint0"] or
            pendingTack["stirrups_tint1"] or
            pendingTack["stirrups_tint2"]

        if hasAnyPendingStirrupTint then
            local stirrupId = pendingTack["stirrups"] or equippedTack["stirrups"]
            if stirrupId then
                local stirrupItems = CoalTack.GetItemsForCategory("stirrups")
                local baseStirrups = nil
                for _, s in ipairs(stirrupItems) do
                    if s.id == stirrupId then
                        baseStirrups = s
                        break
                    end
                end

                if baseStirrups and baseStirrups.rawName then
                    local assets = StirrupsAssetsByName[baseStirrups.rawName]
                    if assets and #assets > 0 then
                        local function findPendingTintItem(catId)
                            local tid = pendingTack[catId] or equippedTack[catId]
                            if not tid then return nil end

                            local items = CoalTack.GetItemsForCategory(catId)
                            for _, it in ipairs(items) do
                                if it.id == tid then
                                    return it
                                end
                            end
                            return nil
                        end

                        local tintItem0 = findPendingTintItem("stirrups_tint0")
                        local tintItem1 = findPendingTintItem("stirrups_tint1")
                        local tintItem2 = findPendingTintItem("stirrups_tint2")

                        local selectedPalette = nil
                        if tintItem0 and tintItem0.palette then selectedPalette = tintItem0.palette end
                        if tintItem1 and tintItem1.palette then selectedPalette = tintItem1.palette end
                        if tintItem2 and tintItem2.palette then selectedPalette = tintItem2.palette end

                        for _, a in ipairs(assets) do
                            if a.drawable and a.albedo and a.normal and a.material then
                                local palette = a.palette or selectedPalette

                                local t0 = a.tint0 or 0
                                local t1 = a.tint1 or 0
                                local t2 = a.tint2 or 0

                                if tintItem0 and tintItem0.tint0 then t0 = tintItem0.tint0 end
                                if tintItem1 and tintItem1.tint1 then t1 = tintItem1.tint1 end
                                if tintItem2 and tintItem2.tint2 then t2 = tintItem2.tint2 end

                                SetMetaPedTag(
                                    previewHorse,
                                    a.drawable,
                                    a.albedo,
                                    a.normal,
                                    a.material,
                                    palette or a.palette,
                                    t0, t1, t2
                                )
                            end
                        end

                        UpdatePedVariationTint(previewHorse)
                    end
                end
            end
        end
    end

    ----------------------------------------------------------------
    ----------------------------------------------------------------
    -- PASS 5: overlay holsters tints on the preview horse
    ----------------------------------------------------------------
    ApplyPendingholstersTintToPreview()

    ----------------------------------------------------------------
    -- PASS 6: overlay pending saddlebag tint LAST on the preview horse
    ----------------------------------------------------------------
    ApplyPendingSaddlebagTintToPreview()
-- NEW: horns preview overlay (can go before or after holsters; they don'
        ApplyPendingHornsTintToPreview()
end
--
function RefreshPreviewHorseAppearance()
    if not previewHorse or not DoesEntityExist(previewHorse) then return end
    -- Reset to base outfit, then reapply chosen tack + beauty
    ApplyHorseOutfit(previewHorse)
    ApplyAllEquippedTack(previewHorse)
    ApplyAllEquippedBeauty(previewHorse)

    -- Apply any saved Build-A-Tack recipe for this horse on top
    if  currentOwnedHorseData
        and CoalBuildATack
        and CoalBuildATack.ApplySavedToPed then
        local savedBATack = nil
        if currentOwnedHorseData.appearance and currentOwnedHorseData.appearance.buildATack then
            savedBATack = currentOwnedHorseData.appearance.buildATack
        elseif currentOwnedHorseData.beauty and currentOwnedHorseData.beauty.buildATack then
            -- Backwards compatibility with old beauty.buildATack saves
            savedBATack = currentOwnedHorseData.beauty.buildATack
        end

        if savedBATack then
            CoalBuildATack.ApplySavedToPed(previewHorse, savedBATack)
        end
    end
end

--=====================================================================
--  HORSE FLEE / DISMISS (RIGHT-CLICK LOCKON + F)
--  - Owned Coal Stables horse: flees + despawns
--  - Wild / non-owned horses: just flee, no delete
--=====================================================================

CreateThread(function()
    while true do
        Wait(0)

        local playerId = PlayerId()
        local ped      = PlayerPedId()

        -- Figure out what we're locked onto / aiming at
        local aiming, entity = GetEntityPlayerIsFreeAimingAt(playerId)

        if not aiming then
            local hasTarget, target = GetPlayerTargetEntity(playerId)
            if hasTarget then
                aiming  = true
                entity  = target
            end
        end

        -- Nothing targeted? Skip.
        if not aiming or not entity or not DoesEntityExist(entity) then
            goto continue
        end

        -- We only care about animal peds (horses etc.), not humans
        if (not IsEntityAPed(entity)) or IsPedHuman(entity) then
            goto continue
        end
        -- Only react when the game says "Flee" (F) and you actually press it
        if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, horseFleeControl) then __coalMenuLastInput = GetGameTimer()
            local horse = entity

            -- Is this our owned Coal Stables horse?
            local isOwned =
                currentOwnedHorse
                and DoesEntityExist(currentOwnedHorse)
                and (horse == currentOwnedHorse)

            -- Make it run away from the player
            TaskSmartFleePed(horse, ped, 80.0, -1, 0, 3.0, 0)
            SetPedKeepTask(horse, true)

            if isOwned then
                -- Owned horse: forget our handle + delete after a short time
                local horseRef = horse
                currentOwnedHorse = nil

                CreateThread(function()
                    Wait(15000) -- owned horse despawn delay (keep as-is or tweak)
                    if DoesEntityExist(horseRef) then
                        DeletePed(horseRef)
                    end
                end)
            else
                -- Wild / NPC horse: flee for a bit, then despawn
                local horseRef = horse

                CreateThread(function()
                    Wait(6000) -- non-owned horses: 6s of fleeing, then delete
                    if DoesEntityExist(horseRef) then
                        DeletePed(horseRef)
                    end
                end)
            end
        end
        ::continue::
    end
end)
--=====================================================================
--  WHISTLE TO CALL OWNED HORSE
--  - If horse is already out: make it run to you
--  - If no horse / lost horse: ask server to spawn it near you
--=====================================================================

CreateThread(function()
    while true do
        Wait(0)

if not (
    stableMainMenuOpen
    or stableMenuOpen
    or tackCategoryMenuOpen
    or beautyCategoryMenuOpen
    or bruteforceMenuOpen
    or buildAHorseMenuOpen
) and IsControlJustPressed(0, whistleControl) then


            local ped = PlayerPedId()

            -- Ignore whistle if we're already on a mount
            if IsPedOnMount(ped) then
                goto continue
            end

            -- If we have a spawned owned horse, try to make it come to us
            if currentOwnedHorse and DoesEntityExist(currentOwnedHorse) and not IsPedDeadOrDying(currentOwnedHorse, true) then
                local horse      = currentOwnedHorse
                local pCoords    = GetEntityCoords(ped)
                local hCoords    = GetEntityCoords(horse)
                local dist       = #(pCoords - hCoords)

                -- If it's reasonably close, just make it run to us
                if dist < 120.0 then
                    ClearPedTasks(horse)
                    -- Run to the player and stop a couple meters away
                    TaskGoToEntity(horse, ped, -1, 3.0, 5.0, 0, 0)
                    SetPedKeepTask(horse, true)
                else
                    -- Too far / effectively lost -> respawn near us
                    TriggerServerEvent("coal_stables:whistleHorse")
                end
            else
                -- No current horse handle, ask server to spawn it
                TriggerServerEvent("coal_stables:whistleHorse")
            end
        end

        ::continue::
    end
end)
------------------------------
-- Apply outfit + scrub dirt so horses look clean
function ApplyHorseOutfit(ped)
    if not ped or ped == 0 then return end

    -- Give the horse a proper outfit variation
    Citizen.InvokeNative(0x283978A15512B2FE, ped, true)      -- _SET_RANDOM_OUTFIT_VARIATION

    -- Try to force a full preset (often includes saddle/tack)
    Citizen.InvokeNative(0x1902C4CFCC5BE57C, ped, 0)         -- SET_PED_OUTFIT_PRESET
    -- Make sure the visual changes apply
    Citizen.InvokeNative(0xCC8CA3E88256E58F, ped, 0, 1, 1, 1, false) -- _UPDATE_PED_VARIATION

    -- Immediate clean pass
    Citizen.InvokeNative(0x6585D955A68452A5, ped)            -- CLEAR_PED_ENV_DIRT
    ClearPedWetness(ped)

    -- Clear damage / grime / blood overlays
    Citizen.InvokeNative(0x9C720776DAA43E7E, ped)            -- CLEAR_PED_DAMAGE_DECAL
    Citizen.InvokeNative(0xB63B9178D0F58D82, ped)            -- _CLEAR_PED_TEXTURE

    -- Force dirt level to 0
    Citizen.InvokeNative(0x7A56D66C78D1AAB7, ped, 0.0)       -- SET_PED_DIRT_LEVEL (clean)

    -- Do a few extra clean ticks in case the outfit re-applies grime after a frame
    CreateThread(function()
        if not DoesEntityExist(ped) then return end

        for i = 1, 8 do
            Wait(100)
            if not DoesEntityExist(ped) then break end

            Citizen.InvokeNative(0x6585D955A68452A5, ped)
            ClearPedWetness(ped)
            Citizen.InvokeNative(0x9C720776DAA43E7E, ped)
            Citizen.InvokeNative(0xB63B9178D0F58D82, ped)
            Citizen.InvokeNative(0x7A56D66C78D1AAB7, ped, 0.0)
        end
    end)
end
-----------------
-- Helper: find a safe ground Z for horse spawn at this XY
local function GetSafeGroundZForHorse(pos)
    if not pos then return 0.0 end

    local x  = pos.x
    local y  = pos.y
    local baseZ = pos.z or 0.0

    local bestZ = baseZ
    local found, groundZ

    -- Try a few different heights so we almost always hit something
    local testHeights = {
        baseZ + 2.0,
        baseZ + 10.0,
        baseZ + 25.0,
        baseZ + 50.0,
        1000.0,          -- big "world" fallback
    }

    for _, h in ipairs(testHeights) do
        found, groundZ = GetGroundZAndNormalFor_3dCoord(x, y, h)
        if found then
            bestZ = groundZ
            break
        end
    end

    -- If the ground we found is WAY below our requested Z (e.g. balcony / interior),
    -- assume we want to stay at baseZ instead so we spawn on the local floor.
    if bestZ < (baseZ - 10.0) then
        bestZ = baseZ
    end

    -- Tiny lift so we don't spawn *inside* the floor
    return bestZ + 0.05
end
--------------------------------------------
--------------------------------------------
--------------------------------------------
    --
    RegisterNetEvent("coal_stables:spawnOwnedHorse", function(horseData, stableId)
    -- Sync local appearance state from server data (important if we whistled
    -- before ever opening the stables UI this session)
    if horseData then
        currentOwnedHorseData = horseData

        if horseData.tack and type(horseData.tack) == "table" then
            for k, v in pairs(horseData.tack) do
                equippedTack[k] = v
            end
        end

        if horseData.beauty and type(horseData.beauty) == "table" then
            for k, v in pairs(horseData.beauty) do
                equippedBeauty[k] = v
            end
        end
    end

    -- ... existing spawnPos / Z / CreatePed logic continues here ...

    -- Find the stable coords from config
    local spawnPos = nil
    local spawnHeading = 0.0

    -- 1) Try to use a stable spawn first
    if stableId then
        for _, stable in ipairs(CoalStables.Config.Stables) do
            if stable.id == stableId then
                spawnPos     = stable.coords
                spawnHeading = stable.heading or 0.0
                break
            end
        end
    end

    -- 2) Whistle / fallback: spawn a bit in front of the player
    if not spawnPos then
        local ped = PlayerPedId()
        spawnPos  = GetOffsetFromEntityInWorldCoords(ped, 0.0, 6.0, 0.0)
        spawnHeading = GetEntityHeading(ped) + 90.0
        if spawnHeading >= 360.0 then
            spawnHeading = spawnHeading - 360.0
        end
    end

    -- 3) Smart Z logic for interiors / exteriors (same as preview horse)
    local baseZ  = spawnPos.z
    local spawnZ = baseZ

    local foundGround, groundZ = GetGroundZAndNormalFor_3dCoord(spawnPos.x, spawnPos.y, baseZ + 2.0)
    if foundGround then
        if groundZ > baseZ - 0.3 then
            -- Real floor (within ~0.3 below feet)
            spawnZ = groundZ + 0.05
        else
            -- Ignore far-below world ground under interiors
            spawnZ = baseZ + 0.01
        end
    else
        spawnZ = baseZ + 0.01
    end

    -- 4) Load model
    local modelName = horseData.model
    local model     = GetHashKey(modelName)

    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end

    -- 5) If we already have an owned horse out, clean it up first
    if currentOwnedHorse and DoesEntityExist(currentOwnedHorse) then
        DeletePed(currentOwnedHorse)
        currentOwnedHorse = nil
    end

    -- 6) Create the horse OFFSCREEN so we never see the setup frames
    local offscreenZ = spawnZ - 80.0
    local horse = CreatePed(model, spawnPos.x, spawnPos.y, offscreenZ, spawnHeading, true, true, false, false)
    if horse == 0 then
        print(("[coal_stables] Failed to create OWNED horse for model %s"):format(modelName))
        SetModelAsNoLongerNeeded(model)
        return
    end

    -- Completely hide & freeze while we set everything up
    SetEntityVisible(horse, false)
    FreezeEntityPosition(horse, true)
    ClearPedTasksImmediately(horse)

    -- 7) Outfit / tack / beauty while offscreen
    ApplyHorseOutfit(horse)
    ApplyAllEquippedTack(horse)
    ApplyAllEquippedBeauty(horse)

    -- Apply Build-A-Horse save, if this horse has one (new appearance structure)
    do
        local savedBAHorse = nil
        if horseData then
            if horseData.appearance and horseData.appearance.buildAHorse then
                -- Preferred: new appearance.buildAHorse structure
                savedBAHorse = horseData.appearance.buildAHorse
            elseif horseData.beauty and horseData.beauty.buildAHorse then
                -- Backwards compatibility with old beauty.buildAHorse saves
                savedBAHorse = horseData.beauty.buildAHorse
            end
        end

        if savedBAHorse and CoalBuildAHorse and CoalBuildAHorse.ApplySavedToPed then
            CoalBuildAHorse.ApplySavedToPed(horse, savedBAHorse)
        end
    end

    -- Apply Build-A-Tack save, if this horse has one (new appearance structure)
    do
        local savedBATack = nil
        if horseData then
            if horseData.appearance and horseData.appearance.buildATack then
                -- Preferred: new appearance.buildATack structure
                savedBATack = horseData.appearance.buildATack
            elseif horseData.beauty and horseData.beauty.buildATack then
                -- Backwards compatibility with old beauty.buildATack saves
                savedBATack = horseData.beauty.buildATack
            end
        end

        if savedBATack and CoalBuildATack and CoalBuildATack.ApplySavedToPed then
            CoalBuildATack.ApplySavedToPed(horse, savedBATack)
        end
    end


    -- Health + stamina (keep your numbers)
    local baseHealth  = 200.0
    local baseStamina = 200.0

    SetEntityMaxHealth(horse, math.floor(baseHealth * (horseData.health or 1.0)))
    SetEntityHealth(horse,     math.floor(baseHealth * (horseData.health or 1.0)))
    -- (keep any attribute code you had here)

     -- 8) Warp into final position & heading on the ground
    SetEntityCoordsNoOffset(horse, spawnPos.x, spawnPos.y, spawnZ, false, false, false)
    SetEntityHeading(horse, spawnHeading)

    -- Owned horse: let it behave like a normal mount (no special blocking here)
    -- (If you really want a tiny “spawn protection” you could make it invincible
    --  for a moment, but don't block non-temporary events.)

    SetModelAsNoLongerNeeded(model)

        -- Remember this as our current owned horse
    currentOwnedHorse     = horse
    currentOwnedHorseData = horseData

    -- 9) Reveal AFTER a short delay, then let it move
    local horseRef = horse
    CreateThread(function()
        -- small delay so physics/outfit fully settle, just like preview
        Wait(250)

        if DoesEntityExist(horseRef) then
            SetEntityVisible(horseRef, true)
            FreezeEntityPosition(horseRef, false)
        end
    end)
end)

--------------------------------------------
--------------------------------------------
--------------------------------------------
--------------------------------------------

ClearPreviewHorse = function()
    if previewHorse and DoesEntityExist(previewHorse) then
        DeletePed(previewHorse)
    end
    previewHorse = nil
    previewRotationOffset = 0.0
end

local function GetCoatLabelFromEntry(entry)
    if not entry or (type(entry.id) == "string" and entry.id:sub(1, 7) == "__owned") then
        return "Current Coat"
    end

    -- Decide which model is actually in use
    local modelName
    if entry._ownedRaw and entry._ownedRaw.model then
        modelName = entry._ownedRaw.model
    elseif entry.models and entry.modelIndex then
        modelName = entry.models[entry.modelIndex] or entry.models[1]
    else
        modelName = entry.model
    end


    if entry.models and entry.modelIndex then
        modelName = entry.models[entry.modelIndex] or entry.models[1]
    else
        modelName = entry.model
    end

    if not modelName then
        return "Unknown"
    end

    -- normalize
    local lower = string.lower(modelName)
    lower = lower:gsub("^a_c_horse_", "")  -- strip prefix if present

    -- everything after the first "_" we treat as the coat
    local firstUnderscore = lower:find("_")
    if not firstUnderscore then
        return "Unknown"
    end

    local coatPart = lower:sub(firstUnderscore + 1) -- e.g. "bayroan", "black_snowflake"
    coatPart = coatPart:gsub("_", " ")

    -- Title-case each word
    coatPart = coatPart:gsub("(%a)(%w*)", function(first, rest)
        return first:upper() .. rest
    end)

    return coatPart
end

function SpawnPreviewHorse(horseData, myToken)
    -- If this isn't the latest request anymore, ignore it
    if myToken and myToken ~= previewSpawnToken then
        return
    end

    ClearPreviewHorse()
    if not horseData then return end

    local isOwnedPreview = (type(horseData.id) == "string" and horseData.id:sub(1, 7) == "__owned")

    -- Decide which model is actually in use
    local modelName
    if isOwnedPreview and horseData._ownedRaw and horseData._ownedRaw.model then
        modelName = horseData._ownedRaw.model
    elseif horseData.models and horseData.modelIndex then
        modelName = horseData.models[horseData.modelIndex] or horseData.models[1]
    else
        modelName = horseData.model
    end

    if not modelName then return end

    local model = GetHashKey(modelName)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end

    local ped = PlayerPedId()

    -- Use the cached anchor if we have one; otherwise set it once now
    if not previewAnchorPos then
        SetPreviewAnchorAtPlayer()
    end

    local spawnPos = previewAnchorPos

    -- Final heading we want (horse facing to your right)
    local heading = previewAnchorHeading or (GetEntityHeading(ped) + 90.0)
    if heading >= 360.0 then
        heading = heading - 360.0
    end

    -- Smart Z logic for interiors / exteriors
    local baseZ  = spawnPos.z
    local spawnZ = baseZ

    local foundGround, groundZ = GetGroundZAndNormalFor_3dCoord(spawnPos.x, spawnPos.y, baseZ + 2.0)
    if foundGround then
        if groundZ > baseZ - 0.3 then
            -- Real floor (within ~0.3 below feet)
            spawnZ = groundZ + 0.05
        else
            -- Ignore far-below world ground under interiors
            spawnZ = baseZ + 0.01
        end
    else
        spawnZ = baseZ + 0.01
    end

    -- Create the horse offscreen so we never see setup flicker
    local offscreenZ = spawnZ - 80.0
    local horse = CreatePed(model, spawnPos.x, spawnPos.y, offscreenZ, heading, false, false, false, false)
    if horse == 0 then
        print(("[coal_stables] Failed to create PREVIEW horse for model %s"):format(modelName))
        return
    end

    -- Completely hide & freeze while we set everything up
    SetEntityVisible(horse, false)
    FreezeEntityPosition(horse, true)

    -- Make sure it has a proper outfit and is clean
    ApplyHorseOutfit(horse)

-- 🔥 NEW: Completely disable idle animations AFTER outfit is applied
ClearPedTasksImmediately(horse)                 -- kill any tasks
SetBlockingOfNonTemporaryEvents(horse, true)    -- stop ambient AI
--Citizen.InvokeNative(0x3488AB99A0ECCD44, horse, true)  -- disable behavior/anim graph

-- ONLY apply your tack / beauty if this is your owned preview horse
if isOwnedPreview then
    ApplyAllEquippedTack(horse)
    ApplyAllEquippedBeauty(horse)

    -- 🔹 Apply Build-A-Horse save, if this horse has one
    local savedBuild = nil

    -- 1) direct on the entry (if ever set there)
    if horseData.beauty and horseData.beauty.buildAHorse then
        savedBuild = horseData.beauty.buildAHorse
    -- 2) fallback: use the raw owned data we tucked under _ownedRaw
    elseif horseData._ownedRaw
        and horseData._ownedRaw.beauty
        and horseData._ownedRaw.beauty.buildAHorse then

        savedBuild = horseData._ownedRaw.beauty.buildAHorse
    end

    if savedBuild and CoalBuildAHorse and CoalBuildAHorse.ApplySavedToPed then
        CoalBuildAHorse.ApplySavedToPed(horse, savedBuild)
    end

    -- 🔹 Apply Build-A-Tack save, if this horse has one
    local savedTack = nil

    -- 1) direct on the entry (if ever set there)
    if horseData.beauty and horseData.beauty.buildATack then
        savedTack = horseData.beauty.buildATack
    -- 2) fallback: use the raw owned data we tucked under _ownedRaw
    elseif horseData._ownedRaw
        and horseData._ownedRaw.beauty
        and horseData._ownedRaw.beauty.buildATack then

        savedTack = horseData._ownedRaw.beauty.buildATack
    end

    if savedTack and CoalBuildATack and CoalBuildATack.ApplySavedToPed then
        CoalBuildATack.ApplySavedToPed(horse, savedTack)
    end
end

    --

    -- Teleport into final position & heading near the player
    SetEntityCoordsNoOffset(horse, spawnPos.x, spawnPos.y, spawnZ, false, false, false)
    SetEntityHeading(horse, heading)

    -- Prevent camera from snapping toward the new horse for a few frames
    SetEntityNoCollisionEntity(PlayerPedId(), horse, true)
    SetPedResetFlag(PlayerPedId(), 240, true)  -- prevents camera lock-on
    Citizen.CreateThread(function()
        local t = GetGameTimer()
        while GetGameTimer() - t < 300 do
            DisableControlAction(0, 0xD2047988, true) -- camera lock-on
            DisableControlAction(0, 0x3C3DD371, true) -- aim tracking
            Wait(0)
        end
    end)

    -- Make it invincible / non-reactive
    SetEntityCanBeDamaged(horse, false)
    SetEntityInvincible(horse, true)
    SetBlockingOfNonTemporaryEvents(horse, true)

    -- Decide how long to wait BEFORE showing the horse (but do it async)
    local delay = 0
    if isOwnedPreview then
        delay = 250         -- owned horse preview: longer settle
    elseif not previewHorseSpawnedOnce then
        delay = 250         -- first-ever preview: longer settle
    end

    if not previewHorseSpawnedOnce then
        previewHorseSpawnedOnce = true
    end

    -- If another preview was requested while we were loading,
    -- don't overwrite it with this older one.
    if myToken and myToken ~= previewSpawnToken then
        if DoesEntityExist(horse) then
            DeletePed(horse)
        end
        return
    end

      previewHorse = horse
    SetModelAsNoLongerNeeded(model)

    -- 🔹 Async visibility: don't block the menu thread
    local horseRef = horse
    CreateThread(function()
        if delay > 0 then
            Wait(delay)
        end
        if DoesEntityExist(horseRef) then
            SetEntityVisible(horseRef, true)
        end
    end)
end

---------------------------------
-- First screen: choose between Stables Store and Stables
local function OpenLiveryMenu(stableId, isLaw, isOutlaw)
    if stableMainMenuOpen or stableMenuOpen then return end

    lastStableId   = stableId
    lastIsLaw      = isLaw or false
    lastIsOutlaw   = isOutlaw or false
    stableMainMenuOpen    = true
    stableMainMenuSelected = 1

    -- Lock in the preview anchor once when livery opens
    SetPreviewAnchorAtPlayer()
end
---------------------------------
---------------------------------
-- When player presses E at a stable:
-- Opens the horse list (store OR stables), called from the main livery menu
function OpenStableMenu(stableId, mode)
    if stableMenuOpen then return end

    lastStableId = stableId
    stableMenuMode = mode or "store"  -- "store" or "stables"

    TriggerServerEvent("coal_stables:requestHorses", {
        law = lastIsLaw,
        outlaw = lastIsOutlaw,
        includeNonLaw = true,
        includeNonOutlaw = true,
    })
end


--[[ LEGACY single-horse receiveHorses handler (disabled; multi-horse version above)
RegisterNetEvent("coal_stables:receiveHorses", function(horses, ownedHorse)
    horses = horses or {}

    -- STORE MODE: show all buyable horses (no Select at the top)
    if stableMenuMode == "store" or stableMenuMode == nil then
        if #horses == 0 then
            print("[coal_stables] No horses available for sale.")
            return
        end

        stableMenuHorses = {}

        for _, h in ipairs(horses) do
            local entry = h
            entry.modelIndex = 1  -- start at first coat
            table.insert(stableMenuHorses, entry)
        end

        stableMenuSelected   = 1
        stableMenuOpen       = true
        stableMainMenuOpen   = false

        QueuePreviewHorse(stableMenuHorses[stableMenuSelected])
        print("[coal_stables] STORE menu opened with " .. #stableMenuHorses .. " entries.")
        return
    end

    -- STABLES MODE: only show horses we can select (currently 1 owned horse)
    if stableMenuMode == "stables" then
        if not ownedHorse then
            TriggerEvent("vorp:TipBottom", "You don't own a horse yet.", 4000)
            stableMenuOpen     = false
            stableMainMenuOpen = false
            ClearPreviewHorse()
            return
        end

           stableMenuHorses = {
        {
            id        = "__owned__",
            name      = "Select: " .. (ownedHorse.name or "Your Horse"),
            price     = 0,
            tierLabel = ownedHorse.tierLabel or "Owned Mount",
            speed     = ownedHorse.speed,
            health    = ownedHorse.health,
            stamina   = ownedHorse.stamina,
            _ownedRaw = ownedHorse,
        }
    }

    -- 🔹 remember this so Tack & Services can spawn a preview later
    currentOwnedHorseData = ownedHorse
--
    -- Sync equipped tack / beauty from server data (for preview & spawn)
-- Sync equipped tack / beauty from server data (for preview & spawn)
if ownedHorse.tack and type(ownedHorse.tack) == "table" then
    -- reset then copy
    equippedTack = {
        -- base categories
        saddles        = nil,
        blankets       = nil,
        stirrups       = nil,
        bedrolls       = nil,
        bridles        = nil,
        harness        = nil,
        saddlebags     = nil,
        holsters       = nil,

        -- generic tints
        saddle_tint    = nil,
        bridle_tint    = nil,
        stirrup_tint   = nil,
        horn_tint      = nil,

        -- saddlebag tints (3 channels)
        saddlebags_tint0 = nil,
        saddlebags_tint1 = nil,
        saddlebags_tint2 = nil,

        -- bedroll tints (3 channels)
        bedroll_tint0  = nil,
        bedroll_tint1  = nil,
        bedroll_tint2  = nil,

        -- holsters tints (3 channels)
        holsters_tint0  = nil,
        holsters_tint1  = nil,
        holsters_tint2  = nil,
    }

    -- copy whatever the server sent (including old saves that
    -- might be missing some of the new keys)
    for k, v in pairs(ownedHorse.tack) do
        equippedTack[k] = v
    end
end

-- legacy one-channel -> three-channel migration for saddlebags
if equippedTack["saddlebags_tint"]
   and not (equippedTack["saddlebags_tint0"]
        or  equippedTack["saddlebags_tint1"]
        or  equippedTack["saddlebags_tint2"]) then

    local legacy = equippedTack["saddlebags_tint"]
    equippedTack["saddlebags_tint0"] = legacy
    equippedTack["saddlebags_tint1"] = legacy
    equippedTack["saddlebags_tint2"] = legacy
end

------------------


if ownedHorse.beauty and type(ownedHorse.beauty) == "table" then
    -- reset then copy, including all known beauty slots
equippedBeauty = {
    manes        = nil,
    tails        = nil,
    hoof_feather = nil,
    mane_colors  = nil,
    tail_colors  = nil,

    HorseBody    = nil,
    HorseHead    = nil,
}

    for k, v in pairs(ownedHorse.beauty) do
        equippedBeauty[k] = v
    end
end


    --
    stableMenuSelected   = 1

        stableMenuOpen       = true
        stableMainMenuOpen   = false

        QueuePreviewHorse(stableMenuHorses[1])
        print("[coal_stables] STABLES menu opened with 1 owned horse.")
        return
    end
end)
--]]  -- end legacy receiveHorses handler block



--=====================================================================
--  SIMPLE HORSE BUY MENU (NO NUI)
--=====================================================================

local controlUp    = 0x6319DB71 -- INPUT_FRONTEND_UP
local controlDown  = 0x05CA7C52 -- INPUT_FRONTEND_DOWN
local controlAccept= 0xC7B5340A -- INPUT_FRONTEND_ACCEPT (Enter)
local controlBack  = 0x156F7119 -- INPUT_FRONTEND_CANCEL (Back)
local controlLeft  = 0xA65EBAB4 -- INPUT_FRONTEND_LEFT
local controlRight = 0xDEB34313 -- INPUT_FRONTEND_RIGHT
-----------------
-- =========================================
-- KEY REPEAT FOR NAVIGATION (UP/DOWN/LEFT/RIGHT)
-- =========================================
local NAV_INITIAL_DELAY = 140  -- ms before first repeat
local NAV_REPEAT_DELAY  = 45  -- ms between repeats

local navStates = {
    [controlUp]    = { pressed = false, repeating = false, lastTime = 0 },
    [controlDown]  = { pressed = false, repeating = false, lastTime = 0 },
    [controlLeft]  = { pressed = false, repeating = false, lastTime = 0 },
    [controlRight] = { pressed = false, repeating = false, lastTime = 0 },
}

local function IsNavRepeat(control)
    local state = navStates[control]
    if not state then
        -- Fallback, should never really hit
        return IsControlJustPressed(0, control)
    end

    local now = GetGameTimer()

    if IsControlPressed(0, control) then
        if not state.pressed then
            -- Fresh press: fire once immediately
            state.pressed   = true
            state.repeating = false
            state.lastTime  = now
            return true
        end

        -- Already held: check repeat timing
        local delay = state.repeating and NAV_REPEAT_DELAY or NAV_INITIAL_DELAY
        if now - state.lastTime >= delay then
            state.lastTime  = now
            state.repeating = true
            return true
        end
    else
        -- Released: clear state
        state.pressed   = false
        state.repeating = false
    end

    return false
end
-----------------
-- Top-level Livery menu: choose between Store and Stables
local function DrawLiveryMenu()

    local listX     = 0.003
    local listY     = 0.003
    local lineStep  = 0.035

    local boxWidth  = 0.23
    local boxHeight = 0.026

    ---------------------------------------------------
    -- ENTRIES
    ---------------------------------------------------
local entries = {
    "Stables",
    "Stables Store",
    "Build-A-Tack Workshop",
    "Build-A-Horse Workshop",
}



    for i, label in ipairs(entries) do
        local isSelected = (i == stableMainMenuSelected)
        local rowY       = listY + (i - 1) * lineStep

        local boxCenterX = listX + (boxWidth / 2.0)
        local boxCenterY = rowY + (boxHeight / 2.0)

        if isSelected then
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 40, 40, 40, 200)
            DrawRect(boxCenterX, boxCenterY, boxWidth + 0.002, boxHeight + 0.002, 180, 30, 30, 90)
        else
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 0, 0, 0, 160)
        end

        SetTextScale(0.40, 0.40)
        SetTextFontForCurrentCommand(1)
        if isSelected then
            SetTextColor(255, 255, 200, 255)
        else
            SetTextColor(220, 220, 220, 255)
        end
        SetTextCentre(false)
        DisplayText(
            CreateVarString(10, "LITERAL_STRING", label),
            listX + 0.003,
            rowY + 0.003
        )
    end

    ---------------------------------------------------
    -- FOOTER
    ---------------------------------------------------
    SetTextScale(0.34, 0.34)
    SetTextFontForCurrentCommand(1)
    SetTextColor(255, 255, 255, 255)
    SetTextCentre(true)
    DisplayText(
        CreateVarString(10, "LITERAL_STRING", "↑/↓ NAVIGATE  |  ENTER SELECT  |  BACKSPACE BACK"),
        0.5,
        0.97
    )
end
-----------------
local function DrawStableMenu()
    ---------------------------------------------------
    -- LAYOUT TWEAKS – these 4 values are the main ones
    ---------------------------------------------------

    local listX     = 0.003  -- left edge of list
    local listY     = 0.003   -- first row Y
    local lineStep  = 0.031  -- vertical spacing

    local boxWidth  = 0.23
    local boxHeight = 0.026

    ---------------------------------------------------
    -- TOP-CENTER HORSE DETAILS
    ---------------------------------------------------
    local selected = stableMenuHorses[stableMenuSelected]
    if selected then
        local infoY = 0.002

        local bigName = tostring(selected.name or "Horse")
        SetTextScale(0.50, 0.50)
        SetTextFontForCurrentCommand(1)
        SetTextColor(255, 255, 200, 255)
        SetTextCentre(true)
        DisplayText(
            CreateVarString(10, "LITERAL_STRING", bigName),
            0.55,
            infoY
        )

        -- local tier = string.format("(%s)", selected.tierLabel or "Unknown")
        -- SetTextScale(0.40, 0.40)
        -- SetTextFontForCurrentCommand(1)
        -- SetTextColor(190, 190, 190, 255)
        -- SetTextCentre(true)
        -- DisplayText(
        --    CreateVarString(10, "LITERAL_STRING", tier),
        --    0.55,
        --    infoY + 0.03
        --)

        local coatLabel = GetCoatLabelFromEntry(selected)
        local coatLine  = string.format("%s", string.upper(coatLabel))
        SetTextScale(0.35, 0.35)
        SetTextFontForCurrentCommand(1)
        SetTextColor(200, 200, 230, 255)
        SetTextCentre(true)
        DisplayText(
            CreateVarString(10, "LITERAL_STRING", coatLine),
            0.55,
            infoY + 0.03
        )

        local statsLine = string.format(
            "SPD %.0f  HP %.0f  STM %.0f",
            selected.speed  * 100,
            selected.health * 100,
            selected.stamina* 100
        )
        SetTextScale(0.35, 0.35)
        SetTextFontForCurrentCommand(1)
        SetTextColor(160, 220, 160, 255)
        SetTextCentre(true)
        DisplayText(
            CreateVarString(10, "LITERAL_STRING", statsLine),
            0.55,
            infoY + 0.06
        )
    end

    ---------------------------------------------------
    -- LEFT LIST (WITH BOXES)
    ---------------------------------------------------
    for i, h in ipairs(stableMenuHorses) do
        local isSelected = (i == stableMenuSelected)
        local rowY       = listY + (i - 1) * lineStep

        local boxCenterX = listX + (boxWidth / 2.0)
        local boxCenterY = rowY + (boxHeight / 2.0)

        if isSelected then
            -- grey fill
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 40, 40, 40, 200)
            -- subtle red-ish border
            DrawRect(boxCenterX, boxCenterY, boxWidth + 0.002, boxHeight + 0.002, 180, 30, 30, 90)
        else
            DrawRect(boxCenterX, boxCenterY, boxWidth, boxHeight, 0, 0, 0, 160)
        end

        local label = string.upper(tostring(h.name or "Horse"))

        SetTextScale(0.40, 0.40)
        SetTextFontForCurrentCommand(1)
        if isSelected then
            SetTextColor(255, 255, 200, 255)
        else
            SetTextColor(220, 220, 220, 255)
        end
        SetTextCentre(false)
        DisplayText(
            CreateVarString(10, "LITERAL_STRING", label),
            listX + 0.01,
            rowY + 0.003
        )
    end

    ---------------------------------------------------
    -- FOOTER HINT (BOTTOM CENTER)
    ---------------------------------------------------
    SetTextScale(0.34, 0.34)
    SetTextFontForCurrentCommand(1)
    SetTextColor(255, 255, 255, 255)
    SetTextCentre(true)
    DisplayText(
        CreateVarString(
            10,
            "LITERAL_STRING",
            "↑/↓ NAVIGATE  |  ←/→ COAT  |  ENTER SELECT  |  BACKSPACE BACK"
        ),
        0.5,
        0.97
    )
end
----------------------------

----------------------------

-- Main menu loop (draw + inputs + distance auto-close)

--=====================================================================
-- VORP / Feather-style menu conversion
-- Replaces frame-drawn Coal menus with vorp_menu, like vorp_stores.
--=====================================================================
local function __CoalMenuCloseAll()
    MenuData.CloseAll()
    stableMainMenuOpen = false
    stableMenuOpen = false
    tackCategoryMenuOpen = false
    beautyCategoryMenuOpen = false
    bruteforceMenuOpen = false
    buildAHorseMenuOpen = false
    buildATackMenuOpen = false
end

local function __CoalMenuBackToMain()
    __CoalMenuCloseAll()
    OpenLiveryMenu(lastStableId, lastIsLaw, lastIsOutlaw)
end

local function __CoalEntryLabel(entry)
    if not entry then return "Horse" end
    local label = entry.name or entry.label or entry.id or "Horse"
    if entry.models and #entry.models > 1 then
        label = ("%s  [%s/%s]"):format(label, tostring(entry.modelIndex or 1), tostring(#entry.models))
    end
    return label
end

local function __CoalSyncOwnedHorse(chosen, slot)
    if not chosen then return end
    currentOwnedHorseData = chosen._ownedRaw or chosen
    if currentOwnedHorseData then
        currentOwnedHorseData._slot = slot or chosen._slot or currentOwnedHorseData._slot or 1
    end

    equippedTack = {}
    if currentOwnedHorseData and currentOwnedHorseData.tack and type(currentOwnedHorseData.tack) == "table" then
        for k, v in pairs(currentOwnedHorseData.tack) do equippedTack[k] = v end
    end

    if equippedTack["saddlebags_tint"] and not (equippedTack["saddlebags_tint0"] or equippedTack["saddlebags_tint1"] or equippedTack["saddlebags_tint2"]) then
        local legacy = equippedTack["saddlebags_tint"]
        equippedTack["saddlebags_tint0"] = legacy
        equippedTack["saddlebags_tint1"] = legacy
        equippedTack["saddlebags_tint2"] = legacy
    end

    equippedBeauty = {}
    if currentOwnedHorseData and currentOwnedHorseData.beauty and type(currentOwnedHorseData.beauty) == "table" then
        for k, v in pairs(currentOwnedHorseData.beauty) do equippedBeauty[k] = v end
    end
end

local function __CoalOpenStableListVorpMenu(mode)
    __CoalMenuCloseAll()
    local elements = {}

    if not stableMenuHorses or #stableMenuHorses == 0 then
        TriggerEvent("vorp:TipBottom", "No horses found.", 4000)
        return __CoalMenuBackToMain()
    end

    for i, h in ipairs(stableMenuHorses) do
        elements[#elements + 1] = {
            label = __CoalEntryLabel(h),
            value = i,
            desc = ("Tier: %s<br>Speed: %s<br>Health: %s<br>Stamina: %s<br><br>Enter to %s."):format(
                tostring(h.tierLabel or "Horse"),
                tostring(h.speed or 1.0),
                tostring(h.health or 1.0),
                tostring(h.stamina or 1.0),
                mode == "store" and "buy" or "select"
            )
        }
    end

    MenuData.Open('default', GetCurrentResourceName(), 'coal_stables_horse_list', {
        title = mode == "store" and "Horse Store" or "Your Horses",
        subtext = "Coal Stables",
        align = "top-left",
        elements = elements,
        itemHeight = "4vh",
    }, function(data, menu)
        local idx = tonumber(data.current.value or 1) or 1
        local chosen = stableMenuHorses[idx]
        if not chosen then return end
        stableMenuSelected = idx
        QueuePreviewHorse(chosen)

        if mode == "stables" then
            __CoalSyncOwnedHorse(chosen, chosen._slot or idx)
            TriggerServerEvent("coal_stables:selectMainHorse", lastStableId, chosen._slot or idx)
            TriggerEvent("vorp:TipBottom", "Horse selected.", 3000)
            return __CoalMenuBackToMain()
        end

        local chosenModel
        if chosen.models and chosen.modelIndex then
            chosenModel = chosen.models[chosen.modelIndex] or chosen.models[1]
        else
            chosenModel = chosen.model
        end

        TriggerServerEvent("coal_stables:buyHorse", chosen.id, lastStableId, chosenModel)
        currentOwnedHorseData = {
            name      = chosen.name,
            tierLabel = chosen.tierLabel or "Owned Mount",
            speed     = chosen.speed or 1.0,
            health    = chosen.health or 1.0,
            stamina   = chosen.stamina or 1.0,
            model     = chosenModel,
            tack      = equippedTack,
            beauty    = equippedBeauty,
        }
        TriggerEvent("vorp:TipBottom", "Horse purchased.", 3000)
        return __CoalMenuBackToMain()
    end, function(data, menu)
        ClearPreviewHorse()
        __CoalMenuBackToMain()
    end)
end

function __CoalVorpMenuOnReceiveHorses(horses, ownedData)
    horses = horses or {}
    local ownedList = {}

    if type(ownedData) == "table" then
        if ownedData.id and ownedData.name then
            ownedList[#ownedList + 1] = ownedData
        else
            for _, h in ipairs(ownedData) do
                if type(h) == "table" and h.id then
                    ownedList[#ownedList + 1] = h
                end
            end
        end
    end

    stableMenuHorses = {}

    if stableMenuMode == "store" or stableMenuMode == nil then
        for _, h in ipairs(horses) do
            local entry = h
            entry.modelIndex = 1
            stableMenuHorses[#stableMenuHorses + 1] = entry
        end
        stableMenuSelected = 1
        if stableMenuHorses[1] then QueuePreviewHorse(stableMenuHorses[1]) end
        return __CoalOpenStableListVorpMenu("store")
    end

    if stableMenuMode == "stables" then
        if #ownedList == 0 then
            TriggerEvent("vorp:TipBottom", "You don't own a horse yet.", 4000)
            ClearPreviewHorse()
            return __CoalMenuBackToMain()
        end

        local mainIndex = 1
        for idx, h in ipairs(ownedList) do
            local isMain = (h.isMain == true)
            if isMain then mainIndex = idx end
            local entryName = h.name or ("Horse #" .. tostring(idx))
            if isMain then entryName = "★ " .. entryName end
            stableMenuHorses[#stableMenuHorses + 1] = {
                id = "__owned_" .. tostring(h._slot or idx),
                name = entryName,
                price = 0,
                tierLabel = h.tierLabel or "Owned Mount",
                speed = h.speed or 1.0,
                health = h.health or 1.0,
                stamina = h.stamina or 1.0,
                _ownedRaw = h,
                _slot = h._slot or idx,
                _isMain = isMain,
            }
        end

        stableMenuSelected = mainIndex
        __CoalSyncOwnedHorse(stableMenuHorses[mainIndex], mainIndex)
        QueuePreviewHorse(stableMenuHorses[mainIndex])
        return __CoalOpenStableListVorpMenu("stables")
    end
end

local function __CoalSaveBeautyAndReturn()
    local hasManeChoice, chosenManeCat = false, nil
    for _, catId in ipairs(maneColorCategories) do
        if pendingBeauty[catId] then hasManeChoice = true; chosenManeCat = catId end
    end
    if hasManeChoice then
        for _, catId in ipairs(maneColorCategories) do if catId ~= chosenManeCat then equippedBeauty[catId] = nil end end
    end

    local hasTailChoice, chosenTailCat = false, nil
    for _, catId in ipairs(tailColorCategories) do
        if pendingBeauty[catId] then hasTailChoice = true; chosenTailCat = catId end
    end
    if hasTailChoice then
        for _, catId in ipairs(tailColorCategories) do if catId ~= chosenTailCat then equippedBeauty[catId] = nil end end
    end

    for catId, itemId in pairs(pendingBeauty) do equippedBeauty[catId] = itemId end

    if currentOwnedHorseData then
        currentOwnedHorseData.beauty = equippedBeauty
        local slot = currentOwnedHorseData and currentOwnedHorseData._slot or nil
        TriggerServerEvent("coal_stables:updateHorseAppearance", slot, nil, equippedBeauty)
    end

    TriggerEvent("vorp:TipBottom", "Beauty & Grooming updated.", 3000)
    ClearPreviewHorse()
    __CoalMenuBackToMain()
end

local function __CoalSaveBuildAHorseAndReturn()
    if currentOwnedHorseData then
        local appearance = currentOwnedHorseData.appearance or {}
        appearance.buildAHorse = appearance.buildAHorse or {}
        appearance.buildAHorse.body = buildAHorseBodyDebug
        appearance.buildAHorse.hair = buildAHorseHairState
        appearance.buildAHorse.scale = buildAHorseScale

        local hfId = buildAHorseSelection and buildAHorseSelection["hoof_feather"] or nil
        if hfId ~= nil then appearance.buildAHorse.hoof_feather = { id = hfId } else appearance.buildAHorse.hoof_feather = nil end

        currentOwnedHorseData.appearance = appearance
        local slot = currentOwnedHorseData and currentOwnedHorseData._slot or nil
        TriggerServerEvent("coal_stables:updateHorseAppearance", slot, nil, appearance)
    end

    TriggerEvent("vorp:TipBottom", "Build-A-Horse saved.", 3000)
    ClearPreviewHorse()
    __CoalMenuBackToMain()
end

local function __CoalSaveBuildATackAndReturn()
    if currentOwnedHorseData then
        local appearance = currentOwnedHorseData.appearance or {}
        appearance.buildATack = buildATackState
        currentOwnedHorseData.appearance = appearance
        local slot = currentOwnedHorseData and currentOwnedHorseData._slot or nil
        TriggerServerEvent("coal_stables:updateHorseAppearance", slot, nil, appearance)
    end

    TriggerEvent("vorp:TipBottom", "Build-A-Tack saved.", 3000)
    __CoalMenuBackToMain()
end

local function __CoalOpenCategorySliderMenu(title, categories, getItems, getIndex, setIndex, onApply, onSave, onCancel)
    __CoalMenuCloseAll()
    local elements = {}

    for _, cat in ipairs(categories or {}) do
        local items = getItems(cat.id) or {}
        if #items > 0 then
            local idx = getIndex(cat.id)
            if idx < 1 then idx = 1 end
            if idx > #items then idx = #items end
            local item = items[idx]
            elements[#elements + 1] = {
                label = tostring(cat.label or cat.id),
                value = idx,
                min = 1,
                max = #items,
                type = "slider",
                action = "change",
                catId = cat.id,
                desc = ("Current: %s<br><br>Move slider to preview."):format(tostring((item and item.label) or idx)),
            }
        end
    end

    elements[#elements + 1] = {
        label = "SAVE",
        value = "save",
        desc = "Save changes and return."
    }

    MenuData.Open('default', GetCurrentResourceName(), 'coal_' .. title:gsub("%W", "_"), {
        title = title,
        subtext = "Coal Stables",
        align = "top-left",
        elements = elements,
        itemHeight = "4vh",
    }, function(data, menu)
        if data.current.value == "save" then
            return onSave()
        end

        if data.current.action == "change" then
            local catId = data.current.catId
            local idx = tonumber(data.current.value or 1) or 1
            setIndex(catId, idx)
            local items = getItems(catId) or {}
            local item = items[idx]
            if item then onApply(catId, item) end

            for key, element in pairs(menu.data.elements) do
                if element.catId == catId then
                    menu.setElement(key, "desc", ("Current: %s<br><br>Move slider to preview."):format(tostring(item.label or idx)))
                    menu.refresh()
                    break
                end
            end
        end
    end, function(data, menu)
        if onCancel then onCancel() else __CoalMenuBackToMain() end
    end)
end

-- Override Coal's old frame-drawn livery menu

local function __CoalOpenHorseGenderMenu()
    if not currentOwnedHorseData then
        TriggerEvent("vorp:TipBottom", "Select one of your horses first.", 3500)
        return __CoalMenuBackToMain()
    end

    local horseId = tonumber(currentOwnedHorseData.id or (currentOwnedHorseData._ownedRaw and currentOwnedHorseData._ownedRaw.id))
    if not horseId then
        TriggerEvent("vorp:TipBottom", "Could not find this horse ID.", 3500)
        return __CoalMenuBackToMain()
    end

    local current = tostring(currentOwnedHorseData.gender or (currentOwnedHorseData._ownedRaw and currentOwnedHorseData._ownedRaw.gender) or "male"):lower()
    local currentLabel = (current == "female" or current == "mare") and "Mare" or "Stallion"

    MenuData.Open('default', GetCurrentResourceName(), 'coal_horse_gender', {
        title = "Horse Gender",
        subtext = "Current: " .. currentLabel,
        align = "top-left",
        elements = {
            { label = "Set As Mare", value = "female", desc = "Use this horse as a mare in breeding." },
            { label = "Set As Stallion", value = "male", desc = "Use this horse as a stallion/stud in breeding." },
            { label = "Back", value = "back", desc = "Return to Coal Stables." },
        },
        itemHeight = "4vh",
    }, function(data, menu)
        local val = data.current.value
        if val == "back" then
            return __CoalMenuBackToMain()
        end
        TriggerServerEvent("coal_bcc:SetHorseGender", horseId, val)
        currentOwnedHorseData.gender = val
        if currentOwnedHorseData._ownedRaw then currentOwnedHorseData._ownedRaw.gender = val end
        TriggerEvent("vorp:TipBottom", "Horse gender set to " .. (val == "female" and "Mare" or "Stallion") .. ".", 3000)
        __CoalMenuBackToMain()
    end, function(data, menu)
        __CoalMenuBackToMain()
    end)
end

OpenLiveryMenu = function(stableId, isLaw, isOutlaw)
    lastStableId = stableId
    lastIsLaw = isLaw or false
    lastIsOutlaw = isOutlaw or false
    __CoalMenuCloseAll()

    local elements = {
        { label = "Your Horses", value = "stables", desc = "Select your main horse." },
        { label = "Horse Store", value = "store", desc = "Buy a horse." },
        { label = "Build-A-Tack", value = "build_tack", desc = "Customize tack with VORP menu sliders." },
        { label = "Build-A-Horse", value = "build_horse", desc = "Customize body, hair, scale, and coat pieces." },
        { label = "Beauty & Grooming", value = "beauty", desc = "Mane, tail, and grooming options." },
        { label = "Horse Gender", value = "gender", desc = "Set selected horse as a mare or stallion." },
    }

    MenuData.Open('default', GetCurrentResourceName(), 'coal_livery_main', {
        title = "Coal Stables",
        subtext = "VORP Menu",
        align = "top-left",
        elements = elements,
        itemHeight = "4vh",
    }, function(data, menu)
        if data.current.value == "stables" then
            return OpenStableMenu(lastStableId, "stables")
        elseif data.current.value == "store" then
            return OpenStableMenu(lastStableId, "store")
        elseif data.current.value == "build_tack" then
            return OpenBuildATackMenu()
        elseif data.current.value == "build_horse" then
            return OpenBuildAHorseMenu()
        elseif data.current.value == "beauty" then
            return OpenBeautyMenu()
        elseif data.current.value == "gender" then
            return __CoalOpenHorseGenderMenu()
        end
    end, function(data, menu)
        MenuData.CloseAll()
        ClearPreviewHorse()
    end)
end

OpenTackCategoryMenu = function()
    if not CoalTack or not CoalTack.GetCategories then return end
    tackCategories = CoalTack.GetCategories()
    pendingTack = {}
    __CoalOpenCategorySliderMenu(
        "Tack & Services",
        tackCategories,
        function(catId) return CoalTack.GetItemsForCategory(catId) or {} end,
        function(catId) return tackItemIndexByCategory[catId] or 1 end,
        function(catId, idx) tackItemIndexByCategory[catId] = idx end,
        function(catId, item)
            pendingTack[catId] = item.id
            ApplyPendingTackToPreview()
        end,
        function()
            local finalTack = {}
            if equippedTack then for k, v in pairs(equippedTack) do finalTack[k] = v end end
            for catId, itemId in pairs(pendingTack) do finalTack[catId] = itemId end
            equippedTack = finalTack
            if currentOwnedHorseData then
                currentOwnedHorseData.tack = finalTack
                local slot = currentOwnedHorseData and currentOwnedHorseData._slot or nil
                TriggerServerEvent("coal_stables:updateHorseAppearance", slot, finalTack, nil)
            end
            TriggerEvent("vorp:TipBottom", "Horse tack updated.", 3000)
            ClearPreviewHorse()
            __CoalMenuBackToMain()
        end,
        function()
            pendingTack = {}
            ClearPreviewHorse()
            __CoalMenuBackToMain()
        end
    )
end

local __OldOpenBeautyMenu = OpenBeautyMenu
OpenBeautyMenu = function()
    __OldOpenBeautyMenu()
    if not beautyCategoryMenuOpen then return end
    beautyCategoryMenuOpen = false
    __CoalOpenCategorySliderMenu(
        "Beauty & Grooming",
        beautyCategories,
        function(catId) return CoalBeauty.GetItemsForCategory(catId) or {} end,
        function(catId) return beautyItemIndexByCategory[catId] or 1 end,
        function(catId, idx) beautyItemIndexByCategory[catId] = idx end,
        function(catId, item)
            pendingBeauty[catId] = item.id
            local isManeFamily = false
            for _, otherId in ipairs(maneColorCategories) do if otherId == catId then isManeFamily = true end end
            if isManeFamily then for _, otherId in ipairs(maneColorCategories) do if otherId ~= catId then pendingBeauty[otherId] = nil end end end
            local isTailFamily = false
            for _, otherId in ipairs(tailColorCategories) do if otherId == catId then isTailFamily = true end end
            if isTailFamily then for _, otherId in ipairs(tailColorCategories) do if otherId ~= catId then pendingBeauty[otherId] = nil end end end
            ApplyPendingBeautyToPreview()
        end,
        __CoalSaveBeautyAndReturn,
        function()
            pendingBeauty = {}
            for catId, itemId in pairs(originalBeauty) do pendingBeauty[catId] = itemId end
            ClearPreviewHorse()
            __CoalMenuBackToMain()
        end
    )
end

local __OldOpenBuildAHorseMenu = OpenBuildAHorseMenu
OpenBuildAHorseMenu = function()
    __OldOpenBuildAHorseMenu()
    if not buildAHorseMenuOpen then return end
    buildAHorseMenuOpen = false
    __CoalOpenCategorySliderMenu(
        "Build-A-Horse",
        buildAHorseCategories,
        function(catId) return CoalBuildAHorse.GetItemsForCategory(catId) or {} end,
        function(catId) return buildAHorseItemIndexByCat[catId] or 1 end,
        function(catId, idx) buildAHorseItemIndexByCat[catId] = idx end,
        function(catId, item)
            ApplyBuildAHorseItemToPreview(catId, item)
        end,
        __CoalSaveBuildAHorseAndReturn,
        function()
            ClearPreviewHorse()
            __CoalMenuBackToMain()
        end
    )
end

local __OldOpenBuildATackMenu = OpenBuildATackMenu
OpenBuildATackMenu = function()
    __OldOpenBuildATackMenu()
    if not buildATackMenuOpen then return end
    buildATackMenuOpen = false
    __CoalOpenCategorySliderMenu(
        "Build-A-Tack",
        buildATackCategories,
        function(catId) return CoalBuildATack.GetItemsForCategory(catId) or {} end,
        function(catId) return buildATackItemIndexByCat[catId] or 1 end,
        function(catId, idx) buildATackItemIndexByCat[catId] = idx end,
        function(catId, item)
            ApplyBuildATackItemToPreview(catId, item)
        end,
        __CoalSaveBuildATackAndReturn,
        function()
            if RefreshPreviewHorseAppearance then RefreshPreviewHorseAppearance() end
            __CoalMenuBackToMain()
        end
    )
end


CreateThread(function()
    while true do
        if false and (stableMainMenuOpen or stableMenuOpen or tackCategoryMenuOpen or beautyCategoryMenuOpen or bruteforceMenuOpen or buildAHorseMenuOpen or buildATackMenuOpen) then
            -- When any menu is open, tick every frame
            Wait(0)

            ----------------------------------------------------------
            -- Livery Showlight (always on while menu is open)
            -- Now anchored ABOVE THE PLAYER (not above the preview horse)
            ----------------------------------------------------------
            do
                local ped = PlayerPedId()
                local p   = GetEntityCoords(ped)

                local lx = p.x
                local ly = p.y
                local lz = p.z + 2.0

                -- Warm stable lantern vibe:
                -- DrawLightWithRange(x, y, z, r, g, b, range, intensity)
                DrawLightWithRange(lx, ly, lz, 255, 244, 214, 8.0, 2.0)
            end


            ----------------------------------------------------------
            -- While editing Tack, Beauty, or Build-A-Horse, hard-freeze
            -- the preview horse and use the mouse wheel to rotate it
            ----------------------------------------------------------
            if (tackCategoryMenuOpen or beautyCategoryMenuOpen or buildAHorseMenuOpen or buildATackMenuOpen)
                and previewHorse and DoesEntityExist(previewHorse) then

                local rotStep = 30.0   -- degrees per wheel tick

                -- Stop default sniper zoom behavior from using the wheel
                DisableControlAction(0, rotateLeftKey,  true)  -- wheel up
                DisableControlAction(0, rotateRightKey, true)  -- wheel down

                -- Scroll wheel to rotate
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsDisabledControlJustPressed(0, rotateLeftKey) then __coalMenuLastInput = GetGameTimer()
                    previewRotationOffset = previewRotationOffset - rotStep
                elseif GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsDisabledControlJustPressed(0, rotateRightKey) then __coalMenuLastInput = GetGameTimer()
                    previewRotationOffset = previewRotationOffset + rotStep
                end

                -- keep rotation offset tidy
                if previewRotationOffset < 0.0 then
                    previewRotationOffset = previewRotationOffset + 360.0
                elseif previewRotationOffset >= 360.0 then
                    previewRotationOffset = previewRotationOffset - 360.0
                end

                -- keep it nailed in place
                FreezeEntityPosition(previewHorse, true)
                SetEntityCollision(previewHorse, false, false)

                local baseHeading  = previewAnchorHeading or GetEntityHeading(previewHorse)
                local finalHeading = baseHeading + (previewRotationOffset or 0.0)

                if finalHeading < 0.0 then
                    finalHeading = finalHeading + 360.0
                elseif finalHeading >= 360.0 then
                    finalHeading = finalHeading - 360.0
                end

                SetEntityHeading(previewHorse, finalHeading)
                ClearPedTasksImmediately(previewHorse)
            end

            ----------------------------------------------------------
            -- WHICH MENU IS ACTIVE?
            ----------------------------------------------------------
            if bruteforceMenuOpen then


                --------------------------------------------------
                -- 5) COAL BRUTEFORCE MENU
                --------------------------------------------------
                DrawCoalBruteforceMenu()

                -- LEFT / RIGHT: step through items and apply
                if IsNavRepeat(controlLeft) then
                    bruteforceIndex = bruteforceIndex - 1
                    if bruteforceIndex < 1 then
                        bruteforceIndex = #bruteforceItems
                    end
                elseif IsNavRepeat(controlRight) then
                    bruteforceIndex = bruteforceIndex + 1
                    if bruteforceIndex > #bruteforceItems then
                        bruteforceIndex = 1
                    end
                end

                -- Apply current selection whenever it changes
                local current = bruteforceItems[bruteforceIndex]
                if current and previewHorse and DoesEntityExist(previewHorse) then
                    if current.itemHash then
                        -- DB-driven blanket hashes
                        ApplyTackItem(previewHorse, current.itemHash)
                    elseif current.shopItemHash then
                        -- Static family items
                        ApplyTackItem(previewHorse, current.shopItemHash)
                    end
                end


                -- BACKSPACE: exit bruteforce and go back to Livery main menu
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlBack) then __coalMenuLastInput = GetGameTimer()
                    bruteforceMenuOpen     = false
                    ClearPreviewHorse()
                    stableMainMenuOpen     = true
                    stableMainMenuSelected = 1  -- focus back on "Coal Bruteforce"
                end

             ----------------------------------------------------------
            -- 1) LIVERY MAIN MENU (Store / Stables / Tack / Beauty / Build / BF)
            ----------------------------------------------------------
            
            elseif stableMainMenuOpen then
                DrawLiveryMenu()

                -- we now have 4 entries in DrawLiveryMenu()
                local MAIN_MENU_ENTRY_COUNT = 4

                -- UP / DOWN to move selection
                if IsNavRepeat(controlUp) then
                    stableMainMenuSelected = stableMainMenuSelected - 1
                    if stableMainMenuSelected < 1 then
                        stableMainMenuSelected = MAIN_MENU_ENTRY_COUNT
                    end
                elseif IsNavRepeat(controlDown) then
                    stableMainMenuSelected = stableMainMenuSelected + 1
                    if stableMainMenuSelected > MAIN_MENU_ENTRY_COUNT then
                        stableMainMenuSelected = 1
                    end
                end

                -- ENTER to open the sub-menu
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlAccept) then __coalMenuLastInput = GetGameTimer()
                    if     stableMainMenuSelected == 1 then
                        OpenStableMenu(lastStableId, "stables")
                    elseif stableMainMenuSelected == 2 then
                        OpenStableMenu(lastStableId, "store")
                    elseif stableMainMenuSelected == 3 then
                        OpenBuildATackMenu()
                    elseif stableMainMenuSelected == 4 then
                        OpenBuildAHorseMenu()
                    end
                end

                -- BACKSPACE to close livery entirely
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlBack) then __coalMenuLastInput = GetGameTimer()
                    stableMainMenuOpen = false
                    ClearPreviewHorse()
                    previewAnchorPos     = nil
                    previewAnchorHeading = nil
                end


            ----------------------------------------------------------
            -- 2) HORSE LIST MENU (STORE / STABLES)
            ----------------------------------------------------------
            elseif stableMenuOpen then
                DrawStableMenu()

                -- up/down: change selected horse (with repeat)
                if IsNavRepeat(controlUp) then
                    stableMenuSelected = stableMenuSelected - 1
                    if stableMenuSelected < 1 then
                        stableMenuSelected = #stableMenuHorses
                    end
                    QueuePreviewHorse(stableMenuHorses[stableMenuSelected])

                elseif IsNavRepeat(controlDown) then
                    stableMenuSelected = stableMenuSelected + 1
                    if stableMenuSelected > #stableMenuHorses then
                        stableMenuSelected = 1
                    end
                    QueuePreviewHorse(stableMenuHorses[stableMenuSelected])
                end

                -- left/right: change coat (store mode only, not __owned__) with repeat
                if IsNavRepeat(controlLeft) or IsNavRepeat(controlRight) then
                    local selected = stableMenuHorses[stableMenuSelected]

                    if selected and (not (type(selected.id) == "string" and selected.id:sub(1, 7) == "__owned")) and selected.models and #selected.models > 1 then
                        if IsControlPressed(0, controlRight) then
                            selected.modelIndex = (selected.modelIndex or 1) + 1
                            if selected.modelIndex > #selected.models then
                                selected.modelIndex = 1
                            end
                        elseif IsControlPressed(0, controlLeft) then
                            selected.modelIndex = (selected.modelIndex or 1) - 1
                            if selected.modelIndex < 1 then
                                selected.modelIndex = #selected.models
                            end
                        end

                        QueuePreviewHorse(selected)
                    end
                end

                -- accept: buy or select
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlAccept) then __coalMenuLastInput = GetGameTimer()
                    local chosen = stableMenuHorses[stableMenuSelected]
                    if chosen and lastStableId then
                        if chosen._ownedRaw then
                            -- Update local main horse / tack / beauty so other menus use this horse
                            currentOwnedHorseData = chosen._ownedRaw

                            -- Sync equipped tack from this horse
                            if currentOwnedHorseData.tack and type(currentOwnedHorseData.tack) == "table" then
                                equippedTack = {
                                    -- base categories
                                    saddles        = nil,
                                    blankets       = nil,
                                    stirrups       = nil,
                                    bedrolls       = nil,
                                    bridles        = nil,
                                    harness        = nil,
                                    saddlebags     = nil,
                                    holsters       = nil,

                                    -- generic tints
                                    saddle_tint    = nil,
                                    bridle_tint    = nil,
                                    stirrup_tint   = nil,
                                    horn_tint      = nil,

                                    -- saddlebag tints (3 channels)
                                    saddlebags_tint0 = nil,
                                    saddlebags_tint1 = nil,
                                    saddlebags_tint2 = nil,

                                    -- bedroll tints (3 channels)
                                    bedroll_tint0  = nil,
                                    bedroll_tint1  = nil,
                                    bedroll_tint2  = nil,

                                    -- holsters tints (3 channels)
                                    holsters_tint0  = nil,
                                    holsters_tint1  = nil,
                                    holsters_tint2  = nil,
                                }

                                for k, v in pairs(currentOwnedHorseData.tack) do
                                    equippedTack[k] = v
                                end

                                -- legacy one-channel -> three-channel migration for saddlebags
                                if equippedTack["saddlebags_tint"]
                                   and not (equippedTack["saddlebags_tint0"]
                                        or  equippedTack["saddlebags_tint1"]
                                        or  equippedTack["saddlebags_tint2"]) then

                                    local legacy = equippedTack["saddlebags_tint"]
                                    equippedTack["saddlebags_tint0"] = legacy
                                    equippedTack["saddlebags_tint1"] = legacy
                                    equippedTack["saddlebags_tint2"] = legacy
                                end
                            end

                            -- Sync beauty from this horse
                            if currentOwnedHorseData.beauty and type(currentOwnedHorseData.beauty) == "table" then
                                equippedBeauty = {
                                    manes        = nil,
                                    tails        = nil,
                                    hoof_feather = nil,
                                    mane_colors  = nil,
                                    tail_colors  = nil,

                                    HorseBody    = nil,
                                    HorseHead    = nil,
                                }

                                for k, v in pairs(currentOwnedHorseData.beauty) do
                                    equippedBeauty[k] = v
                                end
                            end

                            -- Normalise this horse's local slot/index so any later
                            -- appearance saves point back to the same owned entry.
                            currentOwnedHorseData._slot = stableMenuSelected

                            -- Select this owned horse as main at this stable, using
                            -- the index from the stables menu (not the DB slot).
                            local slot = stableMenuSelected
                            TriggerServerEvent("coal_stables:selectMainHorse", lastStableId, slot)

                            -- Close list, go back to main livery menu
                            stableMenuOpen         = false
                            ClearPreviewHorse()
                            stableMainMenuOpen     = true
                            stableMainMenuSelected = 1  -- "Stables"
                        else
                            -- Buy from store (still spawns horse at stable)
                            local chosenModel
                            if chosen.models and chosen.modelIndex then
                                chosenModel = chosen.models[chosen.modelIndex] or chosen.models[1]
                            else
                                chosenModel = chosen.model
                            end

                            -- Tell the server to buy the horse
                            TriggerServerEvent("coal_stables:buyHorse", chosen.id, lastStableId, chosenModel)

                            -- Locally assume this is now your main owned horse so
                            -- Tack & Services / Beauty & Grooming can work immediately.
                            currentOwnedHorseData = {
                                name      = chosen.name,
                                tierLabel = chosen.tierLabel or "Owned Mount",
                                speed     = chosen.speed  or 1.0,
                                health    = chosen.health or 1.0,
                                stamina   = chosen.stamina or 1.0,
                                model     = chosenModel,
                                tack      = equippedTack,
                                beauty    = equippedBeauty,
                            }

                            -- After buying, close menu and return to main
                            stableMenuOpen         = false
                            ClearPreviewHorse()
                            stableMainMenuOpen     = true
                            stableMainMenuSelected = 2  -- "Stables Store"
                        end
                    end
                end

                -- back: go back up to Livery menu
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlBack) then __coalMenuLastInput = GetGameTimer()
                    stableMenuOpen     = false
                    ClearPreviewHorse()
                    stableMainMenuOpen = true

                    -- Restore cursor based on which menu we opened
                    if stableMenuMode == "stables" then
                        stableMainMenuSelected = 1   -- "Stables"
                    else
                        -- treat nil or "store" as Store
                        stableMainMenuSelected = 2   -- "Stables Store"
                    end
                end

            ----------------------------------------------------------
            ----------------------------------------------------------
            -- 3) TACK CATEGORY MENU (single-screen, pending + confirm)
            ----------------------------------------------------------
            elseif tackCategoryMenuOpen then
                DrawTackCategoryMenu()

                local cat = tackCategories[tackCategoryIndex]

                -- UP/DOWN: change category (with repeat)
                if IsNavRepeat(controlUp) then
                    tackCategoryIndex = tackCategoryIndex - 1
                    if tackCategoryIndex < 1 then
                        tackCategoryIndex = #tackCategories
                    end
                elseif IsNavRepeat(controlDown) then
                    tackCategoryIndex = tackCategoryIndex + 1
                    if tackCategoryIndex > #tackCategories then
                        tackCategoryIndex = 1
                    end
                end

                -- LEFT/RIGHT: change item within this category (update pendingTack)
                if cat then
                    local items = CoalTack.GetItemsForCategory(cat.id)
                    if #items > 0 then
                        local idx = tackItemIndexByCategory[cat.id] or 1

                        if IsNavRepeat(controlRight) then
                            idx = idx + 1
                            if idx > #items then idx = 1 end
                        elseif IsNavRepeat(controlLeft) then
                            idx = idx - 1
                            if idx < 1 then idx = #items end
                        end

                        if idx ~= (tackItemIndexByCategory[cat.id] or 1) then
                            tackItemIndexByCategory[cat.id] = idx

                            local item = items[idx]
                            if item then
                                -- Always set the current category first
                                pendingTack[cat.id] = item.id

                                -- If this is a bridle style row, clear any OTHER
                                -- bridle style categories so only one style is active.
                                if bridleStyleCategories[cat.id] then
                                    for otherCatId, _ in pairs(bridleStyleCategories) do
                                        if otherCatId ~= cat.id then
                                            local otherItems = CoalTack.GetItemsForCategory(otherCatId)
                                            if #otherItems > 0 then
                                                -- push back to "no_bridle" if present, else first item
                                                local defaultIndex = 1
                                                for j, otherItem in ipairs(otherItems) do
                                                    if otherItem.id == "no_bridle" then
                                                        defaultIndex = j
                                                        break
                                                    end
                                                end

                                                tackItemIndexByCategory[otherCatId] = defaultIndex
                                                pendingTack[otherCatId] = otherItems[defaultIndex].id
                                            else
                                                tackItemIndexByCategory[otherCatId] = 1
                                                pendingTack[otherCatId] = nil
                                            end
                                        end
                                    end
                                end

                                ApplyPendingTackToPreview()
                            end
                        end
                    end
                end

                -- ENTER: confirm & save ALL pending tack changes
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlAccept) then __coalMenuLastInput = GetGameTimer()
                    -- Build a fresh tack snapshot:
                    --  - start from whatever is currently equipped (this already includes
                    --    all “special” keys like bedroll_tint0/1/2, holster_tint0/1/2, etc)
                    --  - then overlay every category the player changed in this session
                    local finalTack = {}

                    -- 1) copy everything from the current equipped set
                    if equippedTack then
                        for k, v in pairs(equippedTack) do
                            finalTack[k] = v
                        end
                    end

                    -- 2) overlay every pending category the user touched (including tints)
                    for catId, itemId in pairs(pendingTack) do
                        finalTack[catId] = itemId
                    end

                    -- This snapshot is now the canonical tack for this horse
                    equippedTack = finalTack

                    if currentOwnedHorseData then
                        currentOwnedHorseData.tack = finalTack

                        -- send the full tack table (including tint keys) to the server
                        local slot = currentOwnedHorseData and currentOwnedHorseData._slot or nil
                        TriggerServerEvent("coal_stables:updateHorseAppearance", slot, finalTack, nil)
                    end

                    --
                    -- Save Build-A-Horse result as this player's main horse appearance

                    --
                    TriggerEvent("vorp:TipBottom", "Horse tack updated.", 3000)

                    tackCategoryMenuOpen   = false
                    ClearPreviewHorse()
                    stableMainMenuOpen     = true
                    stableMainMenuSelected = 4 -- Tack & Services
                end
--------------------------------------------------
    -- BACKSPACE: cancel and return to Tack & Services without saving
    if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlBack) then __coalMenuLastInput = GetGameTimer()
        -- don’t touch equippedTack / DB, just leave preview + menu
        tackCategoryMenuOpen   = false
        ClearPreviewHorse()
        stableMainMenuOpen     = true
        stableMainMenuSelected = 3 -- back to “Tack & Services” on the main livery menu
    end
--
                      ----------------------------------------------------------
            -- 4) BUILD-A-HORSE MENU (body presets / manes / tails)
            ----------------------------------------------------------
            elseif buildAHorseMenuOpen then
                DrawBuildAHorseMenu()

                ------------------------------------------------------
                -- CATEGORY NAV: UP / DOWN
                ------------------------------------------------------
                if IsNavRepeat(controlUp) then
                    buildAHorseCategoryIndex = buildAHorseCategoryIndex - 1
                    if buildAHorseCategoryIndex < 1 then
                        buildAHorseCategoryIndex = #buildAHorseCategories
                    end
                elseif IsNavRepeat(controlDown) then
                    buildAHorseCategoryIndex = buildAHorseCategoryIndex + 1
                    if buildAHorseCategoryIndex > #buildAHorseCategories then
                        buildAHorseCategoryIndex = 1
                    end
                end

                ------------------------------------------------------
                -- ITEM NAV: LEFT / RIGHT
                ------------------------------------------------------
                local cat = buildAHorseCategories[buildAHorseCategoryIndex]
                if cat then
                    local items = CoalBuildAHorse.GetItemsForCategory(cat.id)
                    if #items > 0 then
                        local idx     = buildAHorseItemIndexByCat[cat.id] or 1
                        local changed = false

                        -- wrap index
                        if IsNavRepeat(controlLeft) then
                            idx = idx - 1
                            if idx < 1 then
                                idx = #items
                            end
                            changed = true
                        elseif IsNavRepeat(controlRight) then
                            idx = idx + 1
                            if idx > #items then
                                idx = 1
                            end
                            changed = true
                        end

                        buildAHorseItemIndexByCat[cat.id] = idx

                        --------------------------------------------------
                        -- Keep the 3 body regions in lockstep per channel
                        --------------------------------------------------
                        if changed then
                            if cat.id == "body_hand_ab"
                                or cat.id == "body_head_ab"
                                or cat.id == "body_mis2_ab" then

                                buildAHorseItemIndexByCat["body_hand_ab"] = idx
                                buildAHorseItemIndexByCat["body_head_ab"] = idx
                                buildAHorseItemIndexByCat["body_mis2_ab"] = idx

                            elseif cat.id == "body_hand_nm"
                                or cat.id == "body_head_nm"
                                or cat.id == "body_mis2_nm" then

                                buildAHorseItemIndexByCat["body_hand_nm"] = idx
                                buildAHorseItemIndexByCat["body_head_nm"] = idx
                                buildAHorseItemIndexByCat["body_mis2_nm"] = idx

                            elseif cat.id == "body_hand_m"
                                or cat.id == "body_head_m"
                                or cat.id == "body_mis2_m" then

                                buildAHorseItemIndexByCat["body_hand_m"]  = idx
                                buildAHorseItemIndexByCat["body_head_m"]  = idx
                                buildAHorseItemIndexByCat["body_mis2_m"]  = idx
                            end
                        end

                        --------------------------------------------------
                        -- LIVE PREVIEW WHEN ITEM CHANGES
                        --------------------------------------------------
                        if changed then
                            ApplyBuildAHorseItemToPreview(cat.id, items[idx])
                        end

                        --------------------------------------------------
                        -- ENTER: SAVE BUILD-A-HORSE & RETURN TO LIVERY
                        --------------------------------------------------
                        if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlAccept) then __coalMenuLastInput = GetGameTimer()
                            if currentOwnedHorseData then
                                -- New structure: keep Build-A-Horse state in an appearance blob
                                local appearance = currentOwnedHorseData.appearance or {}

                                appearance.buildAHorse        = appearance.buildAHorse or {}
                                appearance.buildAHorse.body   = buildAHorseBodyDebug
                                appearance.buildAHorse.hair   = buildAHorseHairState
                                appearance.buildAHorse.scale  = buildAHorseScale

                                -- Persist hoof feather choice (if any)
                                do
                                    local hfId = buildAHorseSelection and buildAHorseSelection["hoof_feather"] or nil
                                    if hfId ~= nil then
                                        appearance.buildAHorse.hoof_feather = { id = hfId }
                                    else
                                        appearance.buildAHorse.hoof_feather = nil
                                    end
                                end

                                currentOwnedHorseData.appearance = appearance

                                -- Persist via the existing appearance handler (3rd arg is now appearance overrides)
                                local slot = currentOwnedHorseData and currentOwnedHorseData._slot or nil
                                TriggerServerEvent(
                                    "coal_stables:updateHorseAppearance",
                                    slot,
                                    nil,
                                    appearance
                                )
                            end

                            TriggerEvent(
                                "vorp:TipBottom",
                                "Build-A-Horse saved as your main horse.",
                                4000
                            )

                            -- Return to the main livery menu with Build-A-Horse selected
                            buildAHorseMenuOpen    = false
                            stableMainMenuOpen     = true
                            stableMenuOpen         = false
                            stableMainMenuSelected = 2
                        end
                    end
                end

                ------------------------------------------------------
                -- BACKSPACE: back to main livery menu on Build-A-Horse
                ------------------------------------------------------
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlBack) then __coalMenuLastInput = GetGameTimer()
                    buildAHorseMenuOpen    = false
                    stableMainMenuOpen     = true
                    stableMainMenuSelected = 4  -- Build-A-Horse entry

                    -- Leaving Build-A-Horse cancels any temporary preview horse.
                    if previewHorse and DoesEntityExist(previewHorse) then
                        DeletePed(previewHorse)
                    end
                    previewHorse     = nil
                    lastPreviewEntry = nil
                end
--


----------------------------------------------------------
            -- 5) BUILD-A-TACK MENU (saddles / blankets / bags / stirrups / horns)
            ----------------------------------------------------------
            elseif buildATackMenuOpen then
                DrawBuildATackMenu()

                ------------------------------------------------------
                -- CATEGORY NAV: UP / DOWN
                ------------------------------------------------------
                if IsNavRepeat(controlUp) then
                    buildATackCategoryIndex = buildATackCategoryIndex - 1
                    if buildATackCategoryIndex < 1 then
                        buildATackCategoryIndex = #buildATackCategories
                    end
                elseif IsNavRepeat(controlDown) then
                    buildATackCategoryIndex = buildATackCategoryIndex + 1
                    if buildATackCategoryIndex > #buildATackCategories then
                        buildATackCategoryIndex = 1
                    end
                end

                ------------------------------------------------------
                -- ITEM NAV: LEFT / RIGHT
                ------------------------------------------------------
                local cat = buildATackCategories[buildATackCategoryIndex]
                if cat and CoalBuildATack and CoalBuildATack.GetItemsForCategory then
                    local items = CoalBuildATack.GetItemsForCategory(cat.id) or {}
                    if #items > 0 then
                        local idx     = buildATackItemIndexByCat[cat.id] or 1
                        local changed = false

                        if IsNavRepeat(controlLeft) then
                            idx = idx - 1
                            if idx < 1 then
                                idx = #items
                            end
                            changed = true
                        elseif IsNavRepeat(controlRight) then
                            idx = idx + 1
                            if idx > #items then
                                idx = 1
                            end
                            changed = true
                        end

                        if changed then
                            buildATackItemIndexByCat[cat.id] = idx
                            local item = items[idx]
                            if item then
                                ApplyBuildATackItemToPreview(cat.id, item)
                            end
                        end
                    end
                end

                ------------------------------------------------------
                -- ENTER: SAVE BUILD-A-TACK & RETURN TO LIVERY
                ------------------------------------------------------
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlAccept) then __coalMenuLastInput = GetGameTimer()
                    if currentOwnedHorseData then
                        -- New structure: keep Build-A-Tack state in the same appearance blob
                        local appearance = currentOwnedHorseData.appearance or {}

                        appearance.buildATack = buildATackState

                        currentOwnedHorseData.appearance = appearance

                        -- Persist via the existing appearance handler (3rd arg is now appearance overrides)
                        local slot = currentOwnedHorseData and currentOwnedHorseData._slot or nil
                        TriggerServerEvent(
                            "coal_stables:updateHorseAppearance",
                            slot,
                            nil,
                            appearance
                        )
                    end

                    TriggerEvent(
                        "vorp:TipBottom",
                        "Build-A-Tack saved as your main tack.",
                        4000
                    )

                    -- Return to the main livery menu with Build-A-Tack selected
                    buildATackMenuOpen     = false
                    stableMainMenuOpen     = true
                    stableMenuOpen         = false
                    stableMainMenuSelected = 1
                end

                ------------------------------------------------------
                -- BACKSPACE: cancel Build-A-Tack and restore real main horse
                ------------------------------------------------------
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlBack) then __coalMenuLastInput = GetGameTimer()
                    -- Close the Build-A-Tack workshop UI
                    buildATackMenuOpen     = false
                    stableMainMenuOpen     = true
                    stableMenuOpen         = false
                    stableMainMenuSelected = 3  -- Build-A-Tack entry

                    -- IMPORTANT: restore preview to canonical appearance
                    -- (equipped tack + equipped beauty + any *saved* Build-A-Tack),
                    -- so unsaved workshop changes don't leak into other menus.
                    if RefreshPreviewHorseAppearance then
                        RefreshPreviewHorseAppearance()
                    end
                end

            ----------------------------------------------------------
            -- 5) BEAUTY CATEGORY MENU (manes / tails)
            ----------------------------------------------------------
            elseif beautyCategoryMenuOpen then
                DrawBeautyCategoryMenu()

                local cat = beautyCategories[beautyCategoryIndex]

                -- UP/DOWN: change beauty category (with repeat)
                if IsNavRepeat(controlUp) then
                    beautyCategoryIndex = beautyCategoryIndex - 1
                    if beautyCategoryIndex < 1 then
                        beautyCategoryIndex = #beautyCategories
                    end
                elseif IsNavRepeat(controlDown) then
                    beautyCategoryIndex = beautyCategoryIndex + 1
                    if beautyCategoryIndex > #beautyCategories then
                        beautyCategoryIndex = 1
                    end
                end

                -- LEFT/RIGHT: change style within this category (update pendingBeauty)
                if cat then
                    local items = CoalBeauty.GetItemsForCategory(cat.id)
                    if #items > 0 then
                        local idx = beautyItemIndexByCategory[cat.id] or 1

                        if IsNavRepeat(controlRight) then
                            idx = idx + 1
                            if idx > #items then idx = 1 end
                        elseif IsNavRepeat(controlLeft) then
                            idx = idx - 1
                            if idx < 1 then idx = #items end
                        end

                        if idx ~= (beautyItemIndexByCategory[cat.id] or 1) then
                            beautyItemIndexByCategory[cat.id] = idx

                            local item = items[idx]
                            if item then
                                -- Store the chosen tint for this category
                                pendingBeauty[cat.id] = item.id

                                -- Mane-color families: only one active at a time
                                local isManeFamily = false
                                for _, otherId in ipairs(maneColorCategories) do
                                    if otherId == cat.id then
                                        isManeFamily = true
                                        break
                                    end
                                end
                                if isManeFamily then
                                    for _, otherId in ipairs(maneColorCategories) do
                                        if otherId ~= cat.id then
                                            pendingBeauty[otherId] = nil
                                        end
                                    end
                                end

                                -- Tail-color families: only one active at a time
                                local isTailFamily = false
                                for _, otherId in ipairs(tailColorCategories) do
                                    if otherId == cat.id then
                                        isTailFamily = true
                                        break
                                    end
                                end
                                if isTailFamily then
                                    for _, otherId in ipairs(tailColorCategories) do
                                        if otherId ~= cat.id then
                                            pendingBeauty[otherId] = nil
                                        end
                                    end
                                end

                                if previewHorse and DoesEntityExist(previewHorse) then
                                    ApplyPendingBeautyToPreview()
                                end
                            end
                        end
                    end
                end

                -- ENTER: confirm & save ALL pending beauty changes
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlAccept) then __coalMenuLastInput = GetGameTimer()
                    -- Clean mane color families
                    local hasManeChoice = false
                    local chosenManeCat
                    for _, catId in ipairs(maneColorCategories) do
                        if pendingBeauty[catId] then
                            hasManeChoice = true
                            chosenManeCat = catId
                        end
                    end
                    if hasManeChoice then
                        for _, catId in ipairs(maneColorCategories) do
                            if catId ~= chosenManeCat then
                                equippedBeauty[catId] = nil
                            end
                        end
                    end

                    -- Clean tail color families
                    local hasTailChoice = false
                    local chosenTailCat
                    for _, catId in ipairs(tailColorCategories) do
                        if pendingBeauty[catId] then
                            hasTailChoice = true
                            chosenTailCat = catId
                        end
                    end
                    if hasTailChoice then
                        for _, catId in ipairs(tailColorCategories) do
                            if catId ~= chosenTailCat then
                                equippedBeauty[catId] = nil
                            end
                        end
                    end

                    -- Now apply pending -> equipped
                    for catId, itemId in pairs(pendingBeauty) do
                        equippedBeauty[catId] = itemId
                    end

                    if currentOwnedHorseData then
                        currentOwnedHorseData.beauty = equippedBeauty
                        local slot = currentOwnedHorseData and currentOwnedHorseData._slot or nil
                        TriggerServerEvent("coal_stables:updateHorseAppearance", slot, nil, equippedBeauty)
                    end

                    TriggerEvent("vorp:TipBottom", "Beauty & Grooming updated.", 3000)
                    beautyCategoryMenuOpen  = false
                    ClearPreviewHorse()
                    stableMainMenuOpen      = true
                    stableMainMenuSelected  = 1
                end

                -- BACKSPACE: cancel changes and restore original beauty
                if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, controlBack) then __coalMenuLastInput = GetGameTimer()
                    pendingBeauty = {}
                    for catId, itemId in pairs(originalBeauty) do
                        pendingBeauty[catId] = itemId
                    end

                    beautyCategoryMenuOpen  = false
                    ClearPreviewHorse()
                    stableMainMenuOpen      = true
                    stableMainMenuSelected  = 1
                end

            end -- end which-menu branch
        else
            -- No menu open: chill a bit
            Wait(250)
        end
    end
end)


--==================================================
--HORSEBRUSH
--==================================================
-- Coal_Horsebrush - client

local BRUSH_DISTANCE = 3.0

-- Helper: is this ped a horse?
local function IsPedHorse(ped)
    if not DoesEntityExist(ped) then return false end
    local model = GetEntityModel(ped)
    -- _IS_THIS_MODEL_A_HORSE
    return Citizen.InvokeNative(0x772A1969F649E902, model)
end

-- Your brush function, unchanged but wrapped
local function BrushHorse(targetHorse)
    local playerPed = PlayerPedId()

    -- Native brush interaction with prop
    Citizen.InvokeNative(
        0xCD181A959CFDD7F4,            -- _TASK_ITEM_INTERACTION
        playerPed,
        targetHorse,
        GetHashKey("Interaction_Brush"),
        GetHashKey("p_brushHorse02x"),
        1
    )

    -- Let the animation play
    Citizen.Wait(5000)

    -- Clean the horse locally
    ClearPedEnvDirt(targetHorse)
    ClearPedBloodDamage(targetHorse)
    ClearPedDecorations(targetHorse)
    ClearPedWetness(targetHorse)
end

-- Simple raycast in front of the player to find a horse
local function GetHorseInFront()
    local ped = PlayerPedId()
    local from = GetEntityCoords(ped)
    local fwd = GetEntityForwardVector(ped)
    local to = from + (fwd * BRUSH_DISTANCE)

    -- capsule raycast
    local handle = StartShapeTestCapsule(
        from.x, from.y, from.z,
        to.x,   to.y,   to.z,
        0.5,           -- radius
        10,            -- flags: peds & vehicles
        ped,
        0
    )

    local _, hit, _, _, entityHit = GetShapeTestResult(handle)
    if hit == 1 and DoesEntityExist(entityHit) and IsPedHorse(entityHit) then
        return entityHit
    end

    return nil
end

-- Decide which horse to brush:
-- 1) your mount if you're on one
-- 2) otherwise the horse in front
local function GetBrushTarget()
    local ped = PlayerPedId()

    local mount = GetMount(ped)
    if mount ~= 0 and IsPedHorse(mount) then
        return mount
    end

    return GetHorseInFront()
end

RegisterNetEvent("coal:useBrush")
AddEventHandler("coal:useBrush", function()
    local horse = GetBrushTarget()

    if not horse or not IsPedHorse(horse) then
        TriggerEvent("vorp:TipBottom", "No horse to brush.", 3000)
        return
    end

    BrushHorse(horse)
end)

-- OPTIONAL debug command (remove if you want it super clean)
-- /testbrush
RegisterCommand("testbrush", function()
    TriggerEvent("coal:useBrush")
end, false)
--=====================================================================
--  STABLE INTERACTION (PROXIMITY + KEYBIND)
--=====================================================================

local interactKey = 0x760A9C6F -- G (check / change to your preferred control)

CreateThread(function()
    while true do
        local sleep = 1000
        local ped = PlayerPedId()
        local pCoords = GetEntityCoords(ped)

        for _, stable in ipairs(CoalStables.Config.Stables) do
            local dist = #(pCoords - stable.coords)

            if dist < 15.0 then
                sleep = 0

                -- Simple 3D text prompt
 if dist < 3.0 then
    -- Only show prompt & accept G when NO livery UI is open
   
            -- Only show prompt & accept G when NO livery UI is open
        if not (
            stableMainMenuOpen
            or stableMenuOpen
            or tackCategoryMenuOpen
            or beautyCategoryMenuOpen
            or bruteforceMenuOpen      -- 🔹 added
        ) then

   
    SetTextScale(0.35, 0.35)
        SetTextFontForCurrentCommand(1)
        SetTextColor(255, 255, 255, 255)
        SetTextCentre(true)
        DisplayText(
            CreateVarString(10, "LITERAL_STRING", stable.name .. " - Press [G] to open stables"),
            0.5,
            0.9
        )

        if GetGameTimer() - __coalMenuLastInput > __coalMenuInputDelay and IsControlJustPressed(0, interactKey) then __coalMenuLastInput = GetGameTimer()
            local isLaw    = false
            local isOutlaw = false
            OpenLiveryMenu(stable.id, isLaw, isOutlaw)
        end
    end
end
            end
        end

        Wait(sleep)
    end
end)
----------------------------------
--you can now safely add the debug command
----------------------------------
RegisterCommand("coal_dump_blankets", function()
    if not CoalBruteforce or not CoalBruteforce.GetItems then
        print("[CoalBruteforce] No BF items available.")
        return
    end

    local items = CoalBruteforce.GetItems() or {}
    print(("[CoalBruteforce] Dumping %d blankets:"):format(#items))

    for i, it in ipairs(items) do
        local name = it.shopItemHash or it.rawName or it.id
        local hash = it.itemHash

        -- Fallback: compute hash from name if needed
        if (not hash) and name then
            if type(name) == "string" then
                hash = GetHashKey(name)
            else
                hash = name
            end
        end

        local src  = it.source or "unknown"
        local page = it.pageIndex or 0

        if hash then
            print(string.format(
                "[%03d] src=%s page=%s name=%s hash=0x%08X (%d)",
                i,
                src,
                tostring(page),
                tostring(name),
                hash,
                hash
            ))
        else
            print(string.format(
                "[%03d] src=%s page=%s name=%s (no hash)",
                i,
                src,
                tostring(page),
                tostring(name)
            ))
        end
    end
end, false)


-- Cleanup spawned/preview horses when resource stops/restarts
local function __coalDeleteEntitySafe(ent)
    if ent and ent ~= 0 and DoesEntityExist(ent) then
        SetEntityAsMissionEntity(ent, true, true)
        DeleteEntity(ent)
    end
end

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    __coalDeleteEntitySafe(currentHorse)
    __coalDeleteEntitySafe(previewHorse)
    __coalDeleteEntitySafe(PreviewHorse)
    __coalDeleteEntitySafe(currentPreviewHorse)
    __coalDeleteEntitySafe(CurrentPreviewHorse)
    __coalDeleteEntitySafe(stableHorse)
    __coalDeleteEntitySafe(StableHorse)

    -- Extra safety: delete nearby horses spawned by this script if they are mission entities we own.
    local playerPed = PlayerPedId()
    if playerPed and playerPed ~= 0 then
        local pcoords = GetEntityCoords(playerPed)
        local handle, ped = FindFirstPed()
        local success = true
        repeat
            if ped and ped ~= 0 and ped ~= playerPed and DoesEntityExist(ped) then
                if IsPedAPlayer(ped) == false and GetPedType(ped) == 28 then
                    local coords = GetEntityCoords(ped)
                    if #(pcoords - coords) < 60.0 then
                        SetEntityAsMissionEntity(ped, true, true)
                        DeleteEntity(ped)
                    end
                end
            end
            success, ped = FindNextPed(handle)
        until not success
        EndFindPed(handle)
    end
end)




RegisterCommand("coalclearhorses", function()
    local playerPed = PlayerPedId()
    local pcoords = GetEntityCoords(playerPed)
    local count = 0

    local handle, ped = FindFirstPed()
    local success = true
    repeat
        if ped and ped ~= 0 and ped ~= playerPed and DoesEntityExist(ped) then
            if IsPedAPlayer(ped) == false and GetPedType(ped) == 28 then
                local coords = GetEntityCoords(ped)
                if #(pcoords - coords) < 60.0 then
                    SetEntityAsMissionEntity(ped, true, true)
                    DeleteEntity(ped)
                    count = count + 1
                end
            end
        end
        success, ped = FindNextPed(handle)
    until not success
    EndFindPed(handle)

    TriggerEvent("vorp:TipBottom", ("Cleared %s nearby horse(s)."):format(count), 4000)
end, false)

