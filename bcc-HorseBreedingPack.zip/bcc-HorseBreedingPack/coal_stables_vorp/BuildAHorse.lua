CoalBuildAHorse = CoalBuildAHorse or {}
local H = {}


-- Resource name used for LoadResourceFile. Defaults to current resource.
local BA_HORSE_RESNAME = GetCurrentResourceName and GetCurrentResourceName() or "coal_stables"

-- Optional: override which resource contains data/*.json used by Build-A-Horse
function CoalBuildAHorse.SetDataResourceName(resName)
    if type(resName) == "string" and resName ~= "" then
        BA_HORSE_RESNAME = resName
    end
end
local function sortOnce(list)
    if list and not list._sorted then
        table.sort(list, function(a, b)
            local sa = a.sortIndex or 0
            local sb = b.sortIndex or 0
            if sa ~= sb then return sa < sb end
            return (a.label or "") < (b.label or "")
        end)
        list._sorted = true
    end
end

--  These will be your sections: body presets, heads, manes, tails, etc.
H.Categories = {
    -- 0: Horse selector (store breeds / models)
    { id = "horse_model", label = "Horse", name = "Horse" },
    { id = "body_hand_ab", label = "Coat Style",   name = "Coat" },
    { id = "body_palette", label = "Coat Palette", name = "Body Tint Palette" },
    { id = "body_hand_tint0", label = "Primary Coat Tint",   name = "Primary Coat Tint",   useItemLabel = false },
    { id = "body_hand_tint1", label = "Secondary Coat Tint", name = "Secondary Coat Tint", useItemLabel = false },
    { id = "body_hand_tint2", label = "Miscellaneous Tint",    name = "Miscellaneous Tint",    useItemLabel = false },
    { id = "body_hand_m",  label = "Shine Level",  name = "Shine" },
    { id = "body_hand_nm", label = "Physique",    name = "{Physique}" },
    { id = "manes",        label = "Mane Style",               name = "Mane" },
    { id = "tails",      label = "Tail Style",               name = "Tail" },
    { id = "hair_palette", label = "Hair Palette",            name = "Hair Palette" },
    { id = "mane_tint0",   label = "Mane Primary Tint",           name = "Mane Mid Tint",       useItemLabel = false },
    { id = "tail_tint0", label = "Tail Primary Tint",           name = "Tail Mid Tint",       useItemLabel = false },
    { id = "mane_tint1",   label = "Mane Base Tint",          name = "Mane Base Tint",      useItemLabel = false },
    { id = "tail_tint1", label = "Tail Base Tint",          name = "Tail Base Tint",      useItemLabel = false },
    { id = "mane_tint2",   label = "Mane Highlight Tint",     name = "Mane Highlight Tint", useItemLabel = false },
    { id = "tail_tint2", label = "Tail Highlight Tint",     name = "Tail Highlight Tint", useItemLabel = false },
    { id = "hoof_feather", label = "Hoof Feather Tint", name = "Hoof Feather Tint", useItemLabel = false },
    { id = "horse_scale",  label = "Horse Scale",       name = "Horse Scale" },
}

-- You’ll fill these from bodies.json / manes.json / tails.json
H.Items = {
    horse_model        = {},
    horse_body_presets = {},
    horse_head_presets = {},
    manes              = {},
    tails              = {},
    hoof_feather       = {},
}

-- Clamp tint helper
local function clampTint(v)
    v = tonumber(v) or 0
    if v == 0 then return 0 end
    if v < 1 then return 1 end
    if v > 254 then return 254 end
    return v
end


-- Shared MetaPed tint palettes for Build-A-Horse body tints
-- If Beauty_Menu has already created B.PALETTES, reuse it.

local T_PALETTES =
    {
        -- HORSE / BODY
        P1  = "metaped_tint_horse",
        P2  = "metaped_tint_horse_001",

        -- ANIMAL / FUR
        P3  = "metaped_tint_animal",

        -- HAIR (WORLD / HORSE)
        P4  = "metaped_tint_hair",

        -- EYES / TEETH / EYE UI
        P5  = "metaped_tint_eye",
        P6  = "metaped_tint_eyes_ui",
        P7 = "metaped_tint_teeth",

        -- LEATHER (HORSE + GENERIC)
        P8 = "metaped_tint_horse_leather",
        P9 = "metaped_tint_horse_leather_001",
        P10 = "metaped_tint_leather",
        P11 = "metaped_tint_combined_leather",

        -- HATS / GENERIC SURFACES
        P12 = "metaped_tint_hat",
        P13 = "metaped_tint_generic",
        P14 = "metaped_tint_genericclean",
        P15 = "metaped_tint_generic_weathered",

        -- MAKEUP / MISC
        P16 = "metaped_tint_makeup",

        -- MPADV (PHOTO-MODE / FILTER SETS)
        P17 = "metaped_tint_mpadv",

        -- UI ONLY
        P18 = "metaped_tint_hair_ui",
    }



-- Expose palettes so other menus/scripts can reuse them
H.PALETTES = T_PALETTES
CoalBuildAHorse._data = CoalBuildAHorse._data or {}
CoalBuildAHorse._data.PALETTES = T_PALETTES
if CoalBeauty and CoalBeauty._data then
    CoalBeauty._data.PALETTES = T_PALETTES
end

local function BuildPaletteItems()
    local items      = {}
    local orderedIds = {}

    for key in pairs(T_PALETTES) do
        orderedIds[#orderedIds+1] = key
    end

    table.sort(orderedIds, function(a, b)
        local na = tonumber(a:match("^P(%d+)$") or 99)
        local nb = tonumber(b:match("^P(%d+)$") or 99)
        return na < nb
    end)

    for _, key in ipairs(orderedIds) do
        local paletteName = T_PALETTES[key]
        items[#items+1] = {
            id        = key,
            label     = string.format("Coat Palette %s", key),
            palette   = paletteName,
            sortIndex = tonumber(key:match("^P(%d+)$")) or 0,
        }
    end

    return items
end

local function LoadJson(path)
    local raw = LoadResourceFile(BA_HORSE_RESNAME, path)
    if not raw or raw == "" then
        print(("[BuildAHorse] missing file: %s"):format(path))
        return nil
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= "table" then
        print(("[BuildAHorse] ERROR decoding %s: %s"):format(path, tostring(decoded)))
        return nil
    end

    return decoded
end

local function NormalizeItems(list)
    local out = {}
    for _, rec in ipairs(list or {}) do
        local id = rec.id or rec.name
        if id then
            local item = {
                id            = id,
                label         = rec.label or rec.name or id,
                desc          = rec.desc,
                sortIndex     = rec.sortIndex,
                swatchTexture = rec.swatchTexture,
                swatchPalette = rec.swatchPalette,
                swatchTint0   = clampTint(rec.swatchTint0),
                swatchTint1   = clampTint(rec.swatchTint1),
                swatchTint2   = clampTint(rec.swatchTint2),
                assets        = rec.assets or {},
            }

            for _, a in ipairs(item.assets) do
                a.tint0 = clampTint(a.tint0)
                a.tint1 = clampTint(a.tint1)
                a.tint2 = clampTint(a.tint2)
            end

            table.insert(out, item)
        end
    end
    return out
end

-- Body drawables (000–015)
local function BuildBodyDrawableItems(regionPrefix)
    local list = {}
    for drawableIdx = 0, 15 do
        local name = string.format("%s_%03d", regionPrefix, drawableIdx)
        list[#list + 1] = {
            id           = name,
            label        = name,
            drawableName = name,
            drawableIdx  = drawableIdx,
        }
    end
    return list
end

-- Body texture channels
--  Albedo:    845–999 (with some blocked indices)
--  Normals:   001–005
--  Materials: 001–005
local function BuildBodyChannelItems(regionPrefix, kind) -- kind = "ab" | "nm" | "m"
    local list   = {}
    local suffix = (kind == "nm" and "nm") or (kind == "m" and "m") or "ab"

    -- Helper to keep UI clean: "Coat 845" / "Age 001" / "Shine 001"
    local function makeLabel(num)
        if kind == "ab" then
            return ("Coat Style %03d"):format(num)
        elseif kind == "nm" then
            return ("Physique %03d"):format(num)
        else
            return ("Shine Level %03d"):format(num)
        end
    end

    if kind == "ab" then
        -- Base engine range is 845–999, but we skip some problem values:
        --   874, 880, 892, 893, 900–987, 990
        local function isBlocked(num)
            if num == 874 or num == 880 or num == 892 or num == 893 or num == 990 then
                return true
            end
            if num >= 900 and num <= 987 then
                return true
            end
            return false
        end

        for num = 845, 999 do
            if not isBlocked(num) then
                local texName = string.format("%s_000_C0_%03d_%s", regionPrefix, num, suffix)
                list[#list + 1] = {
                    id          = texName,
                    label       = makeLabel(num),
                    textureName = texName,
                    drawableIdx = 0,
                    cVar        = 0,
                    num         = num,
                }
            end
        end
        return list
    end

    if kind == "nm" then
        -- Only keep 001, 002, 004 (remove 003 and 005)
        for _, num in ipairs({ 1, 2, 4 }) do
            local texName = string.format("%s_000_C0_%03d_%s", regionPrefix, num, suffix)
            list[#list + 1] = {
                id          = texName,
                label       = makeLabel(num),
                textureName = texName,
                drawableIdx = 0,
                cVar        = 0,
                num         = num,
            }
        end
        return list
    end

    if kind == "m" then
        for num = 1, 5 do
            local texName = string.format("%s_000_C0_%03d_%s", regionPrefix, num, suffix)
            list[#list + 1] = {
                id          = texName,
                label       = makeLabel(num),
                textureName = texName,
                drawableIdx = 0,
                cVar        = 0,
                num         = num,
            }
        end
        return list
    end

    return list
end

local function BuildTintItems()
    local list = {}
    for v = 2, 254 do
        list[#list+1] = {
            id        = v,
            label     = tostring(v),
            value     = v,
            sortIndex = v,   -- numeric sort so we don’t get 10,100,101...
        }
    end
    return list
end
--
local function BuildScaleItems()
    -- Discrete horse scales from smallest to largest
    local list   = {}
    local values = { 0.85, 0.90, 0.95, 1.00, 1.05, 1.10, 1.15, 1.20, 1.25, 1.30, 1.35 }

    for idx, s in ipairs(values) do
        local label = string.format("Scale x%.2f", s)
        list[#list+1] = {
            id        = string.format("scale_%.2f", s):gsub("%.", "_"), -- e.g. scale_0_90
            label     = label,
            desc      = string.format("<scale value=\"%.6f\">", s),
            sortIndex = idx,
            scale     = s,
        }
    end

    return list
end

--
local function BuildHoofFeatherItems()
    local list     = {}
    local drawable = "p_c_horse_01_feather_000"
    local albedo   = "p_c_horse_01_hair_000_c0_997_ab"
    local normal   = "p_c_horse_01_hair_000_c0_000_nm"
    -- 0 = none (removes hoof feathers)
list[#list+1] = {
    id        = 0,
    label     = "No Hoof Feather",
    value     = 0,
    sortIndex = 0,
    none      = true,
}

local material = "p_c_horse_01_hair_000_c0_000_m"

    for i = 2, 254 do
        list[#list+1] = {
            id        = i,
            label     = tostring(i),
            value     = i,
            sortIndex = i,

            drawable  = drawable,
            albedo    = albedo,
            normal    = normal,
            material  = material,
        }
    end

    return list
end

--

local function LoadAll()
    -- Body drawables
    H.Items.body_hand_drawable = BuildBodyDrawableItems("p_c_horse_01_hand")
    H.Items.body_head_drawable = BuildBodyDrawableItems("p_c_horse_01_head")
    H.Items.body_mis2_drawable = BuildBodyDrawableItems("p_c_horse_01_mis2")

    -- Body texture channels
    H.Items.body_hand_ab = BuildBodyChannelItems("p_c_horse_01_hand", "ab")
    H.Items.body_hand_nm = BuildBodyChannelItems("p_c_horse_01_hand", "nm")
    H.Items.body_hand_m  = BuildBodyChannelItems("p_c_horse_01_hand", "m")

    H.Items.body_head_ab = BuildBodyChannelItems("p_c_horse_01_head", "ab")
    H.Items.body_head_nm = BuildBodyChannelItems("p_c_horse_01_head", "nm")
    H.Items.body_head_m  = BuildBodyChannelItems("p_c_horse_01_head", "m")

    H.Items.body_mis2_ab = BuildBodyChannelItems("p_c_horse_01_mis2", "ab")
    H.Items.body_mis2_nm = BuildBodyChannelItems("p_c_horse_01_mis2", "nm")
    H.Items.body_mis2_m  = BuildBodyChannelItems("p_c_horse_01_mis2", "m")

    -- Shared palette selectors
    local paletteItems   = BuildPaletteItems()
    H.Items.body_palette = paletteItems
    H.Items.hair_palette = paletteItems   -- NEW: manes + tails share this list


    -- Tint lists (shared object to keep memory small)
    local tintItems = BuildTintItems()
    H.Items.body_hand_tint0 = tintItems
    H.Items.body_hand_tint1 = tintItems
    H.Items.body_hand_tint2 = tintItems

    H.Items.body_head_tint0 = tintItems
    H.Items.body_head_tint1 = tintItems
    H.Items.body_head_tint2 = tintItems

    H.Items.body_mis2_tint0 = tintItems
    H.Items.body_mis2_tint1 = tintItems
    H.Items.body_mis2_tint2 = tintItems

        -- NEW: mane / tail tint vectors share the same 2–254 list
    H.Items.mane_tint0 = tintItems
    H.Items.mane_tint1 = tintItems
    H.Items.mane_tint2 = tintItems

    H.Items.tail_tint0 = tintItems
    H.Items.tail_tint1 = tintItems
    H.Items.tail_tint2 = tintItems

    H.Items.hoof_feather = BuildHoofFeatherItems()
       -- Horse scale options (0.70–1.50)
    H.Items.horse_scale = BuildScaleItems()
    -- Manes
    local manes = LoadJson("data/manes.json")
    if manes then
        H.Items.manes = NormalizeItems(manes)
        print(("[BuildAHorse] Loaded %d mane entries."):format(#H.Items.manes))
    
        -- UI label cleanup: strip HORSE_EQUIPMENT_ prefix
        for _, it in ipairs(H.Items.manes) do
            if it and it.label then
                it.label = tostring(it.label):gsub("^[Hh][Oo][Rr][Ss][Ee]_[Ee][Qq][Uu][Ii][Pp][Mm][Ee][Nn][Tt]_", "")
            end
        end
end

    -- Tails
    local tails = LoadJson("data/tails.json")
    if tails then
        H.Items.tails = NormalizeItems(tails)
        print(("[BuildAHorse] Loaded %d tail entries."):format(#H.Items.tails))
    
        -- UI label cleanup: strip HORSE_EQUIPMENT_ prefix
        for _, it in ipairs(H.Items.tails) do
            if it and it.label then
                it.label = tostring(it.label):gsub("^[Hh][Oo][Rr][Ss][Ee]_[Ee][Qq][Uu][Ii][Pp][Mm][Ee][Nn][Tt]_", "")
            end
        end
end
end

-- Inject horse list from the parent resource (keeps this file independent).
-- Expected format per item:
-- { id="Morgan", label="Morgan", models={...} }
function CoalBuildAHorse.SetHorseModelItems(items)
    H.Items.horse_model = {}
    if type(items) == "table" then
        for _, it in ipairs(items) do
            if it and (it.models or it.model) then
                local models = it.models
                if not models and type(it.model) == "string" then
                    models = { it.model }
                elseif not models and type(it.model) == "table" then
                    models = it.model
                end

                if type(models) == "table" and #models > 0 then
                    H.Items.horse_model[#H.Items.horse_model+1] = {
                        id        = it.id or it.label or ("horse_" .. tostring(#H.Items.horse_model+1)),
                        label     = it.label or it.name or it.id or "Horse",
                        models    = models,
                        sortIndex = it.sortIndex or 0,
                    }
                end
            end
        end
    end
    sortOnce(H.Items.horse_model)
end

LoadAll()

function CoalBuildAHorse.GetCategories()
    return H.Categories
end

function CoalBuildAHorse.GetItemsForCategory(catId)
    local list = H.Items[catId] or {}
    sortOnce(list)
    return list
end

CoalBuildAHorse._data = H



-- Cleanup spawned/preview horses when resource stops/restarts
local function __coalDeleteEntitySafe(ent)
    if ent and ent ~= 0 and DoesEntityExist(ent) then
        SetEntityAsMissionEntity(ent, true, true)
        DeleteEntity(ent)
    end
end

AddEventHandler("onResourceStop", function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    __coalDeleteEntitySafe(currentHorse)
    __coalDeleteEntitySafe(previewHorse)
    __coalDeleteEntitySafe(PreviewHorse)
    __coalDeleteEntitySafe(currentPreviewHorse)
    __coalDeleteEntitySafe(CurrentPreviewHorse)
    __coalDeleteEntitySafe(stableHorse)
    __coalDeleteEntitySafe(StableHorse)

    -- Extra safety: delete nearby horses spawned by this script if they are mission entities we own.
    local playerPed = PlayerPedId()
    if playerPed and playerPed ~= 0 then
        local pcoords = GetEntityCoords(playerPed)
        local handle, ped = FindFirstPed()
        local success = true
        repeat
            if ped and ped ~= 0 and ped ~= playerPed and DoesEntityExist(ped) then
                if IsPedAPlayer(ped) == false and GetPedType(ped) == 28 then
                    local coords = GetEntityCoords(ped)
                    if #(pcoords - coords) < 60.0 then
                        SetEntityAsMissionEntity(ped, true, true)
                        DeleteEntity(ped)
                    end
                end
            end
            success, ped = FindNextPed(handle)
        until not success
        EndFindPed(handle)
    end
end)

