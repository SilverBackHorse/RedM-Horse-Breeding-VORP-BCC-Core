-- Coal Stables BCC compatibility SQL - safe/idempotent installer
-- Adds the Coal appearance fields used by BCC Stables/player_horses.

CREATE TABLE IF NOT EXISTS `player_horses` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(50) NOT NULL,
  `charid` INT(11) NOT NULL,
  `selected` INT(11) NOT NULL DEFAULT 0,
  `name` VARCHAR(100) NOT NULL,
  `model` VARCHAR(100) NOT NULL,
  `components` LONGTEXT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Compatibility helpers: avoids MySQL/MariaDB version problems with ADD COLUMN IF NOT EXISTS / CREATE INDEX IF NOT EXISTS.
DROP PROCEDURE IF EXISTS `bcc_safe_add_column`;
DELIMITER $$
CREATE PROCEDURE `bcc_safe_add_column`(IN p_table VARCHAR(64), IN p_column VARCHAR(64), IN p_definition TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND COLUMN_NAME = p_column
  ) THEN
    SET @sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS `bcc_safe_add_index`;
DELIMITER $$
CREATE PROCEDURE `bcc_safe_add_index`(IN p_table VARCHAR(64), IN p_index VARCHAR(64), IN p_definition TEXT)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND INDEX_NAME = p_index
  ) THEN
    SET @sql = CONCAT('CREATE INDEX `', p_index, '` ON `', p_table, '` ', p_definition);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;
END$$
DELIMITER ;

CALL `bcc_safe_add_column`('player_horses', 'coal_appearance', 'LONGTEXT DEFAULT NULL');
CALL `bcc_safe_add_column`('player_horses', 'coal_tack_colors', 'LONGTEXT DEFAULT NULL');

DROP PROCEDURE IF EXISTS `bcc_safe_add_column`;
DROP PROCEDURE IF EXISTS `bcc_safe_add_index`;
