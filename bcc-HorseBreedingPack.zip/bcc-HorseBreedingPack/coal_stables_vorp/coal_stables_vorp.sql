-- Coal Stables standalone/VORP table SQL - safe/idempotent installer

CREATE TABLE IF NOT EXISTS `coal_stables_horses` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(128) NOT NULL,
  `slot` INT NOT NULL DEFAULT 1,
  `horse_id` VARCHAR(128) NOT NULL,
  `last_stable` VARCHAR(128) DEFAULT NULL,
  `model` VARCHAR(128) DEFAULT NULL,
  `tack_json` LONGTEXT DEFAULT NULL,
  `beauty_json` LONGTEXT DEFAULT NULL,
  `is_main` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_identifier_slot` (`identifier`, `slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
