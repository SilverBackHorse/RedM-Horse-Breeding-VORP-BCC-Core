local Core = exports.vorp_core:GetCore()

local function getCharacter(src)
    local user = Core.getUser(src)
    if not user then return nil end
    return user.getUsedCharacter
end

CreateThread(function()
    Wait(2000)
    pcall(function()
        MySQL.query.await("ALTER TABLE `player_horses` ADD COLUMN IF NOT EXISTS `coal_appearance` LONGTEXT DEFAULT NULL")
        MySQL.query.await("ALTER TABLE `player_horses` ADD COLUMN IF NOT EXISTS `coal_tack_colors` LONGTEXT DEFAULT NULL")
    end)
end)

Core.Callback.Register("coal_bcc:GetHorses", function(source, cb)
    local char = getCharacter(source)
    if not char then return cb({}) end
    local rows = MySQL.query.await(
        "SELECT id, selected, name, model, gender, xp, health, stamina, dead, coal_appearance, coal_tack_colors FROM `player_horses` WHERE `identifier` = ? AND `charid` = ? AND (`dead` = 0 OR `dead` IS NULL) ORDER BY selected DESC, id ASC",
        { char.identifier, char.charIdentifier }
    ) or {}
    cb(rows)
end)

Core.Callback.Register("coal_bcc:GetAppearance", function(source, cb, horseId)
    local char = getCharacter(source)
    horseId = tonumber(horseId)
    if not char or not horseId then return cb({ appearance = "{}", tackColors = "{}" }) end
    local rows = MySQL.query.await(
        "SELECT id, name, model, gender, coal_appearance, coal_tack_colors FROM `player_horses` WHERE `id` = ? AND `identifier` = ? AND `charid` = ? LIMIT 1",
        { horseId, char.identifier, char.charIdentifier }
    ) or {}
    if rows[1] then
        return cb({
            id = rows[1].id,
            name = rows[1].name,
            model = rows[1].model,
            gender = rows[1].gender or "male",
            appearance = rows[1].coal_appearance or "{}",
            tackColors = rows[1].coal_tack_colors or "{}"
        })
    end
    cb({ appearance = "{}", tackColors = "{}" })
end)

RegisterNetEvent("coal_bcc:SaveAppearance", function(horseId, appearanceJson, tackColorsJson)
    local src = source
    local char = getCharacter(src)
    horseId = tonumber(horseId)
    if not char or not horseId then return end
    MySQL.query.await(
        "UPDATE `player_horses` SET `coal_appearance` = ?, `coal_tack_colors` = ? WHERE `id` = ? AND `identifier` = ? AND `charid` = ?",
        { appearanceJson or "{}", tackColorsJson or "{}", horseId, char.identifier, char.charIdentifier }
    )
    print("[coal_bcc] Saved player_horses id:", horseId, "charid:", char.charIdentifier)
    Core.NotifyRightTip(src, "Coal edits saved to your BCC horse.", 4000)
end)


RegisterNetEvent("coal_bcc:SetHorseGender", function(horseId, gender)
    local src = source
    local char = getCharacter(src)
    horseId = tonumber(horseId)
    gender = tostring(gender or ""):lower()

    if gender == "mare" or gender == "female" or gender == "f" then
        gender = "female"
    elseif gender == "stallion" or gender == "stud" or gender == "male" or gender == "m" then
        gender = "male"
    else
        Core.NotifyRightTip(src, "Invalid horse gender.", 3500)
        return
    end

    if not char or not horseId then return end

    local affected = MySQL.update.await(
        "UPDATE `player_horses` SET `gender` = ? WHERE `id` = ? AND `identifier` = ? AND `charid` = ?",
        { gender, horseId, char.identifier, char.charIdentifier }
    ) or 0

    if affected > 0 then
        local label = gender == "female" and "Mare" or "Stallion"
        Core.NotifyRightTip(src, "Horse gender set to " .. label .. ".", 3500)
    else
        Core.NotifyRightTip(src, "Could not update horse gender.", 3500)
    end
end)
